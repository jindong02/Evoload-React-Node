/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'primary': '#2C2C69',
        'secondary': '#958BB3',
        'bgPrimary': '#E3EEFB',
        'bgSecondary': '#EEF5FE',
        'btnPrimary': '#03A9F4',
        'btnPrimaryText': '#FFFFFF',
        'flag1': '#BFDAFB',
      },
    },
  },
  plugins: [],
}

