import React, { useEffect, useState } from 'react';
import { RxHamburgerMenu, RxCross1 } from 'react-icons/rx';
import { IoPersonOutline } from 'react-icons/io5';
import { FiBell } from 'react-icons/fi';
import { AiOutlineDown, AiOutlinePlus, AiOutlineMinus } from 'react-icons/ai';
import { useDispatch, useSelector } from 'react-redux';
import { toggleSidebar } from '../../slices/sidebarSlice';
import { useNavigate } from 'react-router-dom';
import { logoutUser, saveUser } from '../../slices/authSlice';
import axiosInstance from '../../axiosInstance';
import { addNotification } from '../../slices/notificationSlice';
import { profileMenuExpeditor, profileMenuGeneral, sidebarItemsExpeditor, sidebarItemsExpeditorPrimaryUser, sidebarItemsTransporter, sidebarItemsTransporterPrimaryUser } from '../../utilities/menuItems';
import { type } from '../../utilities/constantValues';
import { useTranslation } from 'react-i18next';

const Navbar = () => {
    const [isOpened, setIsOpened] = useState(false);
    const [openItemId, setOpenItemId] = useState(null);
    const [sidebarItems, setSidebarItems] = useState([]);
    const [profileMenu, setProfileMenu] = useState([]);
    const { isOpen } = useSelector(state => state.sidebar);
    const { user } = useSelector(state => state.auth);
    const { t } = useTranslation();
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const getUserInfo = async () => {
        try {
            const { data: response } = await axiosInstance.get('/users/me');
            dispatch(saveUser(response.data));
        } catch (err) {
            dispatch(addNotification({ type: "error", message: err.response.data.message }));
        }
    };

    const logout = async (item) => {
        try {
            const { data: response } = await axiosInstance.get('/users/logout');
            dispatch(addNotification({ type: "success", message: response.message }));
            dispatch(logoutUser());
            navigate(item.link);
        } catch (err) {
            dispatch(addNotification({ type: "error", message: err.response.data.message }));
        }
    };

    const handleClick = (item) => {
        setIsOpened(false);
        if (item.link) {
            if (item.link === '/log-in') {
                logout(item);
            } else {
                navigate(item.link);
            }
        }
    }

    const handleClickSidebar = (item) => {
        if (item.id === openItemId) {
            if (!item.subItems?.length) {
                dispatch(toggleSidebar());
            }
            setOpenItemId(null);
            return;
        }
        setOpenItemId(item.id);
        if (!item.subItems?.length) {
            dispatch(toggleSidebar());
            navigate(item.link);
        }
    };

    const handleClickSidebarSubItem = (item) => {
        dispatch(toggleSidebar())
        navigate(item.link);
    }

    useEffect(() => {
        if (user && Object.keys(user).length) {
            if (user.type === type.expeditor) {
                if (user.is_primary_user) {
                    setProfileMenu(profileMenuExpeditor);
                    setSidebarItems(sidebarItemsExpeditorPrimaryUser);
                } else {
                    setProfileMenu(profileMenuGeneral);
                    setSidebarItems(sidebarItemsExpeditor);
                }
            } else {
                if (user.is_primary_user) {
                    setProfileMenu(profileMenuGeneral);
                    setSidebarItems(sidebarItemsTransporterPrimaryUser);
                } else {
                    setProfileMenu(profileMenuGeneral);
                    setSidebarItems(sidebarItemsTransporter);
                }
            }
        }
    }, [user]);

    useEffect(() => {
        if (!user) {
            getUserInfo();
        }
    }, []);

    return (
        <div className={`flex flex-row justify-between fixed bg-white p-5 z-10 shadow-sm ${isOpen ? 'w-full lg:w-[calc(100%-220px)]' : 'w-full'}`}>
            <div>
                <RxHamburgerMenu
                    size={24}
                    className={`cursor-pointer ${isOpen ? 'hidden lg:block' : 'block'}`}
                    onClick={() => dispatch(toggleSidebar())}
                />
                <RxCross1
                    size={24}
                    className={`cursor-pointer ${isOpen ? 'block lg:hidden' : 'hidden'}`}
                    onClick={() => dispatch(toggleSidebar())}
                />
                {
                    isOpen &&
                    <div className='lg:hidden absolute bg-blue-700 w-full -left-0 top-16'>
                        <div className='p-5'>
                            {
                                sidebarItems.map((item, index) => (
                                    <div
                                        key={index}
                                        className='flex flex-col cursor-pointer hover:bg-blue-500 px-5 py-1 select-none text-white'
                                        onClick={() => handleClickSidebar(item)}
                                    >
                                        <div className='flex flex-row items-center justify-between'>
                                            <p>
                                                {item.name}
                                            </p>
                                            {
                                                item.subItems?.length &&
                                                <div>
                                                    {
                                                        item.id === openItemId ?
                                                            <div>
                                                                <AiOutlineMinus
                                                                    size={16}
                                                                    className='fill-white'
                                                                />
                                                            </div>
                                                            :
                                                            <div>
                                                                <AiOutlinePlus
                                                                    size={16}
                                                                    className='fill-white'
                                                                />
                                                            </div>
                                                    }
                                                </div>
                                            }
                                        </div>
                                        <div className='px-5'>
                                            {
                                                (item.id === openItemId && item.subItems?.length) &&
                                                item.subItems.map((subItem, index) => (
                                                    <div
                                                        key={index}
                                                        className='text-white my-2 text-sm'
                                                        onClick={() => handleClickSidebarSubItem(subItem)}
                                                    >
                                                        {subItem.name}
                                                    </div>
                                                ))
                                            }
                                        </div>
                                    </div>
                                ))
                            }
                        </div>
                    </div>
                }
            </div>
            <div className='flex flex-row items-center'>
                <FiBell
                    size={24}
                    className='mr-5 lg:mr-10 cursor-pointer'
                />
                <span
                    className='flex items-center cursor-pointer relative'
                    onClick={() => setIsOpened((prev) => !prev)}
                >
                    <IoPersonOutline
                        size={24}
                    />
                    <p className='text-primary font-normal pl-1 pr-1 select-none'>
                        {user?.first_name} {user?.surname}
                    </p>
                    <AiOutlineDown
                        size={16}
                    />
                </span>
                {
                    isOpened &&
                    <div className='absolute bg-blue-700 text-white right-5 top-16 py-3 w-[200px]'>
                        {
                            profileMenu.map((item, index) => (
                                <div
                                    key={index}
                                    className='flex flex-row items-center cursor-pointer px-5 py-1 hover:bg-blue-400'
                                    onClick={() => handleClick(item)}
                                >
                                    <item.icon className='fill-white mr-2' />
                                    <span className='select-none'>
                                        {t(item.name)}
                                    </span>
                                </div>

                            ))
                        }
                    </div>
                }
            </div>
        </div>
    );
};

export default Navbar;