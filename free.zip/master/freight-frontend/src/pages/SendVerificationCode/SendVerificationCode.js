import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import axiosInstance from '../../axiosInstance';
import { addNotification } from '../../slices/notificationSlice';

const SendVerificationCode = () => {
    const { user } = useSelector(state => state.auth);
    const dispatch = useDispatch();

    const sendVerificationCode = async () => {
        try {
            const { data: response } = await axiosInstance.post(`/users/send-verification-code`, {
                id: user.id,
            });
            dispatch(addNotification({ type: "success", message: response.message }));
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data?.message }));
        }
    };

    return (
        <div className='flex justify-center items-center h-screen'>
            <div className='w-1/2'>
                <div className='text-center'>
                    <h1 className='text-3xl font-bold text-primary'>
                        Please check your email to verify your account.
                    </h1>
                    <p className='text-secondary mt-5 text-xl'>
                        Haven't received the email?
                        <span
                            className='text-primary cursor-pointer select-none px-2 font-semibold'
                            onClick={sendVerificationCode}
                        >Click here</span>
                        to resend.
                    </p>
                </div>
            </div>
        </div>
    );
};

export default SendVerificationCode;