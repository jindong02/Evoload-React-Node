import React, { useEffect, useState } from 'react';
import { BsTruck } from 'react-icons/bs';
import { SlCalender } from 'react-icons/sl';
import { AiOutlineClockCircle } from 'react-icons/ai';
import AddFreightLabelWithInput from '../../components/AddFreightLabelWithInput/AddFreightLabelWithInput';
import CheckboxWithIcon from '../../components/CheckboxWithIcon/CheckboxWithIcon';
import InputField from '../../components/InputField/InputField';
import DatePicker from '../../components/DatePicker/DatePicker';
import Dropdown from '../../components/Dropdown/Dropdown';
import { useForm } from 'react-hook-form';
import { hourArray } from '../../utilities/menuItems';
import axiosInstance from '../../axiosInstance';
import { useDispatch } from 'react-redux';
import { addNotification } from '../../slices/notificationSlice';
import TextArea from '../../components/TextArea/TextArea';
import Button from '../../components/Button/Button';
import { useParams } from 'react-router-dom';
import ShowStarts from '../../components/ShowStarts/ShowStarts';
import { useTranslation } from 'react-i18next';


const hourArrayData = hourArray();

const EditOffer = () => {
    const { id } = useParams();
    const [freight, setFreight] = useState({});
    const [currencies, setCurrencies] = useState([]);
    const { t } = useTranslation();
    const dispatch = useDispatch();
    const {
        register,
        handleSubmit,
        formState: { errors },
        setValue,
        watch
    } = useForm();

    const watchDirectDelivery = watch("directDelivery");
    const watchLoadingDate = watch("loadingDate");

    const formatDate = (date) => {
        return date.toISOString().split('T')[0];
    };

    const populateForm = (data) => {
        setValue('directDelivery', data.direct_delivery);
        setValue('offerPrice', data.offer_price);
        setValue('currencyId', data.currency_id);
        setValue('vatIncluded', data.vat_included ? 'yes' : 'no');
        setValue('loadingDate', data.loading_date ? formatDate(new Date(data.loading_date)) : undefined);
        setValue('loadingHour', data.loading_hour?.replace(':00', ''));
        setValue('unloadingDate', data.unloading_date ? formatDate(new Date(data.unloading_date)) : undefined);
        setValue('unloadingHour', data.unloading_hour?.replace(':00', ''));
        setValue('details', data.details);
    };

    const getAllCurrencies = async () => {
        try {
            const { data } = await axiosInstance.get('/currencies?order=title&direction=asc');
            setCurrencies(data.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const getFreightDataById = async (freightId) => {
        try {
            const { data: response } = await axiosInstance.get(`/freights/${freightId}`);
            setFreight(response.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const getOfferById = async (offerId) => {
        try {
            const { data: response } = await axiosInstance.get(`/offers/${offerId}`);
            populateForm(response.data);
            getFreightDataById(response.data.freight_id);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const onSubmit = async (formData) => {
        try {
            const { data: response } = await axiosInstance.put(`/freights/${freight.id}/offer/${id}`, formData);
            dispatch(addNotification({ type: "success", message: response.message }));
            getOfferById(id);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        getOfferById(id);
    }, [id]);

    useEffect(() => {
        getAllCurrencies();
    }, []);

    return (
        <div className='flex flex-col lg:flex-row flex-wrap'>
            <div className='w-full p-3'>
                <div className='p-5 bg-[#F8FBFF] text-xl'>
                    {t('editOffer')}
                </div>
                <div className='bg-white px-5 flex flex-col lg:flex-row'>
                    <div className='w-full lg:w-1/2 p-0 lg:p-5'>
                        <AddFreightLabelWithInput
                            label={t('directDelivery')}
                            icon={BsTruck}
                            error={errors.directDelivery && "This field is required"}
                        >
                            <div className='mt-3'>
                                <CheckboxWithIcon
                                    formData={register('directDelivery')}
                                />
                            </div>
                        </AddFreightLabelWithInput>
                        <AddFreightLabelWithInput
                            label={t('offerPrice')}
                            icon={BsTruck}
                            error={errors.offerPrice && errors.offerPrice.type === "min" ? "Offer Price must be greater or equal to 0" : errors.offerPrice && "Offer Price is required"}
                        >
                            <InputField
                                className='px-3 py-2'
                                placeholder={t('offerPrice')}
                                type='Number'
                                formData={register('offerPrice', { required: true, min: 0 })}
                            />
                        </AddFreightLabelWithInput>
                        <AddFreightLabelWithInput
                            label={t('currency')}
                            icon={BsTruck}
                            error={errors.currencyId && "Currency is required"}
                        >
                            <Dropdown
                                className='py-2 px-3'
                                placeholder={`${t('select')} ${t('currency')}`}
                                options={currencies}
                                formData={register('currencyId', { required: true, validate: value => value !== "null" })}
                            />
                        </AddFreightLabelWithInput>
                        <AddFreightLabelWithInput
                            label={t('vatIncluded')}
                            icon={BsTruck}
                            error={errors.vatIncluded && "Vat Included is required"}
                        >
                            <Dropdown
                                className='py-2 px-3'
                                placeholder={`${t('select')} ${t('vatIncluded')}`}
                                options={[
                                    { id: 'yes', title: 'Yes' },
                                    { id: 'no', title: 'No' }
                                ]}
                                formData={register('vatIncluded', { required: true, validate: value => value !== "null" })}
                            />
                        </AddFreightLabelWithInput>
                        <AddFreightLabelWithInput
                            label={t('loadingDate')}
                            icon={SlCalender}
                            error={errors.loadingDate && "Loading Date is required"}
                        >
                            <DatePicker
                                className='py-2'
                                formData={register('loadingDate', { required: true })}
                            />
                        </AddFreightLabelWithInput>
                        <AddFreightLabelWithInput
                            label={t('loadingHour')}
                            icon={AiOutlineClockCircle}
                            error={errors.loadingHour && "Please select a valid hour"}
                        >
                            <Dropdown
                                className='py-2 px-3'
                                placeholder={`${t('select')} ${t('loadingHour')}`}
                                options={hourArrayData}
                                formData={register('loadingHour', { required: true, validate: value => value !== "null" })}
                            />
                        </AddFreightLabelWithInput>
                        {
                            watchDirectDelivery === false &&
                            <>
                                <AddFreightLabelWithInput
                                    label={t('unloadingDate')}
                                    icon={SlCalender}
                                    error={errors.unloadingDate && errors.unloadingDate.type === "validate" ? "Unloading Date must be greater than Loading Date" : errors.unloadingDate && "Unloading Date is required"}
                                >
                                    <DatePicker
                                        className='py-2'
                                        formData={register('unloadingDate', { required: watchDirectDelivery === false ? true : false, validate: value => value >= watchLoadingDate })}
                                    />
                                </AddFreightLabelWithInput>
                                <AddFreightLabelWithInput
                                    label={t('unloadingHour')}
                                    icon={AiOutlineClockCircle}
                                    error={errors.unloadingHour && "Please select a valid hour"}
                                >
                                    <Dropdown
                                        className='py-2 px-3'
                                        placeholder={`${t('select')} ${t('unloadingHour')}`}
                                        options={hourArrayData}
                                        formData={register('unloadingHour', { required: watchDirectDelivery === false ? true : false, validate: value => value !== "null" })}
                                    />
                                </AddFreightLabelWithInput>
                            </>
                        }
                    </div>
                    <div className='w-full lg:w-1/2 p-0 lg:p-5'>
                        <p className='mt-5 lg:mt-2'>
                            {t('detailsAboutLoadingAndUnloadingPossibilities')}
                        </p>
                        <TextArea
                            className='mt-3 p-2'
                            placeholder={t('detailsAboutLoadingAndUnloadingPossibilities')}
                            rows={12}
                            formData={register('details')}
                        />
                        <Button
                            className='mt-5 px-3 py-2 ml-auto select-none cursor-pointer'
                            title={t('save')}
                            onClick={handleSubmit(onSubmit)}
                        />
                    </div>
                </div>
            </div>
            <div className='w-full flex flex-col lg:flex-row'>
                <div className='w-full p-3'>
                    <div className='p-5 bg-[#F8FBFF] text-xl text-center'>
                        {t('loadingDetails')}
                    </div>
                    <div className='bg-white px-5 flex flex-col lg:flex-row'>
                        <div className='w-full p-0 lg:p-5'>
                            <AddFreightLabelWithInput
                                label={t('fromCountry')}
                                icon={BsTruck}
                            >
                                <p className='py-2' >
                                    {freight?.freights_from?.title}
                                </p>
                            </AddFreightLabelWithInput>
                            <AddFreightLabelWithInput
                                label={t('loadingDate')}
                                icon={BsTruck}
                            >
                                <p className='py-2' >
                                    {
                                        freight?.loading_asap_loading ? 'ASAP' : `${new Date(freight?.loading_from_date).toLocaleDateString()} ${t('to')} ${new Date(freight?.loading_to_date).toLocaleDateString()}`
                                    }
                                </p>
                            </AddFreightLabelWithInput>
                            {
                                !freight?.loading_asap_loading &&
                                <AddFreightLabelWithInput
                                    label={t('loadingHour')}
                                    icon={BsTruck}
                                >
                                    <p className='py-2' >
                                        {
                                            `${freight?.loading_between} ${t('to')} ${freight?.loading_and}`
                                        }
                                    </p>
                                </AddFreightLabelWithInput>
                            }
                        </div>
                    </div>
                </div>
                <div className='w-full p-3'>
                    <div className='p-5 bg-[#F8FBFF] text-xl text-center'>
                        {t('unloadingDetails')}
                    </div>
                    <div className='bg-white px-5 flex flex-col lg:flex-row'>
                        <div className='w-full p-0 lg:p-5'>
                            <AddFreightLabelWithInput
                                label={t('toCountry')}
                                icon={BsTruck}
                            >
                                <p className='py-2' >
                                    {freight?.freights_to?.title}
                                </p>
                            </AddFreightLabelWithInput>
                            <AddFreightLabelWithInput
                                label={t('unloadingDate')}
                                icon={BsTruck}
                            >
                                <p className='py-2'>
                                    {
                                        freight?.unloading_direct_delivery ? 'Direct Delivery' : `${new Date(freight?.unloading_from_date).toLocaleDateString()} ${t('to')} ${new Date(freight?.unloading_to_date).toLocaleDateString()}`
                                    }
                                </p>
                            </AddFreightLabelWithInput>
                            {
                                !freight?.unloading_direct_delivery &&
                                <AddFreightLabelWithInput
                                    label={t('unloadingHour')}
                                    icon={BsTruck}
                                >
                                    <p className='py-2' >
                                        {
                                            `${freight?.unloading_between} ${t('to')} ${freight?.unloading_and}`
                                        }
                                    </p>
                                </AddFreightLabelWithInput>
                            }
                        </div>
                    </div>
                </div>
            </div>
            <div className='w-full p-3'>
                <div className='p-5 bg-[#F8FBFF] text-xl'>
                    {t('freightDetails')}
                </div>
                <div className='bg-white px-5 flex flex-col lg:flex-row'>
                    <div className='w-full lg:w-1/2 p-0 lg:p-5'>
                        <p className='bg-btnPrimary px-2 py-1 inline-block rounded my-2'>
                            <span
                                className='font-semibold text-white mr-2'
                            >
                                {t('freightNo')}:
                            </span>
                            <span className='text-white '>
                                {freight?.id}
                            </span>
                        </p>
                        <AddFreightLabelWithInput
                            label={t('carType')}
                            icon={BsTruck}
                        >
                            <p className='py-2' >
                                {freight?.CarType?.title}
                            </p>
                        </AddFreightLabelWithInput>
                        <AddFreightLabelWithInput
                            label={t('weightInTons')}
                            icon={BsTruck}
                        >
                            <p className='py-2'>
                                {freight?.weight}
                            </p>
                        </AddFreightLabelWithInput>
                    </div>
                    <div className='w-full lg:w-1/2 p-0 lg:p-5'>
                        <AddFreightLabelWithInput
                            label={t('transportType')}
                            icon={BsTruck}
                        >
                            <p className='py-2' >
                                {freight?.TransportType?.title}
                            </p>
                        </AddFreightLabelWithInput>
                        <AddFreightLabelWithInput
                            label={t('paymentDeadline')}
                            icon={BsTruck}
                        >
                            <p className='py-2'>
                                {freight?.PaymentDeadline?.title}
                            </p>
                        </AddFreightLabelWithInput>
                    </div>
                </div>
            </div>
            <div className='w-full flex flex-col lg:flex-row'>
                <div className='w-full p-3'>
                    <div className='p-5 bg-[#F8FBFF] text-xl'>
                        <p>
                            {t('companyInfo')} - <span className='text-btnPrimary'>{freight?.Company?.title}</span>
                        </p>
                    </div>
                    <div className='bg-white px-5 flex flex-col lg:flex-row'>
                        <div className='w-full p-0 lg:p-5'>
                            <p className='my-1'>
                                <span className='text-primary font-bold mx-2'>
                                    {t('address')}:
                                </span>
                                <span className='text-primary'>
                                    {freight?.Company?.street_and_number}
                                </span>
                            </p>
                            <p className='my-1'>
                                <span className='text-primary font-bold mx-2'>
                                    {t('companySinceYear')}:
                                </span>
                                <span className='text-primary'>
                                    {freight?.Company?.established_in}
                                </span>
                            </p>
                            <p className='my-1'>
                                <span className='text-primary font-bold mx-2'>
                                    {t('ownerDirector')}:
                                </span>
                                <span className='text-primary'>
                                    {freight?.Company?.owner}
                                </span>
                            </p>
                            <p className='my-1'>
                                <span className='text-primary font-bold mx-2'>
                                    {t('companyRepresentativename')}:
                                </span>
                                <span className='text-primary'>
                                    {freight?.Company?.street_and_number}
                                </span>
                            </p>
                        </div>
                    </div>
                </div>
                <div className='w-full p-3'>
                    <div className='p-5 bg-[#F8FBFF] text-xl'>
                        {freight?.Company?.title} - {t('reviews')}
                    </div>
                    <div className='bg-white p-5 flex flex-col justify-center items-center'>
                        <p className='text-primary font-bold text-6xl'>
                            {(freight?.Company?.total_star_count / freight?.Company?.total_review_count).toFixed(2) === 'NaN' ? '0.00' : (freight?.Company?.total_star_count / freight?.Company?.total_review_count).toFixed(2)}
                        </p>
                        <div className='flex flex-row py-1'>
                            <ShowStarts rating={(freight?.Company?.total_star_count / freight?.Company?.total_review_count).toFixed(2)} />
                        </div>
                        <p className='text-primary text-md'>
                            {freight?.Company?.total_review_count} {t('reviews')}
                        </p>
                    </div>
                </div>
            </div>
        </div >
    );
};

export default EditOffer;