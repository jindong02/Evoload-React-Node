import React, { useEffect, useState } from 'react';
import Pagination from '../../components/Pagination/Pagination';
import axiosInstance from '../../axiosInstance';
import { addNotification } from '../../slices/notificationSlice';
import { useDispatch } from 'react-redux';
import getRowCountToPage from '../../utilities/getRowCountToPage';
import ActiveFreightsCard from '../../components/ActiveFreightCard/ActiveFreightsCard';
import { useTranslation } from 'react-i18next';

const ActiveFreights = () => {
    const [freightsCount, setFreightsCount] = useState(0);
    const [freights, setFreights] = useState([]);
    const [pageIndex, setPageIndex] = useState(0);
    const { t } = useTranslation();
    const dispatch = useDispatch();

    const handleStart = async (id) => {
        try {
            const { data: response } = await axiosInstance.patch(`/freights/${id}/start-freight`);
            dispatch(addNotification({ type: "success", message: response.message }));
            getActiveFreights();
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const handleFinish = async (id) => {
        try {
            const { data: response } = await axiosInstance.patch(`/freights/${id}/finish-freight`);
            dispatch(addNotification({ type: "success", message: response.message }));
            getActiveFreights();
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const cancelFreight = async (id) => {
        try {
            const { data: response } = await axiosInstance.patch(`/freights/${id}/cancel`);
            dispatch(addNotification({ type: "success", message: response.message }));
            getActiveFreights();
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const getActiveFreights = async () => {
        try {
            const { data: response } = await axiosInstance.get(`/freights/active-freights?page=${pageIndex + 1}`);
            setFreightsCount(response.data.count);
            setFreights(response.data.rows);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        getActiveFreights();
    }, [pageIndex]);

    return (
        <div className='overflow-x-auto'>
            <div className='my-2 w-full min-w-[800px]'>
                <div className='flex flex-row bg-white py-3'>
                    <p className='w-3/12 px-3 font-bold text-primary'>{t('load')}</p>
                    <p className='w-3/12 px-3 font-bold text-primary'>{t('unload')}</p>
                    <p className='w-4/12 px-3 font-bold text-primary'>{t('contact')}</p>
                    <p className='w-2/12 px-3 font-bold text-primary text-center'>{t('actions')}</p>
                </div>
                {
                    freights.map((item, index) => (
                        <ActiveFreightsCard
                            key={index}
                            item={item}
                            handleStart={handleStart}
                            handleFinish={handleFinish}
                            cancelFreight={cancelFreight}
                        />
                    ))
                }
            </div>
            <Pagination
                pageCount={getRowCountToPage(freightsCount)}
                pageIndex={pageIndex}
                setPageIndex={setPageIndex}
            />
        </div>
    );
};
export default ActiveFreights;