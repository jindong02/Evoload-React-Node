import React, { useEffect, useState } from 'react';
import MyOfferCard from '../../components/MyOfferCard/MyOfferCard';
import { useDispatch } from 'react-redux';
import { addNotification } from '../../slices/notificationSlice';
import axiosInstance from '../../axiosInstance';
import Pagination from '../../components/Pagination/Pagination';
import getRowCountToPage from '../../utilities/getRowCountToPage';
import { useNavigate, useParams } from 'react-router-dom';
import FreightOfferCard from '../../components/FreightOfferCard/FreightOfferCard';
import Modal from '../../components/Modal/Modal';
import { useTranslation } from 'react-i18next';

const activeTransportsTableHeader = [
    'company',
    'offer',
    'loading',
    'unloading',
    'offeredOn',
    'actions'
];

const Offers = () => {
    const { id } = useParams();
    const [offerCount, setOfferCount] = useState(0);
    const [offer, setOffer] = useState([]);
    const [pageIndex, setPageIndex] = useState(0);
    const [showModal, setShowModal] = useState(false);
    const [modalData, setModalData] = useState({});
    const { t } = useTranslation();
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const getOffersByFreightId = async (freightId) => {
        try {
            const { data: response } = await axiosInstance.get(`/freights/${freightId}/offers?page=${pageIndex + 1}`);
            setOfferCount(response.data.count);
            setOffer(response.data.rows);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const acceptOffer = async (offerId) => {
        try {
            const { data: response } = await axiosInstance.post(`/freights/${id}/accept-offer`, { offerId });
            dispatch(addNotification({ type: "success", message: response.message }));
            navigate('/my-freights');
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const openModal = (data) => {
        setModalData(data);
        setShowModal(true);
    }

    useEffect(() => {
        getOffersByFreightId(id);
    }, [pageIndex, id]);

    return (
        <div>
            <Modal
                title='Offer Details'
                showModal={showModal}
                setShowModal={setShowModal}
            >
                <p className='text-center'>
                    {modalData.details}
                </p>
            </Modal>
            <div className='my-5 border border-slate-300'>
                <div className='bg-bgSecondary p-5 flex flex-col lg:flex-row justify-between lg:items-center'>
                    <p className='text-primary text-xl'>
                        {t('offers')}
                    </p>
                </div>
                <div className='bg-white'>
                    <div className='overflow-x-auto'>
                        <div className='my-5 bg-white drop-shadow-sm w-full'>
                            <div className='w-full flex flex-row px-3'>
                                {
                                    activeTransportsTableHeader.map((item, index) => (
                                        <div
                                            key={index}
                                            className={`px-4 py-2 font-bold text-left text-primary tracking-wider ${index < 1 ? 'w-3/12' : index === 1 ? 'w-1/12' : 'w-2/12'} ${index === activeTransportsTableHeader.length - 1 ? 'text-center' : ''}`}
                                        >{t(item)}</div>
                                    ))
                                }
                            </div>
                            {
                                offer.map((item, index) => (
                                    <FreightOfferCard
                                        key={index}
                                        item={item}
                                        openModal={openModal}
                                        acceptOffer={acceptOffer}
                                    />
                                ))
                            }
                            <Pagination
                                pageCount={getRowCountToPage(offerCount)}
                                pageIndex={pageIndex}
                                setPageIndex={setPageIndex}
                            />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Offers;