import React, { useEffect, useState } from 'react';
import AddTruckStepOne from '../../components/AddTruckStepOne/AddTruckStepOne';
import AddTruckStepTwo from '../../components/AddTruckStepTwo/AddTruckStepTwo';
import AddTruckStepThree from '../../components/AddTruckStepThree/AddTruckStepThree';
import axiosInstance from '../../axiosInstance';
import { addNotification } from '../../slices/notificationSlice';
import { useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';

const AddTruck = () => {
    const [data, setData] = useState({});
    const [step, setStep] = useState(1);
    const [saveTruck, setSaveTruck] = useState(false);
    const [reset, setReset] = useState([]);
    const { t } = useTranslation();

    const dispatch = useDispatch();

    const changeStep = (step) => {
        setStep(step);
    };

    const updateData = (newData) => {
        setData((prevData) => ({ ...prevData, ...newData }));
    };

    const components = {
        1: <AddTruckStepOne
            changeStep={changeStep}
            updateData={updateData}
            data={data}
            reset={reset}
            setReset={setReset}
        />,
        2: <AddTruckStepTwo
            changeStep={changeStep}
            updateData={updateData}
            data={data}
            reset={reset}
            setReset={setReset}
        />,
        3: <AddTruckStepThree
            changeStep={changeStep}
            updateData={updateData}
            data={data}
            setSaveTruck={setSaveTruck}
            reset={reset}
            setReset={setReset}
        />,
    };

    const saveTruckData = async () => {
        try {
            const { data: response } = await axiosInstance.post('/trucks', data);
            dispatch(addNotification({ type: "success", message: response.message }));
            setReset([1, 2, 3]);
            setStep(1);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        } finally {
            setSaveTruck(false);
        }
    };

    useEffect(() => {
        if (saveTruck) {
            saveTruckData();
        }
    }, [data]);

    return (
        <div>
            <div className='flex flex-row items-center justify-between'>
                <p className='text-primary text-2xl font-medium'>
                    {t('addTruck')}
                </p>
            </div>
            <div className='my-5'>
                {
                    components[step]
                }
            </div>
        </div>
    );
};

export default AddTruck;