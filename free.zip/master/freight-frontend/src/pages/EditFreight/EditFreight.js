import React, { useEffect, useState } from 'react';
import NewFreightContainer from '../../components/NewFreightContainer/NewFreightContainer';
import { BsTruck, BsFlag } from 'react-icons/bs';
import { SlCalender } from 'react-icons/sl';
import { AiOutlineClockCircle } from 'react-icons/ai';
import InputField from '../../components/InputField/InputField';
import AddFreightLabelWithInput from '../../components/AddFreightLabelWithInput/AddFreightLabelWithInput';
import CheckboxWithIcon from '../../components/CheckboxWithIcon/CheckboxWithIcon';
import DatePicker from '../../components/DatePicker/DatePicker';
import Dropdown from '../../components/Dropdown/Dropdown';
import { hourArray } from '../../utilities/menuItems';
import axiosInstance from '../../axiosInstance';
import { useDispatch } from 'react-redux';
import { addNotification } from '../../slices/notificationSlice';
import TextArea from '../../components/TextArea/TextArea';
import { ReactComponent as IconOne } from '../../assets/icons/empire.svg';
import { ReactComponent as IconTwo } from '../../assets/icons/triangle-exclamation-solid.svg';
import { ReactComponent as IconThree } from '../../assets/icons/square-caret-up-regular.svg';
import Button from '../../components/Button/Button';
import { useForm } from 'react-hook-form';
import { useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

const hourArrayData = hourArray();

const EditFreight = () => {
    const { id } = useParams();
    const [carTypes, setCarTypes] = useState([]);
    const [transportTypes, setTransportTypes] = useState([]);
    const [currencies, setCurrencies] = useState([]);
    const [paymentDeadlines, setPaymentDeadlines] = useState([]);
    const [countryCodes, setCountryCodes] = useState([]);
    const [countries, setCountries] = useState([]);
    const { t } = useTranslation();

    const dispatch = useDispatch();

    const {
        register,
        handleSubmit,
        formState: { errors },
        setValue,
        watch
    } = useForm();

    const watchAsapLoading = watch("loadingAsapLoading");
    const watchDirectDelivery = watch("directDelivery");
    const watchLoadingFromDate = watch("loadingFromDate");
    const watchUnloadingFromDate = watch("unloadingFromDate");
    const watchShowPhone = watch("showPhone");
    const watchPhone = watch("phone");

    const idDoesExist = (id, arr) => {
        return arr.some((el) => el.id === id);
    };

    const formatDate = (date) => {
        return date.toISOString().split('T')[0];
    }

    const populateForm = (data) => {
        setValue('loadingAsapLoading', data?.loading_asap_loading);
        setValue('loadingFromCountryId', data?.from_country_id);
        setValue('loadingFromDate', data?.loading_from_date ? formatDate(new Date(data?.loading_from_date)) : undefined);
        setValue('loadingToDate', data?.loading_to_date ? formatDate(new Date(data?.loading_to_date)) : undefined);
        setValue('loadingBetween', data?.loading_between?.replace(':00', ''));
        setValue('loadingAnd', data?.loading_and?.replace(':00', ''));
        setValue('directDelivery', data?.unloading_direct_delivery);
        setValue('unloadingToCountryId', data?.to_country_id);
        setValue('unloadingFromDate', data?.unloading_from_date ? formatDate(new Date(data?.unloading_from_date)) : undefined);
        setValue('unloadingToDate', data?.unloading_to_date ? formatDate(new Date(data?.unloading_to_date)) : undefined);
        setValue('unloadingBetween', data?.unloading_between?.replace(':00', ''));
        setValue('unloadingAnd', data?.unloading_and?.replace(':00', ''));
        setValue('paymentDeadlineId', data?.payment_deadline_id);
        setValue('carTypeId', data?.car_type_id);
        setValue('transportTypeId', data?.transport_type_id);
        setValue('distance', data?.distance);
        setValue('suggestedPrice', data?.suggested_price);
        setValue('currencyId', data?.currency_id);
        setValue('vatIncluded', data?.vat_included ? "yes" : "no");
        setValue('weight', data?.weight);
        setValue('articles', data?.articles);
        setValue('volume', data?.volume);
        setValue('referenceNo', data?.reference);
        setValue('specialRequirementOne', idDoesExist(1, data?.special_requirements));
        setValue('specialRequirementTwo', idDoesExist(2, data?.special_requirements));
        setValue('specialRequirementThree', idDoesExist(3, data?.special_requirements));
        setValue('observations', data?.observations);
        setValue('phone', data?.phone);
        setValue('showPhone', data?.show_phone);
        setValue('countryCodeId', data?.country_code_id);
    };

    const getEditableFreightById = async (freightId) => {
        try {
            const { data: response } = await axiosInstance.get(`/freights/${freightId}/editable`);
            populateForm(response.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data?.message }));
        }
    };

    const getAllPaymentDeadlines = async () => {
        try {
            const { data } = await axiosInstance.get('/payment-deadlines?order=title&direction=asc');
            setPaymentDeadlines(data?.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data?.message }));
        }
    };

    const getAllCarTypes = async () => {
        try {
            const { data } = await axiosInstance.get('/car-types?order=title&direction=asc');
            setCarTypes(data?.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data?.message }));
        }
    };

    const getAllTransportTypes = async () => {
        try {
            const { data } = await axiosInstance.get('/transport-types?order=title&direction=asc');
            setTransportTypes(data?.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data?.message }));
        }
    };

    const getAllCurrencies = async () => {
        try {
            const { data } = await axiosInstance.get('/currencies?order=title&direction=asc');
            setCurrencies(data?.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data?.message }));
        }
    };

    const getAllCountryCodes = async () => {
        try {
            const { data: response } = await axiosInstance.get('/country-codes');
            setCountryCodes(response.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const getAllCountries = async () => {
        try {
            const { data } = await axiosInstance.get('/countries?order=title&direction=asc');
            setCountries(data.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const submitForm = async (formData) => {
        try {
            const { data: response } = await axiosInstance.put(`freights/${id}/edit`, formData);
            dispatch(addNotification({ type: "success", message: response.message }));
            getEditableFreightById(id);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data?.message }));
        }
    };

    useEffect(() => {
        getAllPaymentDeadlines();
        getAllCarTypes();
        getAllTransportTypes();
        getAllCurrencies();
        getAllCountryCodes();
        getAllCountries();
        getEditableFreightById(id);
    }, [id]);

    return (
        <div className='flex flex-col lg:flex-row flex-wrap'>
            <NewFreightContainer title={t('loadingDetails')}>
                <AddFreightLabelWithInput
                    label={t('asapLoading')}
                    icon={BsTruck}
                    error={errors.loadingAsapLoading && "This field is required"}
                >
                    <div className='mt-3'>
                        <CheckboxWithIcon
                            formData={register('loadingAsapLoading')}
                        />
                    </div>
                </AddFreightLabelWithInput>
                <AddFreightLabelWithInput
                    label={t('fromCountry')}
                    icon={BsFlag}
                    error={errors.loadingFromCountryId && "From Country is required"}
                >
                    <Dropdown
                        className='px-3 py-2'
                        placeholder={`${t('select')} ${t('fromCountry')}`}
                        options={countries}
                        formData={register('loadingFromCountryId', { required: true, validate: value => value !== 'null' })}
                    />
                </AddFreightLabelWithInput>

                {
                    watchAsapLoading === false &&
                    <>
                        <AddFreightLabelWithInput
                            label={t('fromDate')}
                            icon={SlCalender}
                            error={errors.loadingFromDate && "From Date is required"}
                        >
                            <DatePicker
                                className='py-2'
                                formData={register('loadingFromDate', { required: watchAsapLoading === false ? true : false })}
                            />
                        </AddFreightLabelWithInput>
                        <AddFreightLabelWithInput
                            label={t('toDate')}
                            icon={SlCalender}
                            error={errors.loadingToDate && errors.loadingToDate.type === "validate" ? "To Date must be greater than From Date" : errors.loadingToDate && "To Date is required"}
                        >
                            <DatePicker
                                className='py-2'
                                formData={register('loadingToDate', { required: watchAsapLoading === false ? true : false, validate: value => value >= watchLoadingFromDate })}
                            />
                        </AddFreightLabelWithInput>
                        <AddFreightLabelWithInput
                            label={t('between')}
                            icon={AiOutlineClockCircle}
                            error={errors.loadingBetween && "Please select a valid hour"}
                        >
                            <Dropdown
                                className='py-2 px-3'
                                placeholder={`${t('select')} ${t('hour')}`}
                                options={hourArrayData}
                                formData={register('loadingBetween', { required: watchAsapLoading === false ? true : false, validate: value => value !== "null" })}
                            />
                        </AddFreightLabelWithInput>
                        <AddFreightLabelWithInput
                            label={t('and')}
                            icon={AiOutlineClockCircle}
                            error={errors.loadingAnd && "Please select a valid hour"}
                        >
                            <Dropdown
                                className='py-2 px-3'
                                placeholder={`${t('select')} ${t('hour')}`}
                                options={hourArrayData}
                                formData={register('loadingAnd', { required: watchAsapLoading === false ? true : false, validate: value => value !== "null" })}
                            />
                        </AddFreightLabelWithInput>
                    </>
                }
            </NewFreightContainer>
            <NewFreightContainer title={t('unloadingDetails')}>
                <AddFreightLabelWithInput
                    label={t('directDelivery')}
                    icon={BsTruck}
                >
                    <div className='mt-3'>
                        <CheckboxWithIcon
                            formData={register('directDelivery')}
                        />
                    </div>
                </AddFreightLabelWithInput>
                <AddFreightLabelWithInput
                    label={t('toCountry')}
                    icon={BsFlag}
                    error={errors.unloadingToCountryId && "To Country is required"}
                >
                    <Dropdown
                        className='px-3 py-2'
                        placeholder={`${t('select')} ${t('toCountry')}`}
                        options={countries}
                        formData={register('unloadingToCountryId', { required: true, validate: value => value !== 'null' })}
                    />
                </AddFreightLabelWithInput>
                {
                    watchDirectDelivery === false &&
                    <>
                        <AddFreightLabelWithInput
                            label={t('fromDate')}
                            icon={SlCalender}
                            error={errors.unloadingFromDate && "From Date is required"}
                        >
                            <DatePicker
                                className='py-2'
                                formData={register('unloadingFromDate', { required: watchDirectDelivery === false ? true : false })}
                            />
                        </AddFreightLabelWithInput>
                        <AddFreightLabelWithInput
                            label={t('toDate')}
                            icon={SlCalender}
                            error={errors.unloadingToDate && errors.unloadingToDate.type === "validate" ? "To Date must be greater than From Date" : errors.unloadingToDate && "To Date is required"}
                        >
                            <DatePicker
                                className='py-2'
                                formData={register('unloadingToDate', { required: watchDirectDelivery === false ? true : false, validate: value => value >= watchUnloadingFromDate })}
                            />
                        </AddFreightLabelWithInput>
                        <AddFreightLabelWithInput
                            label={t('between')}
                            icon={AiOutlineClockCircle}
                            error={errors.unloadingBetween && "Please select a valid hour"}
                        >
                            <Dropdown
                                className='py-2 px-3'
                                placeholder={`${t('select')} ${t('hour')}`}
                                options={hourArrayData}
                                formData={register('unloadingBetween', { required: watchDirectDelivery === false ? true : false, validate: value => value !== "null" })}
                            />
                        </AddFreightLabelWithInput>
                        <AddFreightLabelWithInput
                            label={t('and')}
                            icon={AiOutlineClockCircle}
                            error={errors.unloadingAnd && "Please select a valid hour"}
                        >
                            <Dropdown
                                className='py-2 px-3'
                                placeholder={`${t('select')} ${t('hour')}`}
                                options={hourArrayData}
                                formData={register('unloadingAnd', { required: watchDirectDelivery === false ? true : false, validate: value => value !== "null" })}
                            />
                        </AddFreightLabelWithInput></>
                }
            </NewFreightContainer>
            <NewFreightContainer title={t('transportDetails')}>
                <AddFreightLabelWithInput
                    label={t('paymentDeadline')}
                    icon={BsTruck}
                    error={errors.paymentDeadlineId && "Payment Deadline is required"}
                >
                    <Dropdown
                        className='py-2 px-3'
                        placeholder={`${t('select')} ${t('paymentDeadline')}`}
                        options={paymentDeadlines}
                        formData={register('paymentDeadlineId', { required: true, validate: value => value !== "null" })}
                    />
                </AddFreightLabelWithInput>
                <AddFreightLabelWithInput
                    label={t('carType')}
                    icon={BsTruck}
                    error={errors.carTypeId && "Car Type is required"}
                >
                    <Dropdown
                        className='py-2 px-3'
                        placeholder={`${t('select')} ${t('carType')}`}
                        options={carTypes}
                        formData={register('carTypeId', { required: true, validate: value => value !== "null" })}
                    />
                </AddFreightLabelWithInput>
                <AddFreightLabelWithInput
                    label={t('transportType')}
                    icon={BsTruck}
                    error={errors.transportTypeId && "Transport Type is required"}
                >
                    <Dropdown
                        className='py-2 px-3'
                        placeholder={`${t('select')} ${t('transportType')}`}
                        options={transportTypes}
                        formData={register('transportTypeId', { required: true, validate: value => value !== "null" })}
                    />
                </AddFreightLabelWithInput>
                <AddFreightLabelWithInput
                    label={t('distanceInKm')}
                    icon={BsTruck}
                    error={errors.distance && errors.distance.type === "min" ? "Distance must be greater or equal to 0" : errors.distance && "Distance is required"}
                >
                    <InputField
                        className='px-3 py-2'
                        placeholder={t('distanceInKm')}
                        type='Number'
                        formData={register('distance', { required: true, min: 0 })}
                    />
                </AddFreightLabelWithInput>
                <AddFreightLabelWithInput
                    label={t('suggestedPrice')}
                    icon={BsTruck}
                    error={errors.suggestedPrice && errors.suggestedPrice.type === "min" ? "Suggested Price must be greater or equal to 0" : errors.suggestedPrice && "Suggested Price is required"}
                >
                    <InputField
                        className='px-3 py-2'
                        placeholder={t('suggestedPrice')}
                        type='Number'
                        formData={register('suggestedPrice', { required: true, min: 0 })}
                    />
                </AddFreightLabelWithInput>
                <AddFreightLabelWithInput
                    label={t('currency')}
                    icon={BsTruck}
                    error={errors.currencyId && "Currency is required"}
                >
                    <Dropdown
                        className='py-2 px-3'
                        placeholder={`${t('select')} ${t('currency')}`}
                        options={currencies}
                        formData={register('currencyId', { required: true, validate: value => value !== "null" })}
                    />
                </AddFreightLabelWithInput>
                <AddFreightLabelWithInput
                    label={t('vatIncluded')}
                    icon={BsTruck}
                    error={errors.vatIncluded && "Vat Included is required"}
                >
                    <Dropdown
                        className='py-2 px-3'
                        placeholder={`${t('select')} ${t('vatIncluded')}`}
                        options={[
                            { id: 'yes', title: 'Yes' },
                            { id: 'no', title: 'No' }
                        ]}
                        formData={register('vatIncluded', { required: true, validate: value => value !== "null" })}
                    />
                </AddFreightLabelWithInput>
                <AddFreightLabelWithInput
                    label={t('showPhone')}
                    icon={BsTruck}
                >
                    <div className='mt-3'>
                        <CheckboxWithIcon
                            formData={register('showPhone')}
                        />
                    </div>
                </AddFreightLabelWithInput>
                <AddFreightLabelWithInput
                    label={t('countryCode')}
                    icon={BsTruck}
                    error={errors.countryCodeId && "Country Code is required"}
                >
                    <Dropdown
                        className='py-2 px-3'
                        placeholder={`${t('select')} ${t('countryCode')}`}
                        options={countryCodes}
                        formData={register('countryCodeId', { required: watchShowPhone || watchPhone?.length, validate: value => (watchShowPhone || watchPhone?.length) ? value !== "null" : true })}
                    />
                </AddFreightLabelWithInput>
                <AddFreightLabelWithInput
                    label={t('phone')}
                    icon={BsFlag}
                    error={errors.phone && "Phone is required"}
                >
                    <InputField
                        className='px-3 py-2'
                        placeholder={t('phone')}
                        formData={register('phone', { required: watchShowPhone === true ? true : false })}
                    />
                </AddFreightLabelWithInput>
            </NewFreightContainer>
            <NewFreightContainer title={t('observations')}>
                <AddFreightLabelWithInput
                    label={t('weightInTons')}
                    icon={BsTruck}
                    error={errors.weight && errors.weight.type === "min" ? "Weight must be greater or equal to 0" : errors.weight && "Weight is required"}
                >
                    <InputField
                        className='px-3 py-2'
                        placeholder={t('weightInTons')}
                        type='Number'
                        formData={register('weight', { required: true, min: 0 })}
                    />
                </AddFreightLabelWithInput>
                <AddFreightLabelWithInput
                    label={t('articlesNoType')}
                    icon={BsTruck}
                >
                    <InputField
                        className='px-3 py-2'
                        placeholder={t('articlesNoType')}
                        type='Number'
                        formData={register('articles')}
                    />
                </AddFreightLabelWithInput>
                <AddFreightLabelWithInput
                    label={t('volumeInM3')}
                    icon={BsTruck}
                    error={errors.volume && "Volume must be greater or equal to 0"}
                >
                    <InputField
                        className='px-3 py-2'
                        placeholder={t('volumeInM3')}
                        type='Number'
                        formData={register('volume', { min: 0 })}
                    />
                </AddFreightLabelWithInput>
                <AddFreightLabelWithInput
                    label={t('referenceNo')}
                    icon={BsTruck}
                >
                    <InputField
                        className='px-3 py-2'
                        placeholder={t('referenceNo')}
                        type='Number'
                        formData={register('referenceNo')}
                    />
                </AddFreightLabelWithInput>
                <div className='flex flex-col lg:flex-row flex-1 justify-between my-2 lg:my-3'>
                    <div className='flex flex-row items-center justify-between'>
                        <span>
                            {t('thermo')}
                        </span>
                        <CheckboxWithIcon
                            icon={IconOne}
                            className='fill-[#03a9f0] mx-2'
                            formData={register('specialRequirementOne')}
                        />
                    </div>
                    <div className='flex flex-row items-center justify-between'>
                        <span>
                            {t('dangerous')}
                        </span>
                        <CheckboxWithIcon
                            icon={IconTwo}
                            className='fill-[red] mx-2'
                            formData={register('specialRequirementTwo')}
                        />
                    </div>
                    <div className='flex flex-row items-center justify-between'>
                        <span>
                            {t('cargoLift')}
                        </span>
                        <CheckboxWithIcon
                            icon={IconThree}
                            className='fill-[orange] mx-2'
                            formData={register('specialRequirementThree')}
                        />
                    </div>
                </div>
                <AddFreightLabelWithInput
                    label={t('observations')}
                    icon={BsTruck}
                >
                    <TextArea
                        className='px-3 py-2'
                        placeholder={t('observations')}
                        formData={register('observations')}
                    />
                </AddFreightLabelWithInput>
                <div className='flex justify-center mt-5'>
                    <Button
                        className='px-3 py-2'
                        title={t('update')}
                        onClick={handleSubmit(submitForm)}
                    />
                </div>
            </NewFreightContainer>
        </div >

    );
};

export default EditFreight;