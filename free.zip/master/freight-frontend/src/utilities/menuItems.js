import { AiOutlineHome, AiOutlineProfile, AiOutlineLock, AiOutlineEye } from 'react-icons/ai';
import { VscAccount } from 'react-icons/vsc';
import { RxDashboard } from 'react-icons/rx';
import { BsBox } from 'react-icons/bs';
import { FiTruck } from 'react-icons/fi';
import { BsInfoCircle } from 'react-icons/bs';
import { GiWorld } from 'react-icons/gi';
import { RiWechatLine } from 'react-icons/ri';

export const profileMenuGeneral = [
    {
        id: 1,
        name: 'myAccount',
        icon: AiOutlineHome,
        link: '/my-account'
    },
    {
        id: 2,
        name: 'companyProfile',
        icon: AiOutlineProfile,
        link: '/company-profile'
    },
    {
        id: 5,
        name: 'logout',
        icon: AiOutlineLock,
        link: '/log-in'
    }
];

export const profileMenuExpeditor = [
    {
        id: 1,
        name: 'myAccount',
        icon: AiOutlineHome,
        link: '/my-account'
    },
    {
        id: 2,
        name: 'companyProfile',
        icon: AiOutlineProfile,
        link: '/company-profile'
    },
    {
        id: 3,
        name: 'addUser',
        icon: VscAccount,
        link: '/add-user'
    },
    {
        id: 4,
        name: 'listUser',
        icon: VscAccount,
        link: '/list-user'
    },
    {
        id: 5,
        name: 'logout',
        icon: AiOutlineLock,
        link: '/log-in'
    }
];

export const sidebarItemsTransporterPrimaryUser = [
    {
        id: 1,
        name: 'home',
        link: '/'
    },
    {
        id: 2,
        name: 'manageFreight',
        subItems: [
            {
                id: 21,
                name: 'followedFreights',
                link: '/followed-freights'
            },
            {
                id: 22,
                name: 'myOffers',
                link: '/my-offers'
            },
            {
                id: 23,
                name: 'activeTransports',
                link: '/active-transports'
            },
            {
                id: 24,
                name: 'completedTransports',
                link: '/completed-transports'
            }
        ]
    },
    {
        id: 3,
        name: 'myTrucks',
        subItems: [
            {
                id: 31,
                name: 'addTruck',
                link: '/add-truck'
            },
            {
                id: 32,
                name: 'listTrucks',
                link: '/list-trucks'
            }
        ]
    },
    {
        id: 4,
        name: 'about',
        link: '/about'
    },
    {
        id: 5,
        name: 'map',
        link: '/map'
    },
    {
        id: 6,
        name: 'support',
        link: '/support'
    },
];

export const sidebarItemsTransporter = [
    {
        id: 1,
        name: 'home',
        link: '/'
    },
    {
        id: 2,
        name: 'manageFreight',
        subItems: [
            {
                id: 21,
                name: 'followedFreights',
                link: '/followed-freights'
            },
            {
                id: 22,
                name: 'myOffers',
                link: '/my-offers'
            },
            {
                id: 23,
                name: 'activeTransports',
                link: '/active-transports'
            },
            {
                id: 24,
                name: 'completedTransports',
                link: '/completed-transports'
            }
        ]
    },
    {
        id: 3,
        name: 'myTrucks',
        subItems: [
            {
                id: 32,
                name: 'listTrucks',
                link: '/list-trucks'
            }
        ]
    },
    {
        id: 4,
        name: 'about',
        link: '/about'
    },
    {
        id: 5,
        name: 'map',
        link: '/map'
    },
    {
        id: 6,
        name: 'support',
        link: '/support'
    },
];

export const sidebarItemsExpeditorPrimaryUser = [
    {
        id: 1,
        name: 'home',
        link: '/'
    },
    {
        id: 2,
        name: 'manageFreight',
        subItems: [
            {
                id: 21,
                name: 'newFreight',
                link: '/new-freight'
            },
            {
                id: 22,
                name: 'myFreights',
                link: '/my-freights'
            },
            {
                id: 23,
                name: 'activeFreights',
                link: '/active-freights'
            },
            {
                id: 24,
                name: 'completedFreights',
                link: '/completed-freights'
            }
        ]
    },
    {
        id: 3,
        name: 'freightLive',
        link: '/freight-live'
    },
    {
        id: 4,
        name: 'about',
        link: '/about'
    },
    {
        id: 5,
        name: 'map',
        link: '/map'
    },
    {
        id: 6,
        name: 'support',
        link: '/support'
    },
];

export const sidebarItemsExpeditor = [
    {
        id: 1,
        name: 'home',
        link: '/'
    },
    {
        id: 2,
        name: 'manageFreight',
        subItems: [
            {
                id: 21,
                name: 'newFreight',
                link: '/new-freight'
            },
            {
                id: 22,
                name: 'myFreights',
                link: '/my-freights'
            },
            {
                id: 23,
                name: 'activeFreights',
                link: '/active-freights'
            },
            {
                id: 24,
                name: 'completedFreights',
                link: '/completed-freights'
            }
        ]
    },
    {
        id: 3,
        name: 'freightLive',
        link: '/freight-live'
    },
    {
        id: 4,
        name: 'about',
        link: '/about'
    },
    {
        id: 5,
        name: 'map',
        link: '/map'
    },
    {
        id: 6,
        name: 'support',
        link: '/support'
    },
];

export const desktopSidebarItemsTransporterPrimaryUser = [
    {
        id: 1,
        name: 'home',
        icon: RxDashboard,
        link: '/'
    },
    {
        id: 2,
        name: 'manageFreight',
        icon: BsBox,
        subItems: [
            {
                id: 21,
                name: 'followedFreights',
                link: '/followed-freights'
            },
            {
                id: 22,
                name: 'myOffers',
                link: '/my-offers'
            },
            {
                id: 23,
                name: 'activeTransports',
                link: '/active-transports'
            },
            {
                id: 24,
                name: 'completedTransports',
                link: '/completed-transports'
            }
        ]
    },
    {
        id: 3,
        name: 'myTrucks',
        icon: FiTruck,
        subItems: [
            {
                id: 31,
                name: 'addTruck',
                link: '/add-truck'
            },
            {
                id: 32,
                name: 'listTrucks',
                link: '/list-trucks'
            }
        ]
    },
    {
        id: 4,
        name: 'about',
        icon: BsInfoCircle,
        link: '/about'
    },
    {
        id: 5,
        name: 'map',
        icon: GiWorld,
        link: '/map'
    },
    {
        id: 6,
        name: 'support',
        icon: RiWechatLine,
        link: '/support'
    },
];

export const desktopSidebarItemsTransporter = [
    {
        id: 1,
        name: 'home',
        icon: RxDashboard,
        link: '/'
    },
    {
        id: 2,
        name: 'manageFreight',
        icon: BsBox,
        subItems: [
            {
                id: 21,
                name: 'followedFreights',
                link: '/followed-freights'
            },
            {
                id: 22,
                name: 'myOffers',
                link: '/my-offers'
            },
            {
                id: 23,
                name: 'activeTransports',
                link: '/active-transports'
            },
            {
                id: 24,
                name: 'completedTransports',
                link: '/completed-transports'
            }
        ]
    },
    {
        id: 4,
        name: 'about',
        icon: BsInfoCircle,
        link: '/about'
    },
    {
        id: 5,
        name: 'map',
        icon: GiWorld,
        link: '/map'
    },
    {
        id: 6,
        name: 'support',
        icon: RiWechatLine,
        link: '/support'
    },
];

export const desktopSidebarItemsExpeditor = [
    {
        id: 1,
        name: 'home',
        icon: RxDashboard,
        link: '/'
    },
    {
        id: 2,
        name: 'manageFreight',
        icon: BsBox,
        subItems: [
            {
                id: 21,
                name: 'newFreight',
                link: '/new-freight'
            },
            {
                id: 22,
                name: 'myFreights',
                link: '/my-freights'
            },
            {
                id: 23,
                name: 'activeFreights',
                link: '/active-freights'
            },
            {
                id: 24,
                name: 'completedFreights',
                link: '/completed-freights'
            }
        ]
    },
    {
        id: 3,
        name: 'freightLive',
        icon: AiOutlineEye,
        link: '/freight-live'
    },
    {
        id: 4,
        name: 'about',
        icon: BsInfoCircle,
        link: '/about'
    },
    {
        id: 5,
        name: 'map',
        icon: GiWorld,
        link: '/map'
    },
    {
        id: 6,
        name: 'support',
        icon: RiWechatLine,
        link: '/support'
    },
];

export const desktopSidebarItemsExpeditorPrimaryUser = [
    {
        id: 1,
        name: 'home',
        icon: RxDashboard,
        link: '/'
    },
    {
        id: 2,
        name: 'manageFreight',
        icon: BsBox,
        subItems: [
            {
                id: 21,
                name: 'newFreight',
                link: '/new-freight'
            },
            {
                id: 22,
                name: 'myFreights',
                link: '/my-freights'
            },
            {
                id: 23,
                name: 'activeFreights',
                link: '/active-freights'
            },
            {
                id: 24,
                name: 'completedFreights',
                link: '/completed-freights'
            }
        ]
    },
    {
        id: 3,
        name: 'freightLive',
        icon: AiOutlineEye,
        link: '/freight-live'
    },
    {
        id: 4,
        name: 'about',
        icon: BsInfoCircle,
        link: '/about'
    },
    {
        id: 5,
        name: 'map',
        icon: GiWorld,
        link: '/map'
    },
    {
        id: 6,
        name: 'support',
        icon: RiWechatLine,
        link: '/support'
    },
];

export const hourArray = () =>
    [...Array(24).keys()].map((item, index) => (
        {
            id: `${index < 10 ? `0${index}` : index}:00`,
            title: `${index < 10 ? `0${index}` : index}:00`
        }
    ));
