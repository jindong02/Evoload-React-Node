const carTypeRoute = require('./carTypeRoute');
const companyRoute = require('./companyRoute');
const countryRoute = require('./countryRoute');
const countryCodeRoute = require('./countryCodeRoute');
const currencyRoute = require('./currencyRoute');
const freightRoute = require('./freightRoute');
const freightStatusRoute = require('./freightStatusRoute');
const offerRoute = require('./offerRoute');
const paymentDeadlineRoute = require('./paymentDeadlineRoute');
const supportCategoryRoute = require('./supportCategoryRoute');
const supportRequestRoute = require('./supportRequestRoute');
const transportRoute = require('./transportRoute');
const transportTypeRoute = require('./transportTypeRoute');
const truckRoute = require('./truckRoute');
const userRoute = require('./userRoute');
const userTypeRoute = require('./userTypeRoute');

module.exports = {
    carTypeRoute,
    companyRoute,
    countryRoute,
    countryCodeRoute,
    currencyRoute,
    freightRoute,
    freightStatusRoute,
    offerRoute,
    paymentDeadlineRoute,
    supportCategoryRoute,
    supportRequestRoute,
    transportRoute,
    transportTypeRoute,
    truckRoute,
    userRoute,
    userTypeRoute
};