const { sequelize } = require("../configs/dbConfig");
const { DataTypes } = require("sequelize");

const Freight = sequelize.define(
    "Freight",
    {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
        },
        loading_asap_loading: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: false
        },
        loading_from_date: {
            type: DataTypes.DATE,
        },
        loading_to_date: {
            type: DataTypes.DATE,
        },
        loading_between: {
            type: DataTypes.TIME,
        },
        loading_and: {
            type: DataTypes.TIME,
        },
        unloading_direct_delivery: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: false
        },
        unloading_from_date: {
            type: DataTypes.DATE,
        },
        unloading_to_date: {
            type: DataTypes.DATE,
        },
        unloading_between: {
            type: DataTypes.TIME,
        },
        unloading_and: {
            type: DataTypes.TIME,
        },
        distance: {
            type: DataTypes.DOUBLE,
            allowNull: false,
        },
        suggested_price: {
            type: DataTypes.DOUBLE,
            allowNull: false,
        },
        vat_included: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: false
        },
        phone: {
            type: DataTypes.STRING,
        },
        show_phone: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
        },
        weight: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        articles: {
            type: DataTypes.STRING,
        },
        volume: {
            type: DataTypes.DOUBLE,
        },
        reference: {
            type: DataTypes.INTEGER
        },
        observations: {
            type: DataTypes.STRING(1000),
        },
        transporter_review_stars: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        transporter_review: {
            type: DataTypes.STRING(1000),
            allowNull: true,
        },
        transporter_review_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        expeditor_review_stars: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        expeditor_review: {
            type: DataTypes.STRING(1000),
            allowNull: true,
        },
        expeditor_review_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        status: {
            type: DataTypes.ENUM,
            allowNull: false,
            values: ['opened', 'closed', 'offered', 'pending', 'started', 'completed', 'cancelled'],
            defaultValue: 'opened'
        },
        soft_delete: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: false
        }
    },
    {
        tableName: "freights",
        freezeTableName: true,
        underscored: true,
        createdAt: 'created_at',
        updatedAt: 'updated_at'
    },

);
// sync force
// Freight.sync({ force: true });
module.exports = Freight;