const Joi = require("joi");
const { type } = require("./constantValues");

module.exports.isValidCreateCarTypeObject = (data) => {
    const schema = Joi.object({
        title: Joi.string().required(),
    });
    const { error, value } = schema.validate(data);
    return { error, value };
};

module.exports.isValidRegisterUserObject = (data) => {
    const schema = Joi.object({
        title: Joi.string().required(),
        owner: Joi.string().required(),
        streetAndNumber: Joi.string().required(),
        countryId: Joi.number().required(),
        city: Joi.string().required(),
        vatNumber: Joi.string().required(),
        userTypeId: Joi.number().required(),
        firstName: Joi.string().required(),
        surname: Joi.string().required(),
        countryCodeId: Joi.number().required(),
        phone: Joi.string().required(),
        email: Joi.string().email().required(),
        username: Joi.string().required(),
        password: Joi.string().required(),
        type: Joi.string().valid(type.expeditor, type.transporter).required(),
    });
    const { error, value } = schema.validate({
        ...data,
        type: parseInt(data.userTypeId) === 1 ? type.expeditor : type.transporter,
        countryCodeId: parseInt(data.countryCodeId),
        userTypeId: parseInt(data.userTypeId),
        countryId: parseInt(data.countryId),
    });
    return { error, value };
};

module.exports.isValidLoginUserObject = (data) => {
    const schema = Joi.object({
        username: Joi.string().required(),
        password: Joi.string().required(),
    });
    const { error, value } = schema.validate(data);
    return { error, value };
};

module.exports.isValidCreateSupportRequestObject = (data) => {
    const schema = Joi.object({
        firstName: Joi.string().required(),
        surname: Joi.string().required(),
        email: Joi.string().email().required(),
        subject: Joi.string().required(),
        message: Joi.string().required(),
        supportCategoryId: Joi.number().required(),
        companyId: Joi.number().required(),
        userId: Joi.number().required(),
    });
    const { error, value } = schema.validate({
        ...data,
        supportCategoryId: parseInt(data.supportCategoryId),
        companyId: parseInt(data.companyId),
        userId: parseInt(data.userId),
    });
    return { error, value };
};

module.exports.isValidCreateTruckObject = (data) => {
    const schema = Joi.object({
        licenseNumber: Joi.string().required(),
        length: Joi.number().required(),
        width: Joi.number().required(),
        height: Joi.number().required(),
        firstName: Joi.string().required(),
        surname: Joi.string().required(),
        phone: Joi.string().required(),
        email: Joi.string().email().required(),
        username: Joi.string().required(),
        password: Joi.string().required(),
        type: Joi.string().valid(type.transporter).required(),
        carTypeId: Joi.number().required(),
        userTypeId: Joi.number().required(),
        countryCodeId: Joi.number().required(),
        companyId: Joi.number().required(),
        userId: Joi.number().required(),
    });
    const { error, value } = schema.validate({
        ...data,
        type: type.transporter,
        carTypeId: parseInt(data.carTypeId),
        userTypeId: parseInt(data.userTypeId),
        countryCodeId: parseInt(data.countryCodeId),
        companyId: parseInt(data.companyId),
        userId: parseInt(data.userId),
    });
    return { error, value };
};

module.exports.isValidUpdateUserObject = (data) => {
    const schema = Joi.object({
        firstName: Joi.string().required(),
        surname: Joi.string().required(),
        function: Joi.string(),
        phone: Joi.string().required(),
        email: Joi.string().email().required(),
        username: Joi.string().required(),
        password: Joi.string(),
        countryCodeId: Joi.number().required(),
    });
    const { error, value } = schema.validate({
        ...data,
        countryCodeId: parseInt(data.countryCodeId),
    });
    return { error, value };
};

module.exports.isValidCreateUserObject = (data) => {
    const schema = Joi.object({
        firstName: Joi.string().required(),
        surname: Joi.string().required(),
        phone: Joi.string().required(),
        email: Joi.string().email().required(),
        username: Joi.string().required(),
        password: Joi.string().required(),
        type: Joi.string().valid(type.expeditor).required(),
        countryCodeId: Joi.number().required(),
        userTypeId: Joi.number().required(),
        companyId: Joi.number().required(),
    });
    const { error, value } = schema.validate({
        ...data,
        type: type.expeditor,
        countryCodeId: parseInt(data.countryCodeId),
        userTypeId: parseInt(data.userTypeId),
        companyId: parseInt(data.companyId),
    });
    return { error, value };
};

module.exports.isValidCreateFreightObject = (data) => {
    const schema = Joi.object({
        loadingAsapLoading: Joi.boolean().required(),
        directDelivery: Joi.boolean().required(),
        paymentDeadlineId: Joi.number().required(),
        carTypeId: Joi.number().required(),
        transportTypeId: Joi.number().required(),
        distance: Joi.number().required().min(0),
        suggestedPrice: Joi.number().required().min(0),
        currencyId: Joi.number().required(),
        vatIncluded: Joi.boolean().required(),
        weight: Joi.number().required().min(0),
        articles: Joi.string().allow(null, ""),
        volume: Joi.number().allow(null, 0).min(0),
        referenceNo: Joi.number().allow(null),
        specialRequirementOne: Joi.boolean(),
        specialRequirementTwo: Joi.boolean(),
        specialRequirementThree: Joi.boolean(),
        observations: Joi.string().allow(null, ""),
        showPhone: Joi.boolean().required(),
        phone: data.showPhone ? Joi.string().required() : Joi.string().allow(null, ""),
        loadingFromDate: data.loadingAsapLoading ? Joi.string().allow(null) : Joi.date().required(),
        loadingToDate: data.loadingAsapLoading ? Joi.string().allow(null) : Joi.date().required().min(Joi.ref('loadingFromDate')),
        loadingBetween: data.loadingAsapLoading ? Joi.string().allow(null) : Joi.string().required(),
        loadingAnd: data.loadingAsapLoading ? Joi.string().allow(null) : Joi.string().required(),
        unloadingFromDate: data.directDelivery ? Joi.string().allow(null) : Joi.date().required(),
        unloadingToDate: data.directDelivery ? Joi.string().allow(null) : Joi.date().required().min(Joi.ref('unloadingFromDate')),
        unloadingBetween: data.directDelivery ? Joi.string().allow(null) : Joi.string().required(),
        unloadingAnd: data.directDelivery ? Joi.string().allow(null) : Joi.string().required(),
        loadingFromCountryId: Joi.number().required(),
        unloadingToCountryId: Joi.number().required(),
        paymentDeadlineId: Joi.number().required(),
        carTypeId: Joi.number().required(),
        transportTypeId: Joi.number().required(),
        currencyId: Joi.number().required(),
        countryCodeId: Joi.number().required().allow(null),
        companyId: Joi.number().required(),
        userId: Joi.number().required(),
    });
    const { error, value } = schema.validate({
        ...data,
        loadingFromDate: data.loadingAsapLoading ? null : new Date(data.loadingFromDate),
        loadingToDate: data.loadingAsapLoading ? null : new Date(data.loadingToDate),
        loadingBetween: data.loadingAsapLoading ? null : data.loadingBetween,
        loadingAnd: data.loadingAsapLoading ? null : data.loadingAnd,
        unloadingFromDate: data.directDelivery ? null : new Date(data.unloadingFromDate),
        unloadingToDate: data.directDelivery ? null : new Date(data.unloadingToDate),
        unloadingBetween: data.directDelivery ? null : data.unloadingBetween,
        unloadingAnd: data.directDelivery ? null : data.unloadingAnd,
        vatIncluded: data.vatIncluded === 'yes' ? true : false,
        referenceNo: data.referenceNo ? parseInt(data.referenceNo) : null,
        volume: data.volume ? parseInt(data.volume) : null,
        loadingFromCountryId: parseInt(data.loadingFromCountryId),
        unloadingToCountryId: parseInt(data.unloadingToCountryId),
        paymentDeadlineId: parseInt(data.paymentDeadlineId),
        carTypeId: parseInt(data.carTypeId),
        transportTypeId: parseInt(data.transportTypeId),
        currencyId: parseInt(data.currencyId),
        countryCodeId: parseInt(data.countryCodeId) || null,
        companyId: parseInt(data.companyId),
        userId: parseInt(data.userId),
    });
    return { error, value };
};

module.exports.isValidCreateOfferObject = (data) => {
    const schema = Joi.object({
        directDelivery: Joi.boolean().required(),
        offerPrice: Joi.number().required().min(0),
        vatIncluded: Joi.boolean().required(),
        loadingDate: Joi.date().required(),
        loadingHour: Joi.string().required(),
        unloadingDate: data.directDelivery ? Joi.date().allow(null) : Joi.date().required().min(Joi.ref('loadingDate')),
        unloadingHour: data.directDelivery ? Joi.string().allow(null) : Joi.string().required(),
        details: Joi.string().allow(null, ""),
        currencyId: Joi.number().required(),
        freightId: Joi.number().required(),
        companyId: Joi.number().required(),
        userId: Joi.number().required(),
    });
    const { error, value } = schema.validate({
        ...data,
        loadingDate: new Date(data.loadingDate),
        unloadingDate: data.directDelivery ? null : new Date(data.unloadingDate),
        unloadingHour: data.directDelivery ? null : data.unloadingHour,
        vatIncluded: data.vatIncluded === 'yes' ? true : false,
        currencyId: parseInt(data.currencyId),
        freightId: parseInt(data.freightId),
        companyId: parseInt(data.companyId),
        userId: parseInt(data.userId),
    });
    return { error, value };
};

module.exports.isValidEditOfferObject = (data) => {
    const schema = Joi.object({
        directDelivery: Joi.boolean().required(),
        offerPrice: Joi.number().required().min(0),
        vatIncluded: Joi.boolean().required(),
        loadingDate: Joi.date().required(),
        loadingHour: Joi.string().required(),
        unloadingDate: data.directDelivery ? Joi.date().allow(null) : Joi.date().required().min(Joi.ref('loadingDate')),
        unloadingHour: data.directDelivery ? Joi.string().allow(null) : Joi.string().required(),
        details: Joi.string().allow(null, ""),
        currencyId: Joi.number().required(),
    });
    const { error, value } = schema.validate({
        ...data,
        loadingDate: new Date(data.loadingDate),
        unloadingDate: data.directDelivery ? null : new Date(data.unloadingDate),
        unloadingHour: data.directDelivery ? null : data.unloadingHour,
        vatIncluded: data.vatIncluded === 'yes' ? true : false,
        currencyId: parseInt(data.currencyId),
    });
    return { error, value };
};

module.exports.isValidCreateFollowerObject = (data) => {
    const schema = Joi.object({
        freightId: Joi.number().required(),
        userId: Joi.number().required(),
        companyId: Joi.number().required(),
    });
    const { error, value } = schema.validate({
        freightId: parseInt(data.freightId),
        userId: parseInt(data.userId),
        companyId: parseInt(data.companyId),
    });
    return { error, value };
};

module.exports.isValidAcceptOfferObject = (data) => {
    const schema = Joi.object({
        offerId: Joi.number().required(),
    });
    const { error, value } = schema.validate({
        offerId: parseInt(data.offerId),
    });
    return { error, value };
};

module.exports.isValidSetTruckForFreightObject = (data) => {
    const schema = Joi.object({
        truckId: Joi.number().required(),
    });
    const { error, value } = schema.validate({
        truckId: parseInt(data.truckId),
    });
    return { error, value };
};

module.exports.isValidUpdateFreightStatusObject = (data) => {
    const schema = Joi.object({
        offerId: Joi.number().required(),
        freightStatusId: Joi.number().required(),
    });
    const { error, value } = schema.validate({
        offerId: parseInt(data.offerId),
        freightStatusId: parseInt(data.freightStatusId),
    });
    return { error, value };
};

module.exports.isValidAddExpeditorReviewObject = (data) => {
    const schema = Joi.object({
        expeditorReviewStars: Joi.number().required().max(5).min(1),
        expeditorReview: Joi.string().allow(null, ""),
    });
    const { error, value } = schema.validate({
        ...data,
        expeditorReviewStars: parseInt(data.expeditorReviewStars),
    });
    return { error, value };
};

module.exports.isValidAddTransporterReviewObject = (data) => {
    const schema = Joi.object({
        transporterReviewStars: Joi.number().required().max(5).min(1),
        transporterReview: Joi.string().allow(null, ""),
    });
    const { error, value } = schema.validate({
        ...data,
        transporterReviewStars: parseInt(data.transporterReviewStars),
    });
    return { error, value };
};

module.exports.isValidEditFreightObject = (data) => {
    const schema = Joi.object({
        loadingAsapLoading: Joi.boolean().required(),
        directDelivery: Joi.boolean().required(),
        paymentDeadlineId: Joi.number().required(),
        carTypeId: Joi.number().required(),
        transportTypeId: Joi.number().required(),
        distance: Joi.number().required().min(0),
        suggestedPrice: Joi.number().required().min(0),
        currencyId: Joi.number().required(),
        vatIncluded: Joi.boolean().required(),
        weight: Joi.number().required().min(0),
        articles: Joi.string().allow(null, ""),
        volume: Joi.number().allow(null, 0).min(0),
        referenceNo: Joi.number().allow(null),
        specialRequirementOne: Joi.boolean(),
        specialRequirementTwo: Joi.boolean(),
        specialRequirementThree: Joi.boolean(),
        observations: Joi.string().allow(null, ""),
        showPhone: Joi.boolean().required(),
        phone: data.showPhone ? Joi.string().required() : Joi.string().allow(null, ""),
        loadingFromDate: data.loadingAsapLoading ? Joi.string().allow(null) : Joi.date().required(),
        loadingToDate: data.loadingAsapLoading ? Joi.string().allow(null) : Joi.date().required().min(Joi.ref('loadingFromDate')),
        loadingBetween: data.loadingAsapLoading ? Joi.string().allow(null) : Joi.string().required(),
        loadingAnd: data.loadingAsapLoading ? Joi.string().allow(null) : Joi.string().required(),
        unloadingFromDate: data.directDelivery ? Joi.string().allow(null) : Joi.date().required(),
        unloadingToDate: data.directDelivery ? Joi.string().allow(null) : Joi.date().required().min(Joi.ref('unloadingFromDate')),
        unloadingBetween: data.directDelivery ? Joi.string().allow(null) : Joi.string().required(),
        unloadingAnd: data.directDelivery ? Joi.string().allow(null) : Joi.string().required(),
        loadingFromCountryId: Joi.number().required(),
        unloadingToCountryId: Joi.number().required(),
        paymentDeadlineId: Joi.number().required(),
        carTypeId: Joi.number().required(),
        transportTypeId: Joi.number().required(),
        currencyId: Joi.number().required(),
        countryCodeId: Joi.number().required().allow(null),
    });
    const { error, value } = schema.validate({
        ...data,
        loadingFromDate: data.loadingAsapLoading ? null : new Date(data.loadingFromDate),
        loadingToDate: data.loadingAsapLoading ? null : new Date(data.loadingToDate),
        loadingBetween: data.loadingAsapLoading ? null : data.loadingBetween,
        loadingAnd: data.loadingAsapLoading ? null : data.loadingAnd,
        unloadingFromDate: data.directDelivery ? null : new Date(data.unloadingFromDate),
        unloadingToDate: data.directDelivery ? null : new Date(data.unloadingToDate),
        unloadingBetween: data.directDelivery ? null : data.unloadingBetween,
        unloadingAnd: data.directDelivery ? null : data.unloadingAnd,
        vatIncluded: data.vatIncluded === 'yes' ? true : false,
        referenceNo: data.referenceNo ? parseInt(data.referenceNo) : null,
        volume: data.volume ? parseInt(data.volume) : null,
        loadingFromCountryId: parseInt(data.loadingFromCountryId),
        unloadingToCountryId: parseInt(data.unloadingToCountryId),
        paymentDeadlineId: parseInt(data.paymentDeadlineId),
        carTypeId: parseInt(data.carTypeId),
        transportTypeId: parseInt(data.transportTypeId),
        currencyId: parseInt(data.currencyId),
        countryCodeId: parseInt(data.countryCodeId) || null,
    });
    return { error, value };
};