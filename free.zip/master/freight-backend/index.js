const express = require('express');
const app = express();
const cors = require("cors");
const morgan = require("morgan");
const cookieParser = require('cookie-parser')
require("dotenv").config();

const { connectToDatabase } = require("./configs/dbConfig");
const {
    carTypeRoute,
    companyRoute,
    countryRoute,
    userTypeRoute,
    userRoute,
    supportCategoryRoute,
    supportRequestRoute,
    truckRoute,
    currencyRoute,
    transportTypeRoute,
    paymentDeadlineRoute,
    freightRoute,
    offerRoute,
    transportRoute,
    freightStatusRoute,
    countryCodeRoute
} = require("./routes");
const { modelService, ExpressError } = require('./utilities');

const PORT = process.env.PORT || 3000;
const STAGE = process.env.STAGE || "dev";

app.use(cookieParser());
app.use(morgan('dev', { skip: (req, res) => STAGE !== 'dev' }));
app.use(cors({
    origin: true,
    credentials: true,
    exposedHeaders: 'Authorization',
}));
app.use(express.json({ limit: "30mb", extended: true }));
app.use(express.urlencoded({ limit: "30mb", extended: true }));

app.use('/car-types', carTypeRoute);
app.use('/companies', companyRoute);
app.use('/countries', countryRoute);
app.use('/country-codes', countryCodeRoute);
app.use('/currencies', currencyRoute);
app.use('/freights', freightRoute);
app.use('/freight-statuses', freightStatusRoute);
app.use('/offers', offerRoute);
app.use('/payment-deadlines', paymentDeadlineRoute);
app.use('/support-categories', supportCategoryRoute);
app.use('/support-requests', supportRequestRoute);
app.use('/transports', transportRoute);
app.use('/transport-types', transportTypeRoute);
app.use('/trucks', truckRoute);
app.use('/users', userRoute);
app.use('/user-types', userTypeRoute);

app.get('/', (req, res) => {
    res.send('Server is running');
});

app.use("*", (req, res, next) => {
    next(new ExpressError(404, "Page not found"));
});

app.use((err, req, res, next) => {
    if (err.name && err.name.includes('Sequelize'))
        err.message = err.errors?.length && err.errors[0]?.message || "Database Error";
    const { statusCode = 500, message = "Internal Server Error" } = err;
    modelService.errorResponse(res, statusCode, message);
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT} : http://localhost:${PORT}`);
});
connectToDatabase();


