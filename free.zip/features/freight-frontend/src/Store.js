import { configureStore } from "@reduxjs/toolkit";
import sidebarReducer from "./slices/sidebarSlice";
import notificationReducer from "./slices/notificationSlice";
import authSlice from "./slices/authSlice";
import companySlice from "./slices/companySlice";
import languageSlice from "./slices/languageSlice";

export const store = configureStore({
  reducer: {
    sidebar: sidebarReducer,
    notification: notificationReducer,
    auth: authSlice,
    company: companySlice,
    language: languageSlice,
  },
});