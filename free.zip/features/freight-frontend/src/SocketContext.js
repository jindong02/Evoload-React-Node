import React, { createContext } from "react";

const socket = "";
const SocketContext = createContext(socket);

export default SocketContext;
