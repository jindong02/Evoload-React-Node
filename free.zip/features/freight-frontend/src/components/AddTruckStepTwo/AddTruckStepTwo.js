import React, { useEffect } from 'react';
import AddTruckLabelWithInput from '../AddTruckLabelWithInput/AddTruckLabelWithInput';
import InputField from '../InputField/InputField';
import Button from '../Button/Button';
import { useForm } from 'react-hook-form';
import InputError from '../InputError/InputError';
import { useTranslation } from 'react-i18next';

const AddTruckStepTwo = (props) => {
    const { t } = useTranslation();
    const {
        register,
        handleSubmit,
        formState: { errors },
        reset
    } = useForm({
        defaultValues: {
            ...props.data
        }
    });

    const handleSubmitForm = (data) => {
        props.updateData(data);
        props.changeStep(3);
    };

    useEffect(() => {
        if (props.reset.includes(2)) {
            reset({
                length: '',
                width: '',
                height: ''
            });
            props.setReset((prev) => prev.filter(r => r !== 2));
        }
    }, [props.reset]);

    return (
        <div className='flex flex-col bg-white drop-shadow-lg rounded p-5 w-full lg:w-1/2 mx-auto'>
            <p className='my-5 text-center text-2xl'>
                {t('loadingSurface')}
            </p>
            <AddTruckLabelWithInput label={t('length')}>
                <InputField
                    placeholder={t('length')}
                    className='px-3 py-2'
                    formData={register('length', { required: true, pattern: /^\d*\.?\d*$/ })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.length && (errors.length.type === 'required' ? 'Length is required' : 'Length must be a number')}
                />
            </AddTruckLabelWithInput>
            <AddTruckLabelWithInput label={t('width')}>
                <InputField
                    placeholder={t('width')}
                    className='px-3 py-2'
                    formData={register('width', { required: true, pattern: /^\d*\.?\d*$/ })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.width && (errors.width.type === 'required' ? 'Width is required' : 'Width must be a number')}
                />
            </AddTruckLabelWithInput>
            <AddTruckLabelWithInput label={t('height')}>
                <InputField
                    placeholder={t('height')}
                    className='px-3 py-2'
                    formData={register('height', { required: true, pattern: /^\d*\.?\d*$/ })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.height && (errors.height.type === 'required' ? 'Height is required' : 'Height must be a number')}
                />
            </AddTruckLabelWithInput>
            <div className='my-5 flex justify-center'>
                <Button
                    className='px-5 py-2 mr-2'
                    title={t('previous')}
                    onClick={() => props.changeStep(1)}
                />
                <Button
                    className='px-5 py-2'
                    title={t('next')}
                    onClick={handleSubmit(handleSubmitForm)}
                />
            </div>
        </div>
    );
};

export default AddTruckStepTwo;