import React from 'react';

const Tooltip = (props) => {
    return (
        <span className="group-hover:opacity-100 transition-opacity bg-gray-800 py-1 px-2 text-sm text-gray-100 rounded-md absolute left-1/2
        -translate-x-1/2 translate-y-1 opacity-0">
            {props.title}
        </span>
    );
};

export default Tooltip;