import React from 'react';
import { BsStarFill, BsStarHalf, BsStar } from 'react-icons/bs';

const ShowStarts = ({ rating, large }) => {
    const size = large ? 24 : 16;
    const margin = large ? 'mx-2' : 'mr-1';

    return (
        <div className='flex flex-row my-1'>
            {
                [...Array(5)].map((star, index) => {
                    const ratingValue = index + 1;
                    return (
                        rating >= ratingValue ?
                            <BsStarFill
                                key={index}
                                className={`fill-yellow-500 ${margin}`}
                                size={size}
                            /> :
                            rating >= ratingValue - 0.5 ?
                                <BsStarHalf
                                    key={index}
                                    className={`fill-yellow-500 ${margin}`}
                                    size={size}
                                />
                                :
                                <BsStar
                                    key={index}
                                    className={`fill-yellow-500 ${margin}`}
                                    size={size}
                                />
                    )
                })
            }
        </div>
    );
};

export default ShowStarts;