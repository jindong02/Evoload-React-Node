import React from 'react';
import Button from '../Button/Button';
import prettyDate from '../../utilities/prettyDate';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

const ActiveFreightsCard = (props) => {
    const { t } = useTranslation();
    const navigate = useNavigate();
    return (
        <div className='flex flex-row justify-between py-3 bg-white my-5 lg:my-2 w-full'>
            <div className='w-3/12 p-3'>
                <div className='flex flex-col lg:flex-row justify-between'>
                    <div className='flex flex-row'>
                        <div className={`w-14 h-10 mr-2 bg-flag1 flex items-center justify-center text-white text-2xl font-bold`}>
                            {props?.item?.freights_from?.title[0]}
                        </div>
                        <div>
                            <p className='text-primary font-bold'>{props?.item?.freights_from?.title}</p>
                            <p className='text-secondary'>{props?.item?.loading_asap_loading ? 'ASAP' : `${t('at')} ${new Date(props?.item?.loading_from_date).toLocaleDateString()} ${t('to')} ${new Date(props?.item?.loading_to_date).toLocaleDateString()}`}</p>
                        </div>
                    </div>
                    <p className='text-secondary'>
                        {props?.item?.load?.postCode}
                    </p>
                </div>
                <div className='mt-4'>
                    <p className='text-secondary'>{props?.item?.CarType?.title}</p>
                    <p className='text-secondary'>No.Art.: {props?.item?.articles} / {t('weight')}:  {props?.item?.weight}</p>
                </div>
            </div>
            <div className='w-3/12 p-3'>
                <div className='flex flex-row'>
                    <div className='flex flex-row'>
                        <div className={`w-14 h-10 mr-2 bg-flag1 flex items-center justify-center text-white text-2xl font-bold`}>
                            {props?.item?.freights_to?.title[0]}
                        </div>
                        <div>
                            <p className='text-primary font-bold'>{props?.item?.freights_to?.title}</p>
                            <p className='text-secondary'>{props?.item?.unloading_direct_delivery ? 'Direct Delivery' : `${t('at')} ${new Date(props?.item?.unloading_from_date).toLocaleDateString()} ${t('to')} ${new Date(props?.item?.unloading_to_date).toLocaleDateString()}`}</p>
                        </div>
                    </div>
                </div>
                <div className='mt-4'>
                    <p className='text-secondary'>
                        {t('distance')}: {props?.item?.distance}km
                        {
                            props?.item?.volume && <span>
                                <span className='mx-2'>| {t('volume')}: {props?.item?.volume}m3</span>
                            </span>
                        }
                    </p>
                    <p className='text-secondary'>{t('publishedOn')}: {prettyDate(props?.item?.created_at)}</p>
                    <p className='text-secondary'>{props?.item?.TransportType?.title}</p>
                    <Button
                        title={t('showInfo')}
                        className='p-1 text-xs block mt-2'
                        onClick={() => navigate(`/freights/${props?.item?.id}`)}
                    />
                </div>
            </div>
            <div className='w-4/12 p-3'>
                <p className='text-primary font-bold'>{props?.item?.status.toUpperCase()}</p>
                {
                    props?.item?.Truck?.license_number &&
                    <div className='pt-1 text-sm'>
                        <p className='text-primary'>{t('driverName')}: {props?.item?.Truck?.driver?.full_name}</p>
                        <p className='text-primary'>{t('licenseNumber')}: : {props?.item?.Truck?.license_number}</p>
                        <p className='text-primary'>{t('phone')}: {props?.item?.Truck?.driver?.phone}</p>
                    </div>
                }
                {
                    props?.item?.freight_statuses?.length > 0 &&
                    <div className='pt-1 text-sm'>
                        {
                            props?.item?.freight_statuses?.map((item, index) => (
                                <p className='text-primary font-bold'>{item?.title} : {new Date(item?.freight_freight_status?.created_at).toLocaleString()}</p>
                            ))
                        }
                    </div>
                }
            </div>
            <div className='w-2/12 p-3'>
                <div className='flex flex-col flex-wrap justify-center items-center'>
                    <Button
                        className='px-2 py-1 mb-2 text-sm text-center'
                        title={t('viewDetails')}
                        onClick={() => navigate(`/offers/${props?.item?.offer_id}`)}
                    />
                    {
                        props?.item?.status === 'pending' &&
                        <Button
                            className='px-2 py-1 mb-2 text-sm bg-green-600'
                            title={t('startTransport')}
                            onClick={() => props.handleStart(props?.item?.id)}
                        />
                    }
                    {/* {
                        props?.item?.status === 'started' && */}
                        <Button
                            className='px-2 py-1 mb-2 text-sm bg-green-600'
                            title={t('finishTransport')}
                            onClick={() => props.handleFinish(props?.item?.id)}
                        />
                    {/* } */}
                    {props?.item?.status === 'offered' &&
                        <Button
                            className='px-2 py-1 mb-2 text-sm bg-red-600'
                            title={t('cancelTransport')}
                            onClick={() => props.cancelFreight(props?.item?.id)}
                        />
                    }
                </div>
            </div>
        </div >
    );
};

export default ActiveFreightsCard;