import React from 'react';

const Dropdown = (props) => {
    return (
        <select
            className={`w-full border bg-white border-slate-300 rounded focus:border-sky-500 focus:ring-sky-500 focus:outline-none focus:ring-1 shadow-sm text-sm cursor-pointer ${props.className}`}
            name={props.name}
            disabled={props.disabled}
            {...props.formData}
        >
            <option className='text-base' value="null">
                {props.placeholder}
            </option>
            {props.options?.length &&
                props.options.map((option, index) => {
                    return (
                        <option className='text-base' key={index} value={option.id}>{option.title}</option>
                    )
                })
            }

        </select>
    );
};

export default Dropdown;