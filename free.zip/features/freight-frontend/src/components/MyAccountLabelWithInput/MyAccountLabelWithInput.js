import React from 'react';

const MyAccountLabelWithInput = (props) => {
    return (
        <div className='flex flex-col lg:flex-row w-full mt-5'>
            <p className='w-full lg:w-1/4 text-left lg:text-right lg:mr-3 font-semibold lg:mt-2'>
                {props.title}
            </p>
            <div className='w-full lg:w-3/4 text-primary mt-2 lg:mt-0'>
                {
                    props.children
                }
            </div>
        </div>
    );
};

export default MyAccountLabelWithInput;