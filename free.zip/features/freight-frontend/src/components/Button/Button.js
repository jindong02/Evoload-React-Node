import React from 'react';

const Button = (props) => {
    return (
        <button
            className={`flex flex-row items-center bg-btnPrimary text-btnPrimaryText select-none ${props.className}`}
            onClick={props.onClick}
        >
            {
                props.icon &&
                <props.icon
                    className={`mr-2 ${props.iconClassName}`}
                    size={props.iconSize}
                />
            }
            <span className={`${props.textClassName}`}>
                {props.title}
            </span>
        </button>
    );
};

export default Button;