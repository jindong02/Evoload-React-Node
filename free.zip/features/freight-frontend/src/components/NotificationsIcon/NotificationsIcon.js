import React, { useState, useEffect } from "react";
import { FiBell } from "react-icons/fi";
import "../../Bell.css";
import { addNotification } from "../../slices/notificationSlice";
import axiosInstance from "../../axiosInstance";
import { useDispatch, useSelector } from "react-redux";
import SocketContext from "../../SocketContext";
import { useContext } from "react";
import { CgClose } from "react-icons/cg";

const NotificationsIcon = ({ freightData }) => {
  const [showNotification, setShowNotification] = useState(false);
  const [socketData, setSocketData] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [clear, setClear] = useState(true);
  const [isOffer , setIsOffer] = useState(true);

  const socket = useContext(SocketContext);
  const { user } = useSelector(state => state.auth);

  const dispatch = useDispatch();

  const getNotifications = async () => {
    try {
      const { data: response } = await axiosInstance.get("/notifications");
      setNotifications(response.data);
      getisOffer();
    } catch (error) {
      dispatch(
        addNotification({ type: "error", message: error.response.data.message })
      );
    } 
    
  };

  async function getisOffer(){
    try{
      const { data: response } = await axiosInstance.post("/notifications/getOfferNotification",{
        user_id: 1
      });
      console.log(response.data);
      console.log(response.data);
      console.log(response.data.is_offer_notification + "++++++++++");
      console.log(response.data.user_id);
  
      if(response.data.is_offer_notification === 1){
        setIsOffer(true)
      } else{
        setIsOffer(false);
      }
    } catch(err){
      console.log(err)
    }
    
  }
 

  
  const toggleNotificationBox = () => {
    setShowNotification((prevShowNotification) => !prevShowNotification);
    getNotifications();
    removeDuplicates();
  };

 useEffect(() => {
  socket.on("offer", (data) => {
    console.log("Socket Data");
      setSocketData((prev) => [...prev, data]);
      console.log("This is data Now " + data);
      console.log(socketData)
  });

  socket.on("accept-offer", (data) => {
    console.log("Socket Data");
    setSocketData((prev) => [...prev, data]);
    console.log("This is data Now " + data);
    console.log(socketData)
  });

  socket.on("add-truck", (data) => {
    console.log("Socket Data");
    setSocketData((prev) => [...prev, data]);
    console.log("This is data Now " + data);
    console.log(socketData)
  });

  socket.on("finish-transport", (data) => {
    console.log("Socket Data");
    setSocketData((prev) => [...prev, data]);
    console.log("This is data Now " + data);
    console.log(socketData)
  });
 
 }, [])

 const removeDuplicates = () => {
  const uniqueData = socketData.filter(
    (item, index, arr) => arr.findIndex((el) => el.text === item.text) === index
  );

  setSocketData(uniqueData);
};
 
 

  

  // Function to clear all notifications
  const clearAllNotifications = async () => {
    try {

      const {
        data: response,
        data,
        status,
        message,
      } = await axiosInstance.post("/notifications/clearall", {
        user_id: user.id,
        notification_id: 1,
        is_clear: 1,
      });
      console.log(response.data);
    } catch (error) {
      dispatch(
        addNotification({ type: "error", message: error.response.data.message })
      );
    }

    setNotifications([]);
    setSocketData([]);
    setClear(false);
  };

  const notificationCount = notifications.length + socketData.length;

  return (
    <nav>
      <div
        className="notification-icon relative "
        onClick={toggleNotificationBox}
      >
        <FiBell size={34} className="mr-5 lg:mr-10 cursor-pointer relative" />
        {notificationCount > 0 && (
          <span className="notification-count ">
            {!clear ? 0 : notificationCount}
          </span>
        )}

        {showNotification && (
          <div className="notification-box h-[300px] w-[100px] overflow-auto  ">
            {notifications.length > 0 && (
              <div className="flex justify-end pb-4">
                {clear && (
                  <button
                    className="clear-all-button"
                    onClick={clearAllNotifications}
                  >
                    Clear All
                  </button>
                )}
              </div>
            )}
            {socketData.length > 0 &&
              clear &&
              socketData.map((notifications, index) => (
                <div key={index} className="notification-items relative ">
                  {notifications.text}
                  <CgClose className="absolute top-[-4px] right-0" />
                </div>
              ))}

            {!clear && (
              <div className="notification-item">No new notifications</div>
            )}
            {notifications.length === 0 && socketData.length === 0 ? (
              <div className="notification-item">No new notifications</div>
            ) : (
              clear &&
              notifications.map((notification, index) => (
                <div key={index} className="notification-item relative">
                  {notification.text}
                  <CgClose className="absolute top-[-4px] right-0" />
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </nav>
  );
};

export default NotificationsIcon;
