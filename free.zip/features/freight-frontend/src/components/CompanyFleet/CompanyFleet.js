import React, { useEffect, useState } from 'react';
import axiosInstance from '../../axiosInstance';
import { addNotification } from '../../slices/notificationSlice';
import { useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';

const CompanyFleet = ({ id }) => {
    const [fleet, setFleet] = useState([]);
    const { t } = useTranslation();
    const dispatch = useDispatch();

    const getCompanyFleet = async (id) => {
        try {
            const { data: response } = await axiosInstance.get(`/companies/${id}/fleet`);
            setFleet(response.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        if (id) {
            getCompanyFleet(id);
        }
    }, [id]);
    return (

        fleet ?
            <div className='my-5 border border-slate-300'>
                <div div className='bg-bgSecondary p-5 flex flex-col lg:flex-row' >
                    <p className='text-primary text-xl w-full'>
                        {t('fleet')}
                    </p>
                </div>
                <div className='bg-white p-5'>
                    {
                        fleet?.rows?.length &&
                        fleet?.rows?.map((item, index) => (
                            <div key={index} className='flex flex-col lg:flex-row justify-between'>
                                <p className='text-primary'>
                                    {item?.CarType?.title} :
                                </p>
                                <p className='text-primary'>
                                    {fleet?.count?.find((dt) => dt?.car_type_id === item?.CarType?.id)?.count}
                                </p>
                            </div>
                        ))
                    }
                </div>
            </div >
            :
            <></>
    );
};

export default CompanyFleet;