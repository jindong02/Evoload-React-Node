import React from 'react';
import Button from '../Button/Button';
import { useTranslation } from 'react-i18next';

const FreightOfferCard = (props) => {
    const { t } = useTranslation();
    return (
        <div className='flex flex-col lg:flex-row justify-between p-3 bg-white'>
            <div className='w-3/12 p-3'>
                <p className='text-blue-500 cursor-pointer select-none'>
                    {props?.item?.Company?.title}
                </p>
                <p>
                    {props?.item?.Company?.established_in && (`${t('companySinceYear')}: ${props?.item?.Company?.established_in},`)} {props?.item?.Company?.city}, {props?.item?.Company?.Country?.title}
                </p>
            </div>
            <div className='w-1/12 p-3'>
                {props?.item?.offer_price} {props?.item?.Currency?.title} <br /> {props?.item?.vat_included ? '' : '+ VAT'}
            </div>
            <div className='w-2/12 p-3'>
                <p>
                    {new Date(props?.item?.loading_date).toLocaleDateString()}, {props?.item?.loading_hour}
                </p>
            </div>
            <div className='w-2/12 p-3'>
                {
                    props?.item?.direct_delivery ?
                        <p>
                            Direct Delivery
                        </p>
                        :
                        <p>
                            {new Date(props?.item?.unloading_date).toLocaleDateString()}, {props?.item?.unloading_hour}
                        </p>
                }
            </div>
            <div className="w-2/12 p-3">
                <p>{new Date(props?.item?.created_at).toLocaleString()}</p>
            </div>
            <div className="w-2/12 p-3 flex flex-col justify-center items-center">
                {console.log(props?.item?.id)}
                <Button
                    className='px-2 py-1 text-sm bg-green-600 mb-2'
                    title={t('acceptOffer')}
                    onClick={() => props.acceptOffer(props?.item?.id)}
                />
                {
                    props?.item?.details === 'accepted' &&
                    <Button
                        className='px-2 py-1 text-sm mb-2'
                        title={t('extraDetails')}
                        onClick={() => props.openModal(props?.item)}
                    />
                }
            </div>
        </div>
    );
};

export default FreightOfferCard;