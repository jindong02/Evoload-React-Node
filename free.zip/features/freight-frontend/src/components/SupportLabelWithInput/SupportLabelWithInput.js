import React from 'react';

const SupportLabelWithInput = (props) => {
    return (
        <div className='flex flex-col lg:flex-row mt-3' >
            <div className='flex flex-1 w-full lg:w-2/6'>
                <p className='text-primary'>
                    {props.label}
                </p>
            </div>
            <div className='flex flex-row w-fill lg:w-4/6'>
                {props.children}
            </div>
        </div>
    );
};

export default SupportLabelWithInput;