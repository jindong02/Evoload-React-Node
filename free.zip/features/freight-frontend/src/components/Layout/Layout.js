import React, { useEffect, useState } from "react";
import Navbar from "../Navbar/Navbar";
import Sidebar from "../Sidebar/Sidebar";
import { Navigate, matchPath, useLocation } from "react-router-dom";
import jwt_decode from "jwt-decode";
import { useDispatch, useSelector } from "react-redux";
import axiosInstance from "../../axiosInstance";
import { saveAccessToken } from "../../slices/authSlice";
import {
  expeditor,
  expeditorPrimaryUser,
  transporter,
  transporterPrimaryUser,
  type,
} from "../../utilities/constantValues";
import SendVerificationCode from "../../pages/SendVerificationCode/SendVerificationCode";

const Layout = ({ children, freightData }) => {
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const { accessToken, user } = useSelector((state) => state.auth);

  const location = useLocation();
  const dispatch = useDispatch();

  const getAccessToken = async () => {
    try {
      const { data: response } = await axiosInstance.get(
        "/users/get-access-token"
      );
      if (response.data.accessToken) {
        dispatch(saveAccessToken(response.data.accessToken));
        setTimeout(() => {
          getAccessToken();
        }, 3000 * 1000);
      } else {
        return (
          <Navigate to="/log-in" state={{ from: location }} replace></Navigate>
        );
      }
    } catch (err) {
      console.log(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (accessToken) {
      const data = jwt_decode(accessToken);
      let isExist = false;
      if (data.type === type.expeditor) {
        if (data.is_primary_user) {
          for (let i = 0; i < expeditorPrimaryUser.length; i++) {
            if (matchPath(expeditorPrimaryUser[i], location.pathname)) {
              isExist = true;
              break;
            }
          }
        } else {
          for (let i = 0; i < expeditor.length; i++) {
            if (matchPath(expeditor[i], location.pathname)) {
              isExist = true;
              break;
            }
          }
        }
      } else {
        if (data.is_primary_user) {
          for (let i = 0; i < transporterPrimaryUser.length; i++) {
            if (matchPath(transporterPrimaryUser[i], location.pathname)) {
              isExist = true;
              break;
            }
          }
        } else {
          for (let i = 0; i < transporter.length; i++) {
            if (matchPath(transporter[i], location.pathname)) {
              isExist = true;
              break;
            }
          }
        }
      }
      if (isExist) {
        setIsAuthorized(true);
      } else {
        setIsAuthorized(false);
      }
    } else {
      setIsAuthorized(false);
    }
  }, [accessToken, location]);

  useEffect(() => {
    if (!accessToken) {
      getAccessToken();
    } else {
      setIsLoading(false);
    }
  }, []);

  if (isLoading) {
    return (
      <div className="absolute right-1/2 bottom-1/2  transform translate-x-1/2 translate-y-1/2 ">
        <div className="border-t-transparent border-solid animate-spin  rounded-full border-blue-400 border-4 h-12 w-12"></div>
      </div>
    );
  }

  if (accessToken) {
    const data = jwt_decode(accessToken);
    if (!data?.is_verified) {
      return (
        <Sidebar>
          <Navbar freightData={freightData} />
          <div className="pt-20 pb-5 px-5">
            <SendVerificationCode />
          </div>
        </Sidebar>
      );
    }
    if (isAuthorized) {
      return (
        <Sidebar>
          <Navbar freightData={freightData} />
          <div className="pt-20 pb-5 px-5">{children}</div>
        </Sidebar>
      );
    }
    return <Navigate to="/" state={{ from: location }} replace></Navigate>;
  }

  return <Navigate to="/log-in" state={{ from: location }} replace></Navigate>;
};

export default Layout;
