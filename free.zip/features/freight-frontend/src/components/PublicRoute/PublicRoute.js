import React from 'react';
import { useSelector } from 'react-redux';
import { Navigate, matchPath, useLocation } from 'react-router-dom';


const PublicRoute = (props) => {
    const { accessToken } = useSelector(state => state.auth);
    const location = useLocation();

    if (accessToken) {
        if (!matchPath("/verify-email", location.pathname)) {
            return <Navigate to="/" replace></Navigate>;
        } else {
            return <>{props.children}</>;
        }
    }

    return (
        <>
            {props.children}
        </>
    );
};

export default PublicRoute;