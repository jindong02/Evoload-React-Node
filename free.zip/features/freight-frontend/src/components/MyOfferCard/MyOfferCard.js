import React from 'react';
import Button from '../Button/Button';
import prettyDate from '../../utilities/prettyDate';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

const MyOfferCard = (props) => {
    const { t } = useTranslation();
    const navigate = useNavigate();

    return (
        <div className='flex flex-row justify-between p-3 bg-white my-5 lg:my-2'>
            <div className='w-3/12 p-3'>
                <div className='flex flex-col lg:flex-row justify-between'>
                    <div className='flex flex-row'>
                        <div className={`w-14 h-10 mr-2 bg-flag1 flex items-center justify-center text-white text-2xl font-bold`}>
                            {props?.item?.Freight?.freights_from?.title[0]}
                        </div>
                        <div>
                            <p className='text-primary font-bold'>{props?.item?.Freight?.freights_from?.title}</p>
                            <p className='text-secondary'>{props?.item?.Freight?.loading_asap_loading ? 'ASAP' : `${t('at')} ${new Date(props?.item?.Freight?.loading_from_date).toLocaleDateString()} ${t('to')} ${new Date(props?.item?.Freight?.loading_to_date).toLocaleDateString()}`}</p>
                        </div>
                    </div>
                    <p className='text-secondary'>
                        {props?.item?.load?.postCode}
                    </p>
                </div>
                <div className='mt-4'>
                    <p className='text-secondary'>{props?.item?.Freight?.CarType?.title}</p>
                    <p className='text-secondary'>No.Art.: {props?.item?.Freight?.articles} / {t('weight')}:  {props?.item?.Freight?.weight}</p>
                </div>
            </div>
            <div className='w-3/12 p-3'>
                <div className='flex flex-row'>
                    <div className='flex flex-row'>
                        <div className={`w-14 h-10 mr-2 bg-flag1 flex items-center justify-center text-white text-2xl font-bold`}>
                            {props?.item?.Freight?.freights_to?.title[0]}
                        </div>
                        <div>
                            <p className='text-primary font-bold'>{props?.item?.Freight?.freights_to?.title}</p>
                            <p className='text-secondary'>{props?.item?.Freight?.unloading_direct_delivery ? 'Direct Delivery' : `${t('at')} ${new Date(props?.item?.Freight?.unloading_from_date).toLocaleDateString()} ${t('to')} ${new Date(props?.item?.Freight?.unloading_to_date).toLocaleDateString()}`}</p>
                        </div>
                    </div>
                </div>
                <div className='mt-4'>
                    <p className='text-secondary'>
                        {t('distance')}: {props?.item?.Freight?.distance}km
                        {
                            props?.item?.Freight?.volume && <span>
                                <span className='mx-2'>| {t('volume')}: {props?.item?.Freight?.volume}m3</span>
                            </span>
                        }
                    </p>
                    <p className='text-secondary'>{t('publishedOn')}: {prettyDate(props?.item?.Freight?.created_at)}</p>
                    <p className='text-secondary'>{props?.item?.Freight?.TransportType?.title}</p>
                </div>
            </div>
            <div className='w-2/12 p-3'>
                <div className='flex flex-row'>
                    <p
                        className='text-btnPrimary cursor-pointer select-none'
                        onClick={() => navigate(`/companies/${props?.item?.Freight?.Company?.id}`)}
                    >
                        {props?.item?.Freight?.Company?.title}
                    </p>
                </div>
            </div>
            <div className='w-2/12 p-3'>
                <p className='text-primary font-bold mb-2'>
                    {props?.item?.status.toUpperCase()}
                </p>
                <p className='text-primary font-bold'>
                    {t('offeredPrice')}: <br /> {props?.item?.offer_price} {props?.item?.Currency?.title} {props?.item?.vat_included ? '' : '+ VAT'}
                </p>
            </div>
            <div className="w-2/12 p-3 flex flex-row">
                <div>
                    <Button
                        className='px-2 py-1 text-sm mr-2'
                        title={t('edit')}
                        onClick={() => navigate(`/my-offers/${props?.item?.id}/edit`)}
                    />
                </div>
                <div>
                    <Button
                        className='px-2 py-1 text-sm bg-red-600'
                        title={t('delete')}
                        onClick={() => props?.onDelete(props?.item?.id)}
                    />
                </div>
            </div>
        </div>
    );
};

export default MyOfferCard;