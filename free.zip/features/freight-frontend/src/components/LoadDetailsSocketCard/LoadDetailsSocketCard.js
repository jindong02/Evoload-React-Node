import React, { useState } from "react";
import Button from "../Button/Button";
import { AiFillStar } from "react-icons/ai";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../../axiosInstance";
import { addNotification } from "../../slices/notificationSlice";
import { useDispatch } from "react-redux";
import { type } from "../../utilities/constantValues";
import { useTranslation } from "react-i18next";

const LoadDetailsSocketCard = (props) => {
  const [hideFollow, setHideFollow] = useState(false);
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleFollowFreight = async (id) => {
    try {
      const { data: response } = await axiosInstance.post(
        `/freights/${id}/follow`
      );
      dispatch(addNotification({ type: "success", message: response.message }));
      setHideFollow(true);
    } catch (error) {
      dispatch(
        addNotification({ type: "error", message: error.response.data.message })
      );
    }
  };

  return (
    <div className="flex flex-col lg:flex-row justify-between p-3 bg-white my-5 lg:my-2 ">
      <div className="flex-1 p-3">
        <div className="flex flex-col lg:flex-row justify-between">
          <div className="block lg:hidden bg-bgPrimary p-3 mb-5 text-lg font-semibold text-primary">
            {t("load")}
          </div>
          <div className="flex flex-row">
            <div
              className={`w-14 h-10 mr-2 bg-flag1 flex items-center justify-center text-white text-2xl font-bold`}
            >
              {props?.item?.loadingFromCountryId === 1 ? "D" : "R"}
            </div>
            <div>
              <p className="text-primary font-bold">
                {props?.item?.loadingFromCountryId === 1
                  ? "Denmark"
                  : "Romania"}
              </p>
              <p className="text-secondary">
                {props?.item?.loadingAsapLoading
                  ? "ASAP"
                  : `${t("at")} ${new Date(
                      props?.item?.loading_from_date
                    ).toLocaleDateString()} ${t("to")} ${new Date(
                      props?.item?.loading_to_date
                    ).toLocaleDateString()}`}
              </p>
            </div>
          </div>
          <p className="text-secondary">{props?.item?.load?.postCode}</p>
        </div>
        <div className="mt-4">
          <p className="text-secondary">
            {props?.item?.carTypeId === 1 ? "Large Truck" : "Small Truck"}
          </p>
          <p className="text-secondary">
            No.Art.: {props?.item?.articles} / {t("weight")}:{" "}
            {props?.item?.weight}
          </p>
        </div>
      </div>
      <div className="flex-1 p-3">
        <div className="block lg:hidden bg-bgPrimary p-3 mb-5 text-lg font-semibold text-primary">
          {t("unload")}
        </div>
        <div className="flex flex-row">
          <div className="flex flex-row">
            <div
              className={`w-14 h-10 mr-2 bg-flag1 flex items-center justify-center text-white text-2xl font-bold`}
            >
              {props?.item?.freights_to === 1 ? "D" : "R"}
            </div>
            <div>
              <p className="text-primary font-bold">
                {props?.item?.freights_to === 1 ? "Denmark" : "Romania"}
              </p>
              <p className="text-secondary">
                {props?.item?.loadingAsapLoading
                  ? "Direct Delivery"
                  : `${t("at")} ${new Date(
                      props?.item?.unloading_from_date
                    ).toLocaleDateString()} ${t("to")} ${new Date(
                      props?.item?.unloading_to_date
                    ).toLocaleDateString()}`}
              </p>
            </div>
          </div>
        </div>
        <div className="mt-4">
          <p className="text-secondary">
            {t("distance")}: {props?.item?.distance}km
            {props?.item?.volume && (
              <span>
                <span className="mx-2">
                  | {t("volume")}: {props?.item?.volume}m3
                </span>
              </span>
            )}
          </p>
          <p className="text-secondary">
            {t("publishedOn")}: {props?.item?.publishedOn}
          </p>

          <p className="text-secondary">{props?.item?.TransportType?.title}</p>
          <Button
            title={t("showInfo")}
            className="p-1 text-xs block mt-2"
            onClick={() => navigate(`/freights/${props?.item?.userId}`)}
          />
        </div>
      </div>
      <div className="min-w-[25%] p-3">
        <div className="block lg:hidden bg-bgPrimary p-3 mb-5 text-lg font-semibold text-primary">
          {t("company")}
        </div>
        <div className="flex flex-row items-center">
          <div className="bg-blue-200 text-btnPrimaryText flex items-center justify-center w-14 h-10 mr-2">
            <p className="text-2xl font-semibold">
              {props?.item?.companyId == 1 ? "DC" : "FC"}
            </p>
          </div>
          <div>
            <p
              className="text-btnPrimary font-semibold select-none cursor-pointer"
              onClick={() => navigate(`/companies/${props?.item?.companyId}`)}
            >
              {props?.item?.companyId == 1 ? "DC" : "FC"}
            </p>
            {props?.item?.phone && (
              <p>
                {props?.item?.countryCodeId == 1 ? "+91" : "+880"}
                {props?.item?.phone}
              </p>
            )}
          </div>
        </div>
        <p className="mt-2 text-secondary">
          {t("price")}: {props?.item?.suggestedPrice}{" "}
          {props?.item?.currencyId == 1 ? "GBP" : "EUR"}{" "}
          {props?.item?.vatIncluded == true ? "+ VAT" : ""}
        </p>
        <p className="mt-1 text-secondary">
          {props?.item?.paymentDeadlineId == 1 ? "30 days" : "60 days"}
        </p>
        {props?.userData?.type === type.transporter && (
          <>
            <Button
              title={t("sendOffer")}
              className="p-1 text-xs block mt-2"
              onClick={() =>
                navigate(`/freights/${props?.item?.userId}/send-offer`)
              }
            />
            {!props?.hideFollow && !hideFollow && (
              <Button
                title={t("follow")}
                className="p-1 text-xs block mt-2"
                icon={AiFillStar}
                iconSize="12"
                iconClassName="mr-1 fill-[#FFC107]"
                onClick={() => handleFollowFreight(props?.item?.userId)}
              />
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default LoadDetailsSocketCard;
