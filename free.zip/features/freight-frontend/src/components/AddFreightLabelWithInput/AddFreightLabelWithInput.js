import React from 'react';
import InputError from '../InputError/InputError';

const AddFreightLabelWithInput = (props) => {
    return (
        <div className='flex flex-col lg:flex-row items-start justify-between mb-3'>
            <div className='w-full lg:w-1/3 flex flex-row items-center lg:pt-2'>
                {
                    props.icon && <props.icon size={16} />
                }
                <span className='ml-3'>
                    {props.label}
                </span>
            </div>
            <div className='w-full lg:w-2/3 mt-2 lg:mt-0'>
                {
                    props.children
                }
                {
                    props.error && <InputError className='py-1' error={props.error} />
                }
            </div>
        </div>
    );
};

export default AddFreightLabelWithInput;