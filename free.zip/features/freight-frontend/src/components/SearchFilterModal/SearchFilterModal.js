import React, { useState } from 'react';
import CheckboxWithIcon from '../CheckboxWithIcon/CheckboxWithIcon';
import DatePicker from '../DatePicker/DatePicker';
import Dropdown from '../Dropdown/Dropdown';
import InputField from '../InputField/InputField';
import Modal from '../Modal/Modal';
import { ReactComponent as IconOne } from '../../assets/icons/empire.svg';
import { ReactComponent as IconTwo } from '../../assets/icons/triangle-exclamation-solid.svg';
import { ReactComponent as IconThree } from '../../assets/icons/square-caret-up-regular.svg';
import Button from '../Button/Button';

const SearchFilterModal = (props) => {

    const [data, setData] = useState({
        fromCountry: '',
        fromPostCode: '',
        fromDateStart: '',
        fromDateEnd: '',
        toCountry: '',
        toPostCode: '',
        toDateStart: '',
        toDateEnd: '',
        carType: '',
        needRefrigerator: false,
        isHazardous: false,
        needLifting: false,
        radius: '',
    });

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setData({
            ...data,
            [name]: value
        });
    }

    return (
        <Modal
            title='Search'
            showModal={props.showSearchModal}
            setShowModal={props.setShowSearchModal}
        >
            <div>
                <div className='flex flex-col lg:flex-row py-3'>
                    <Dropdown
                        className='py-2 px-3 lg:mx-2 flex-1 my-1 lg:my-0'
                        placeholder='From Country'
                    />
                    <InputField
                        className='lg:mx-2 flex-1 py-2 px-3 my-1 lg:my-0'
                        placeholder='Postcode'
                        type='text'
                        name='fromPostCode'
                        value={data.fromPostCode}
                        onChange={handleInputChange}
                    />
                    <DatePicker
                        className='lg:mx-2 flex-1 my-1 lg:my-0'
                        placeholder='Date From'
                        name='fromDateStart'
                        value={data.fromDateStart}
                        onChange={handleInputChange}
                    />
                    <DatePicker
                        className='lg:mx-2 flex-1 my-1 lg:my-0'
                        placeholder='Date To'
                        name='fromDateEnd'
                        value={data.fromDateEnd}
                        onChange={handleInputChange}
                    />
                </div>
                <div className='flex flex-col lg:flex-row py-3'>
                    <Dropdown
                        className='py-2 px-3 lg:mx-2 flex-1 my-1 lg:my-0'
                        placeholder='To Country'
                    />
                    <InputField
                        className='lg:mx-2 flex-1 py-2 px-3 my-1 lg:my-0'
                        placeholder='Postcode'
                        type='text'
                        name='toPostCode'
                        value={data.toPostCode}
                        onChange={handleInputChange}
                    />
                    <DatePicker
                        className='lg:mx-2 flex-1 my-1 lg:my-0'
                        placeholder='Date From'
                        name='toDateStart'
                        value={data.toDateStart}
                        onChange={handleInputChange}
                    />
                    <DatePicker
                        className='lg:mx-2 flex-1 my-1 lg:my-0'
                        placeholder='Date To'
                        name='toDateEnd'
                        value={data.toDateEnd}
                        onChange={handleInputChange}
                    />
                </div>
                <div className='flex flex-col lg:flex-row py-3'>
                    <Dropdown
                        className='py-2 px-3 lg:mx-2 flex-1 my-1 lg:my-0'
                        placeholder='Car Type'
                    />
                    <div className='flex flex-row flex-1 justify-between lg:justify-center my-2 lg:my-0'>
                        <CheckboxWithIcon
                            icon={IconOne}
                            className='fill-[#03a9f0] mx-2'
                        />
                        <CheckboxWithIcon
                            icon={IconTwo}
                            className='fill-[red] mx-2'
                        />
                        <CheckboxWithIcon
                            icon={IconThree}
                            className='fill-[orange] mx-2'
                        />
                    </div>
                    <Dropdown
                        className='lg:mx-2 flex-1 py-2 px-3 my-1 lg:my-0'
                        placeholder='Radius'
                    />
                </div>
                <div className='flex flex-row py-3 px-2'>
                    <Button title='Search' className='px-2 py-1 lg:px-4 lg:py-3' />
                    <Button title='Reset' className='px-2 py-1 lg:px-4 lg:py-3 ml-2' />
                </div>
            </div>
        </Modal >
    );
};

export default SearchFilterModal;