import React, { useState } from 'react';
import Button from '../Button/Button';
import Modal from '../Modal/Modal';
import ShowStarts from '../ShowStarts/ShowStarts';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

const AcceptedOfferCard = (props) => {
    const [showModal, setShowModal] = useState(false);
    const { t } = useTranslation();
    const navigate = useNavigate();
    return (
        <div className='flex flex-col lg:flex-row justify-between py-3 bg-white my-5 lg:my-2'>
            <Modal
                title={t('offerDetails')}
                showModal={showModal}
                setShowModal={setShowModal}
            >
                <p className='text-center'>
                    {props?.item?.details?.length > 0 ? props?.item?.details : t('noDetailsProvided')}
                </p>
            </Modal>
            <div className='w-3/12 p-3'>
                <p
                    className='text-blue-500 cursor-pointer select-none font-semibold text-lg'
                    onClick={() => navigate(`/companies/${props?.item?.Freight?.Company?.id}`)}

                >
                    {props?.item?.Freight?.Company?.title}
                </p>
                <p>
                    {props?.item?.Freight?.Company?.established_in && (`${t('companySinceYear')} ${props?.item?.Freight?.Company?.established_in},`)} {props?.item?.Freight?.Company?.city}, {props?.item?.Freight?.Company?.Country?.title}
                </p>
                <ShowStarts rating={props?.item?.Freight?.Company?.total_review_count ? props?.item?.Freight?.Company?.total_star_count / props?.item?.Freight?.Company?.total_review_count : 0} />
                <p className='text-primary'>{props?.item?.Freight?.Company?.total_review_count} {t('reviews')}</p>
            </div>
            <div className='w-1/12 p-3'>
                {props?.item?.offer_price} {props?.item?.Currency?.title} {props?.item?.vat_included ? '' : '+ VAT'}
            </div>
            <div className='w-2/12 p-3'>
                <p>
                    {new Date(props?.item?.loading_date).toLocaleDateString()}, {props?.item?.loading_hour}
                </p>
            </div>
            <div className='w-2/12 p-3'>
                {
                    props?.item?.direct_delivery ?
                        <p>
                            Direct Delivery
                        </p>
                        :
                        <p>
                            {new Date(props?.item?.unloading_date).toLocaleDateString()}, {props?.item?.unloading_hour}
                        </p>
                }
            </div>
            <div className="w-2/12 p-3">
                <p>{new Date(props?.item?.created_at).toLocaleString()}</p>
            </div>
            <div className="w-2/12 p-3 flex flex-col items-center justify-start">
                <Button
                    className='px-2 py-1 text-sm mb-2'
                    title={t('viewDetails')}
                    onClick={() => setShowModal(true)}
                />
            </div>
        </div>
    );
};

export default AcceptedOfferCard;