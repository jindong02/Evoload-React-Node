import React from 'react';

const RegistrationLabelWithInput = (props) => {
    return (
        <div className='py-2 lg:pl-2 flex flex-col lg:flex-row  justify-center lg:justify-between items-center'>
            <label className='text-primary w-full lg:w-2/6'>{props.label}</label>
            <div className='w-full lg:w-4/6'>
                {props.children}
            </div>
        </div>
    );
};

export default RegistrationLabelWithInput;