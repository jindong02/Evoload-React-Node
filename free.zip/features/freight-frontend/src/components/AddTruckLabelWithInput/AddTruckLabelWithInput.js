import React from 'react';

const AddTruckLabelWithInput = (props) => {
    return (
        <div className='flex flex-col lg:flex-row flex-1 p-3'>
            <p className='font-semibold w-full lg:w-2/6 lg:mt-2'>
                {props.label}
            </p>
            <div className='flex-1 w-full'>
                {
                    props.children
                }
            </div>
        </div>
    );
};

export default AddTruckLabelWithInput;