import React from 'react';
import { RiTruckFill } from 'react-icons/ri';
import { type } from '../../utilities/constantValues';
import ShowStarts from '../ShowStarts/ShowStarts';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

const ReviewCard = (props) => {
    const { t } = useTranslation();
    const navigate = useNavigate();

    const formatDate = (date) => {
        return date.toISOString().split('T')[0];
    };

    return (
        <div className='flex flex-col lg:flex-row items-center bg-white border-2 lg:border-0 shadow-md lg:shadow-none mt-5 lg:mt-0 lg:mb-5'>
            <div
                className='bg-bgPrimary w-24 h-24 lg:h-20 flex items-center justify-center rounded-full m-5 cursor-pointer'
                onClick={() => navigate(`/companies/${props?.item?.Offer ? props?.item?.Offer?.Company?.id : props?.item?.Company?.id}`)}
            >
                <RiTruckFill size={56} />
            </div>
            <div className='bg-bgPrimary p-3 w-full'>
                <div className='flex flex-col lg:flex-row lg:justify-between lg:items-center mb-2'>
                    <p>
                        <span
                            className='text-btnPrimary font-semibold mr-2 cursor-pointer select-none'
                            onClick={() => navigate(`/companies/${props?.item?.Offer ? props?.item?.Offer?.Company?.id : props?.item?.Company?.id}`)}
                        >
                            {props?.item?.Offer ? props?.item?.Offer?.Company?.title : props?.item?.Company?.title}
                        </span>
                        <span className='text-primary text-sm'>
                            {props?.item?.Offer ? type.expeditor : type.transporter}
                        </span>
                    </p>
                    <p className='flex flex-col lg:flex-row lg:items-center mt-2 lg:mt-0'>
                        <ShowStarts rating={props?.item?.Offer ? props?.item?.expeditor_review_stars : props?.item?.transporter_review_stars} />
                        <span className='text-primary font-bold ml-1 text-sm'>{props?.item?.Offer ? props?.item?.expeditor_review_stars : props?.item?.transporter_review_stars}.0</span>
                        <span className='text-primary ml-1 text-sm'>
                            {t('on')} {props?.item?.Offer ? formatDate(new Date(props?.item?.expeditor_review_date)) : formatDate(new Date(props?.item?.transporter_review_date))}
                        </span>
                    </p>
                </div>
                <p className='mb-2 flex flex-col lg:flex-row'>
                    <span className='text-primary font-bold mr-2'>{props?.item?.TransportType?.title}</span>
                    <span className='text-primary '>{t('from')} {props?.item?.freights_from?.title} {t('to')} {props?.item?.freights_to?.title}</span>
                </p>
                <p className='italic text-primary'>
                    "{props?.item?.Offer ? props?.item?.expeditor_review : props?.item?.transporter_review}"
                </p>
            </div>
        </div>
    );
};

export default ReviewCard;