import React, { useEffect, useState } from 'react';
import { addNotification } from '../../slices/notificationSlice';
import axiosInstance from '../../axiosInstance';
import { useDispatch } from 'react-redux';
import ShowStarts from '../ShowStarts/ShowStarts';
import { useTranslation } from 'react-i18next';

const ReviewStats = ({ id, totalStarCount, totalReviewCount }) => {
    const [reviewStats, setReviewStats] = useState([]);
    const { t } = useTranslation();
    const dispatch = useDispatch();

    const getCompanyReviewStats = async (id) => {
        try {
            const { data: response } = await axiosInstance.get(`/companies/${id}/review-stats`);
            const result = [...Array(5).keys()].map((item, index) =>
            ({
                star: index + 1,
                count: response?.data?.count?.length ?
                    (response?.data?.count[0]?.transporter_review_stars ?
                        response?.data?.count?.find((item) => item?.transporter_review_stars === index + 1)?.count || 0
                        :
                        response?.data?.count?.find((item) => item?.expeditor_review_stars === index + 1)?.count) || 0
                    : 0

            }));
            setReviewStats([...result.reverse()]);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        if (id)
            getCompanyReviewStats(id);
    }, [id]);

    return (
        <div className='border border-slate-300'>
            <div className='bg-bgSecondary p-5 flex flex-col lg:flex-row'>
                <div className='text-primary text-xl w-full'>
                    <p>
                        {t('reviewStatistics')}
                    </p>
                    <span className='bg-primary text-white px-2 py-1 text-sm inline'>
                        {totalReviewCount} {t('reviews')}
                    </span>
                </div>
            </div>
            <div className='bg-white p-5'>
                <div className='bg-bgPrimary p-3 flex flex-col items-center justify-center'>
                    <p className='text-center text-6xl font-semibold text-primary mb-2'>
                        {(totalStarCount / totalReviewCount).toFixed(2) === 'NaN' ? '0.00' : (totalStarCount / totalReviewCount).toFixed(2)}
                    </p>
                    <ShowStarts rating={(totalStarCount / totalReviewCount).toFixed(2)} />
                </div>
                <div className='my-2 p-2'>
                    {
                        reviewStats.length ?
                            reviewStats.map((item, index) => (
                                <div key={index} className='flex justify-between items-center'>
                                    <p className='text-primary'>
                                        {item.star} Star
                                    </p>
                                    <ShowStarts rating={item.star} />
                                    <p className='text-primary'>
                                        {item.count}
                                    </p>
                                </div>
                            ))
                            :
                            <p className='text-primary'>
                                This user has not received any reviews yet
                            </p>
                    }
                </div>
            </div>
        </div>
    );
};

export default ReviewStats;