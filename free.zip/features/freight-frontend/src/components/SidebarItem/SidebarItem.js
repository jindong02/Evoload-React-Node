import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';

const SidebarItem = (props) => {
    const navigate = useNavigate();
    const { t } = useTranslation();

    const handleClick = (item) => {
        if (!item.subItems?.length) {
            navigate(item.link);
        }
        if (item.id === props.openItemId) {
            props.setOpenItemId(null);
            return;
        }
        props.setOpenItemId(item.id);
        if (!item.subItems?.length) {
            navigate(item.link);
        }
    };

    const handleSubItemClick = (subItem) => {
        props.setOpenItemId(null);
        navigate(subItem.link);
    };

    return (
        <div
            className='flex my-3 p-5 hover:bg-bgSecondary cursor-pointer relative select-none'
            onClick={() => handleClick(props.item)}
        >
            <span className='mr-5'>
                {
                    <props.item.icon size={24} />
                }
            </span>
            <span className='text-primary'>
                {t(props.item.name)}
            </span>
            {
                (props.item.subItems?.length && props.openItemId === props.item.id) &&
                <div className='absolute z-10 w-full top-14 -left-0 my-2 drop-shadow-md'>
                    {
                        props.item.subItems.map((subItem) => (
                            <div
                                key={subItem.id}
                                className='flex flex-row items-center bg-white cursor-pointer py-5 px-5 text-sm text-primary border-y-2 border-white hover:border-y-2 hover:border-slate-300'
                                onClick={() => handleSubItemClick(subItem)}
                            >
                                {t(subItem.name)}
                            </div>
                        ))
                    }
                </div>
            }
        </div>
    );
};

export default SidebarItem;