import { SlCalender } from 'react-icons/sl';

const DatePicker = (props) => {


    return (
        <div
            className={`flex flex-row items-center border border-slate-300 rounded py-1 px-3 focus-within:border-sky-500 focus-within:ring-sky-500 focus-within:outline-none focus-within:ring-1 shadow-sm select-none relative ${props.className}`}
        >
            {
                <span className='mr-3'>
                    <SlCalender
                        size={16}
                    />
                </span>
            }
            <input
                className="placeholder:text-slate-400 block bg-white w-full sm:text-sm focus:outline-none select-none"
                placeholder={props.placeholder}
                type='date'
                name={props.name}
                value={props.value}
                onChange={props.onChange}
                disabled={props.disabled}
                {...props.formData}
            />
            {
                !props.value &&
                <span className='absolute pl-7 text-slate-400 text-sm select-none'>
                    {props.placeholder}
                </span>
            }
        </div>
    );
};

export default DatePicker;