import React, { useEffect, useState } from 'react';
import axiosInstance from '../../axiosInstance';
import { addNotification } from '../../slices/notificationSlice';
import { useDispatch } from 'react-redux';
import { type } from '../../utilities/constantValues';
import { useTranslation } from 'react-i18next';

const CompletedTransportCount = (props) => {
    const [completedTransportData, setCompletedTransportData] = useState({});
    const { t } = useTranslation();
    const dispatch = useDispatch();

    const getCompletedTransportCount = async (id) => {
        try {
            const { data: response } = await axiosInstance.get(`/companies/${id}/completed-transport-count`);
            setCompletedTransportData(response.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        if (props.id)
            getCompletedTransportCount(props.id);
    }, [props.id]);

    return (
        <div className='border border-slate-300'>
            <div className='bg-bgSecondary p-5 flex flex-col lg:flex-row'>
                <p className='text-primary text-xl w-full'>
                    {t(completedTransportData?.type === type.expeditor ? 'completedShipments' : 'completedTransports')}
                </p>
            </div>
            <div className='bg-white p-5'>
                <p className='text-2xl'>
                    {completedTransportData?.count}
                </p>
            </div>
        </div>
    );
};

export default CompletedTransportCount;