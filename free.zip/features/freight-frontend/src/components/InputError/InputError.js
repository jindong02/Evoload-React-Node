import React from 'react';

const InputError = (props) => {
    return (
        <div className={`flex flex-col ${props.className}`}>
            {
                props.error &&
                <p className='text-red-500 text-xs italic'>
                    {props.error}
                </p>
            }
        </div>
    );
};

export default InputError;