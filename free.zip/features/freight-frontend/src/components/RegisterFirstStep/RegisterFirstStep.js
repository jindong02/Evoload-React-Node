import React, { useEffect, useState } from 'react';
import RegistrationLabelWithInput from '../RegistrationLabelWithInput/RegistrationLabelWithInput';
import InputField from '../InputField/InputField';
import InputError from '../InputError/InputError';
import { useForm } from 'react-hook-form';
import { BsBriefcaseFill } from 'react-icons/bs';
import Dropdown from '../Dropdown/Dropdown';
import Button from '../Button/Button';
import axiosInstance from '../../axiosInstance';
import { useDispatch } from 'react-redux';
import { addNotification } from '../../slices/notificationSlice';
import { useTranslation } from 'react-i18next';

const RegisterFirstStep = (props) => {
    const [countries, setCountries] = useState([]);
    const [userTypes, setUserTypes] = useState([]);
    const { t } = useTranslation();

    const dispatch = useDispatch();

    const {
        register,
        handleSubmit,
        formState: { errors },
    } = useForm();


    const handleSubmitForm = (data) => {
        props.updateData(data);
        props.changeStep(2);
    };

    const getAllCountries = async () => {
        try {
            const { data } = await axiosInstance.get('/countries?order=title&direction=asc');
            setCountries(data.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const getAllUserTypes = async () => {
        try {
            const { data } = await axiosInstance.get('/user-types?order=title&direction=asc');
            setUserTypes(data.data);
        } catch (err) {
            dispatch(addNotification({ type: "error", message: err.response.data.message }));
        }
    };

    useEffect(() => {
        getAllCountries();
        getAllUserTypes();
    }, []);

    return (
        <div className='pt-7 lg:pt-5'>
            <RegistrationLabelWithInput label={t('company')}>
                <InputField
                    placeholder={t('company')}
                    className='px-3 py-2'
                    icon={BsBriefcaseFill}
                    formData={register('title', { required: true })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.title && 'Company is required'}
                />
            </RegistrationLabelWithInput>
            <RegistrationLabelWithInput label={t('ownerDirector')}>
                <InputField
                    placeholder={t('ownerDirector')}
                    className='px-3 py-2'
                    icon={BsBriefcaseFill}
                    formData={register('owner', { required: true })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.owner && 'Owner/Director is required'}
                />
            </RegistrationLabelWithInput>
            <RegistrationLabelWithInput label={t('streetAndNumber')}>
                <InputField
                    placeholder={t('streetAndNumber')}
                    className='px-3 py-2'
                    icon={BsBriefcaseFill}
                    formData={register('streetAndNumber', { required: true })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.streetAndNumber && 'Street and Number is required'}
                />
            </RegistrationLabelWithInput>
            <RegistrationLabelWithInput label={t('country')}>
                <Dropdown
                    placeholder={`${t('select')} ${t('country')}`}
                    className='px-3 py-2'
                    icon={BsBriefcaseFill}
                    name='countryId'
                    options={countries}
                    formData={register('countryId', { required: true, validate: value => value !== "null" })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.countryId && 'Country is required'}
                />
            </RegistrationLabelWithInput>
            <RegistrationLabelWithInput label={t('city')}>
                <InputField
                    placeholder={t('city')}
                    className='px-3 py-2'
                    icon={BsBriefcaseFill}
                    formData={register('city', { required: true })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.city && 'City is required'}
                />
            </RegistrationLabelWithInput>
            <RegistrationLabelWithInput label={t('vatNumber')}>
                <InputField
                    placeholder={t('vatNumber')}
                    className='px-3 py-2'
                    icon={BsBriefcaseFill}
                    formData={register('vatNumber', { required: true })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.vatNumber && 'Vat Number is required'}
                />
            </RegistrationLabelWithInput>
            <RegistrationLabelWithInput label={t('userType')}>
                <Dropdown
                    placeholder={`${t('select')} ${t('userType')}`}
                    className='px-3 py-2'
                    icon={BsBriefcaseFill}
                    name='userTypeId'
                    options={userTypes}
                    formData={register('userTypeId', { required: true, validate: value => value !== "null" })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.userTypeId && 'User Type is required'}
                />
            </RegistrationLabelWithInput>
            <div className='flex justify-center lg:justify-end pt-7 lg:pt-10'>
                <div className='lg:w-4/6 lg:ml-5'>
                    <Button
                        title={t('nextStep')}
                        className='px-3 py-2 lg:ml-2 flex justify-center'
                        onClick={handleSubmit(handleSubmitForm)}
                    />
                </div>
            </div>
        </div>
    );
};

export default RegisterFirstStep;