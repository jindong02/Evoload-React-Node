import React from 'react';

const NewFreightContainer = (props) => {
    return (
        <div className='w-full lg:w-1/2 p-3'>
            <div className='p-5 bg-[#F8FBFF] text-xl'>
                {props.title}
            </div>
            <div className='bg-white p-5'>
                {props.children}
            </div>
        </div>
    );
};

export default NewFreightContainer;