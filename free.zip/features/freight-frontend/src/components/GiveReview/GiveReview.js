import React, { useEffect, useState } from 'react';
import Button from '../Button/Button';
import InputError from '../InputError/InputError';
import Modal from '../Modal/Modal';
import StarReview from '../StarReview/StarReview';
import TextArea from '../TextArea/TextArea';
import { useTranslation } from 'react-i18next';

const GiveReview = ({ title, item, type, onSave, showModal, setShowModal }) => {
    const [rating, setRating] = useState(0);
    const [review, setReview] = useState('');
    const [error, setError] = useState(false);
    const { t } = useTranslation();

    const handleSave = async () => {
        if (rating === 0) {
            setError(true);
            return;
        }
        let data = {};
        setShowModal(false);
        data.freightId = item?.id;
        if (type === 'transporter') {
            data.transporterReviewStars = rating;
            data.transporterReview = review;
        } else {
            data.expeditorReviewStars = rating;
            data.expeditorReview = review;
        }
        onSave(data);
    };

    useEffect(() => {
        if (showModal) {
            setRating(0);
            setReview('');
        }
    }, [showModal]);

    useEffect(() => {
        if (rating)
            setError(false);
    }, [rating]);

    return (
        <Modal
            title={title}
            showModal={showModal}
            setShowModal={setShowModal}
        >
            <div>
                <StarReview
                    rating={rating}
                    setRating={setRating}
                />
                <TextArea
                    className='mt-3 p-3'
                    placeholder={t('writeYourReviewHere')}
                    value={review}
                    onChange={(e) => setReview(e.target.value)}
                    rows={5}
                />
                <InputError
                    className='my-1'
                    error={error && "Minimum 1 star is required"}
                />
                <div className='flex flex-row items-center justify-center pt-5'>
                    <Button
                        className='px-2 py-1 text-sm bg-red-600 mr-2'
                        title={t('cancel')}
                        onClick={() => setShowModal(false)}
                    />
                    <Button
                        className='px-2 py-1 text-sm'
                        title={t('save')}
                        onClick={handleSave}
                    />
                </div>
            </div>
        </Modal>
    );
};

export default GiveReview;