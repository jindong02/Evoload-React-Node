import React, { useEffect, useState } from 'react';
import RegistrationLabelWithInput from '../RegistrationLabelWithInput/RegistrationLabelWithInput';
import InputField from '../InputField/InputField';
import { BsFillPersonFill, BsFillTelephoneFill } from 'react-icons/bs';
import InputError from '../InputError/InputError';
import { GrMail } from 'react-icons/gr';
import Button from '../Button/Button';
import { useForm } from 'react-hook-form';
import { AiFillLock } from 'react-icons/ai';
import isValidEmail from '../../utilities/isValidEmail';
import axiosInstance from '../../axiosInstance';
import { addNotification } from '../../slices/notificationSlice';
import { useDispatch } from 'react-redux';
import Dropdown from '../Dropdown/Dropdown';
import { useTranslation } from 'react-i18next';

const RegisterSecondStep = (props) => {
    const [countryCodes, setCountryCodes] = useState([]);
    const { t } = useTranslation();
    const {
        register,
        handleSubmit,
        formState: { errors },
        watch
    } = useForm();

    const dispatch = useDispatch();
    const watchPassword = watch("password");

    const handleSubmitForm = (data) => {
        props.updateData(data);
        props.setRegister(true);
    };

    const getAllCountryCodes = async () => {
        try {
            const { data } = await axiosInstance.get('/country-codes');
            setCountryCodes(data.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        getAllCountryCodes();
    }, []);

    return (
        <form className='pt-7 lg:pt-5'>
            <RegistrationLabelWithInput label={t('firstName')}>
                <InputField
                    placeholder={t('firstName')}
                    className='px-3 py-2'
                    icon={BsFillPersonFill}
                    formData={register('firstName', { required: true })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.firstName && 'First Name is required'}
                />
            </RegistrationLabelWithInput>
            <RegistrationLabelWithInput label={t('surname')}>
                <InputField
                    placeholder={t('surname')}
                    className='px-3 py-2'
                    icon={BsFillPersonFill}
                    formData={register('surname', { required: true })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.surname && 'Surname is required'}
                />
            </RegistrationLabelWithInput>
            <RegistrationLabelWithInput label={t('countryCode')}>
                <Dropdown
                    placeholder={`${t('select')} ${t('countryCode')}`}
                    className='px-3 py-2'
                    options={countryCodes}
                    formData={register('countryCodeId', { required: true, validate: value => value !== "null" })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.countryCodeId && 'Country Code is required'}
                />
            </RegistrationLabelWithInput>
            <RegistrationLabelWithInput label={t('phone')}>
                <InputField
                    placeholder={t('phone')}
                    className='px-3 py-2'
                    icon={BsFillTelephoneFill}
                    formData={register('phone', { required: true })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.phone && 'Phone is required'}
                />
            </RegistrationLabelWithInput>
            <RegistrationLabelWithInput label={t('email')}>
                <InputField
                    placeholder={t('email')}
                    type='email'
                    className='px-3 py-2'
                    icon={GrMail}
                    formData={register('email', { required: true, validate: value => isValidEmail(value) })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={
                        errors.email &&
                        (errors.email.type === 'required' ? 'Email is required' : 'Email is not valid')
                    }
                />
            </RegistrationLabelWithInput>
            <RegistrationLabelWithInput label={t('username')}>
                <InputField
                    placeholder={t('username')}
                    className='px-3 py-2'
                    icon={BsFillPersonFill}
                    formData={register('username', { required: true })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.username && 'Username is required'}
                />
            </RegistrationLabelWithInput>
            <RegistrationLabelWithInput label={t('password')}>
                <InputField
                    placeholder={t('password')}
                    type='password'
                    className='px-3 py-2'
                    icon={AiFillLock}
                    formData={register('password', { required: true })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.password && 'Password is required'}
                />
            </RegistrationLabelWithInput>
            <RegistrationLabelWithInput label={t('confirmPassword')}>
                <InputField
                    placeholder={t('confirmPassword')}
                    type='password'
                    className='px-3 py-2'
                    icon={AiFillLock}
                    formData={register('confirmPassword', { required: true, validate: value => value === watchPassword })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.confirmPassword && (errors.confirmPassword.type === 'required' ? 'Confirm Password is required' : 'Confirm Password does not match')}
                />
            </RegistrationLabelWithInput>
            <div className='flex justify-center lg:justify-end pt-7 lg:pt-10'>
                <div className='w-full lg:w-4/6 lg:ml-5 flex flex-row justify-center lg:justify-start'>
                    <Button
                        title={t('back')}
                        className='px-3 py-2 lg:ml-2 flex justify-center'
                        onClick={() => props.changeStep(1)}
                    />
                    <Button
                        title={t('next')}
                        className='px-3 py-2 ml-2 flex justify-center'
                        onClick={handleSubmit(handleSubmitForm)}
                    />
                </div>
            </div>
        </form>
    );
};

export default RegisterSecondStep;