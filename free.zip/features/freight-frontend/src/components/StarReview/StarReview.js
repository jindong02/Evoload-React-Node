import React from 'react';
import { BsStarFill, BsStar } from 'react-icons/bs';

const StarReview = (props) => {
    return (
        <div className='flex flex-row justify-center my-2'>
            {
                [...Array(5)].map((star, index) => {
                    const ratingValue = index + 1;
                    return (
                        props.rating >= ratingValue ?
                            <BsStarFill
                                key={index}
                                className='fill-yellow-500 mx-2 cursor-pointer'
                                onMouseEnter={() => props.setRating(ratingValue)}
                                size={24}
                            />
                            :
                            <BsStar
                                key={index}
                                className='text-primary mx-2 cursor-pointer'
                                onMouseEnter={() => props.setRating(ratingValue)}
                                size={24}
                            />
                    )
                })
            }
        </div>
    );
};

export default StarReview;