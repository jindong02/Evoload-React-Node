import React from 'react';
import Modal from '../Modal/Modal';
import { BsStarFill, BsStar } from 'react-icons/bs';

const ViewReview = ({ title, rating, review, showModal, setShowModal }) => {
    const getStars = () => {
        return [...Array(5)].map((_, i) => {
            return rating >= i + 1 ?
                <BsStarFill key={i} size={24} className='fill-yellow-500 mx-2' /> :
                <BsStar key={i} size={24} className='fill-yellow-500 mx-2' />;
        });
    };
    return (
        <Modal
            title={title}
            showModal={showModal}
            setShowModal={setShowModal}
        >
            <div className='flex flex-col justify-center items-center'>
                <div className='flex flex-row my-1'>
                    {getStars()}
                </div>
                {
                    review?.length > 0 &&
                    <p className='text-center mt-2'>
                        {review}
                    </p>
                }
            </div>
        </Modal>
    );
};

export default ViewReview;