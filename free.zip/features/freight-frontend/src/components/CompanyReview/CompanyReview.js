import React, { useEffect, useState } from 'react';
import axiosInstance from '../../axiosInstance';
import ReviewCard from '../../components/ReviewCard/ReviewCard';
import getRowCountToPage from '../../utilities/getRowCountToPage';
import Pagination from '../../components/Pagination/Pagination';
import { addNotification } from '../../slices/notificationSlice';
import { useDispatch } from 'react-redux';
import Dropdown from '../Dropdown/Dropdown';
import { useTranslation } from 'react-i18next';

const CompanyReview = (props) => {
    const [reviews, setReviews] = useState([]);
    const [reviewsCount, setReviewsCount] = useState(0);
    const [pageIndex, setPageIndex] = useState(0);
    const { t } = useTranslation();

    const dispatch = useDispatch();

    const getCompanyReviews = async (id) => {
        try {
            const { data: response } = await axiosInstance.get(`/companies/${id}/reviews`);
            setReviewsCount(response.data.count);
            setReviews(response.data.rows);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        if (props.id)
            getCompanyReviews(props.id);
    }, [props.id]);

    return (
        <div className='my-5 border border-slate-300'>
            <div className='bg-bgSecondary p-5 flex flex-col lg:flex-row justify-between'>
                <p className='text-primary text-xl w-full'>
                    {t('reviewForCompany')} {props?.title} ( {props?.rating} {t('reviews')} )
                </p>
                <Dropdown placeholder='Sort By Date' className='px-2 py-1 mt-3 lg:mt-0 w-full lg:w-1/4' />
            </div>
            <div className='lg:bg-white lg:p-5'>
                {
                    reviews.length ?
                        reviews.map((item, index) => (
                            <ReviewCard key={index} item={item} />
                        ))
                        :
                        <p className='text-primary'>
                            This user has not received any reviews yet
                        </p>
                }
                <Pagination
                    pageCount={getRowCountToPage(reviewsCount)}
                    pageIndex={pageIndex}
                    setPageIndex={setPageIndex}
                />
            </div>
        </div>
    );
};

export default CompanyReview;