import React, { useEffect, useState } from 'react';
import AddTruckLabelWithInput from '../AddTruckLabelWithInput/AddTruckLabelWithInput';
import Dropdown from '../Dropdown/Dropdown';
import InputField from '../InputField/InputField';
import Button from '../Button/Button';
import { useForm } from 'react-hook-form';
import axiosInstance from '../../axiosInstance';
import { addNotification } from '../../slices/notificationSlice';
import { useDispatch } from 'react-redux';
import InputError from '../InputError/InputError';
import { useTranslation } from 'react-i18next';

const AddTruckStepOne = (props) => {
    const [carTypes, setCarTypes] = useState([]);
    const { t } = useTranslation();

    const dispatch = useDispatch();

    const {
        register,
        handleSubmit,
        formState: { errors },
        reset
    } = useForm({
        defaultValues: {
            ...props.data
        }
    });

    const getAllCarTypes = async () => {
        try {
            const { data } = await axiosInstance.get('/car-types?order=title&direction=asc');
            setCarTypes(data.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const handleSubmitForm = (data) => {
        props.updateData(data);
        props.changeStep(2);
    };

    useEffect(() => {
        if (props.reset.includes(1)) {
            reset({
                carTypeId: "null",
                licenseNumber: "",
            });
            props.setReset((prev) => prev.filter(r => r !== 1));
        }
    }, [props.reset]);

    useEffect(() => {
        getAllCarTypes();
    }, []);

    return (
        <div className='flex flex-col bg-white drop-shadow-lg rounded p-5 w-full lg:w-1/2 mx-auto'>
            <p className='my-5 text-center text-2xl'>
                {t('addTruck')}
            </p>
            <AddTruckLabelWithInput label={t('carType')}>
                <Dropdown
                    placeholder={`${t('select')} ${t('carType')}`}
                    className='px-3 py-2'
                    options={carTypes}
                    formData={register('carTypeId', { required: true, validate: value => value !== 'null' })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.carTypeId && 'Car Type is required'}
                />
            </AddTruckLabelWithInput>
            <AddTruckLabelWithInput label={t('licenseNumber')}>
                <InputField
                    placeholder={t('licenseNumber')}
                    className='px-3 py-2'
                    formData={register('licenseNumber', { required: true })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.licenseNumber && 'License Number is required'}
                />
            </AddTruckLabelWithInput>
            <div className='my-5 flex justify-center'>
                <Button
                    className='px-5 py-2'
                    title={t('next')}
                    onClick={handleSubmit(handleSubmitForm)}
                />
            </div>
        </div>
    );
};

export default AddTruckStepOne;