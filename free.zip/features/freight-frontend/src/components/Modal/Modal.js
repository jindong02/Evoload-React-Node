import { useCallback, useEffect, useState } from "react";
import { IoMdClose } from "react-icons/io";

const Modal = (props) => {

    const handleClose = useCallback(() => {
        props.setShowModal(false);
    }, [props]);

    return (
        <>
            {
                props.showModal &&
                <div className="flex justify-center items-center overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none bg-neutral-800/70">
                    <div className="relative w-full md:w-4/6 lg:w-4/6 xl:w-3/5 my-6 mx-auto h-full lg:h-auto">
                        <div className='translate duration-300 h-full translate-y-0 opacity-100'>
                            <div className="p-5 translate h-full lg:h-auto md:h-auto border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none overflow-y-auto">
                                <div className="flex items-center rounded justify-between">
                                    <p className="font-semibold text-xl w-full text-center">{props.title}</p>
                                    <button
                                        className="p-1 border-0 hover:opacity-70"
                                        onClick={handleClose}
                                    >
                                        <IoMdClose size={18} />
                                    </button>
                                </div>
                                <div className="flex-auto mt-5">
                                    {props.children}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            }
        </>
    );
};

export default Modal;
