import React, { useEffect, useMemo, useState } from 'react';
import { AiOutlineDown } from 'react-icons/ai';
import Logo from '../../assets/images/logo.svg';
import SidebarItem from '../SidebarItem/SidebarItem';
import { useDispatch, useSelector } from 'react-redux';
import { desktopSidebarItemsExpeditor, desktopSidebarItemsExpeditorPrimaryUser, desktopSidebarItemsTransporter, desktopSidebarItemsTransporterPrimaryUser } from '../../utilities/menuItems';
import { saveLanguage } from '../../slices/languageSlice';


const Sidebar = (props) => {
    const [openedLanguageDropdown, setOpenedLanguageDropdown] = useState(false);
    const [sidebarItems, setSidebarItems] = useState([]);
    const [openItemId, setOpenItemId] = useState(null);
    const { isOpen } = useSelector(state => state.sidebar);
    const { user } = useSelector(state => state.auth);
    const { language } = useSelector(state => state.language);

    const dispatch = useDispatch();

    const languageItems = useMemo(() => [
        {
            id: 1,
            name: 'ENGLISH',
            icon: 'fi-gb',
            code: 'en'
        },
        {
            id: 2,
            name: 'DEUTSCH',
            icon: 'fi-de',
            code: 'de'
        },
        {
            id: 3,
            name: 'ROMANIAN',
            icon: 'fi-ro',
            code: 'ro'
        }
    ], []);

    const handleLanguageChange = (item) => {
        setOpenedLanguageDropdown(false);
        dispatch(saveLanguage(item));
    };

    useEffect(() => {
        if (user && Object.keys(user).length) {
            if (user.user_type_id === 1) {
                if (user.is_primary_user) {
                    setSidebarItems(desktopSidebarItemsExpeditorPrimaryUser);
                } else {
                    setSidebarItems(desktopSidebarItemsExpeditor);
                }
            } else {
                if (user.is_primary_user) {
                    setSidebarItems(desktopSidebarItemsTransporterPrimaryUser);
                } else {
                    setSidebarItems(desktopSidebarItemsTransporter);
                }
            }
        }
    }, [user]);

    return (
        <div className='flex flex-row h-screen'>
            <div className={`bg-bgPrimary py-5 relative ${isOpen ? 'hidden lg:block lg:w-[220px]' : 'hidden'}`}>
                <img src={Logo} alt='logo' className='w-[160px] h-[64px] pl-5' />
                <div className='pl-5 flex-1'>
                    {
                        sidebarItems.map((item) => (
                            <SidebarItem
                                key={item.id}
                                item={item}
                                openItemId={openItemId}
                                setOpenItemId={setOpenItemId}
                            />
                        ))
                    }
                </div>
                <div className='pl-10 absolute bottom-10'>
                    <div
                        className='flex items-center cursor-pointer select-none'
                        onClick={() => setOpenedLanguageDropdown((prevState) => !prevState)}
                    >
                        <span className={`fi ${language.icon}`}></span>
                        <span className='text-primary pl-2'>
                            {language.name}
                        </span>
                        <AiOutlineDown
                            size={12}
                        />
                    </div>
                    {
                        openedLanguageDropdown &&
                        <div className="relative">
                            <div className='absolute z-10 w-full bottom-4 -left-0 my-2 drop-shadow-md'>
                                {
                                    languageItems.map((item) => (
                                        <div
                                            key={item.id}
                                            className='flex flex-row items-center bg-white cursor-pointer text-primary border-y-2 px-1 border-white hover:border-y-2 hover:border-slate-300'
                                            onClick={() => handleLanguageChange(item)}
                                        >
                                            <div className={`fi ${item.icon} mr-1 w-1/3`}></div>
                                            <div className='text-sm py-1 w-2/3'>{item.name}</div>
                                        </div>
                                    ))
                                }
                            </div>
                        </div>
                    }
                </div>
            </div>
            <div className={`bg-bgSecondary ${isOpen ? 'w-full lg:w-[calc(100%-220px)]' : 'w-full'}`}>
                <div className='w-full overflow-y-auto h-screen'>
                    {props.children}
                </div>
            </div>
        </div >
    );
};

export default Sidebar;