import React from 'react';

const CheckboxWithIcon = (props) => {
    return (
        <div className='flex flex-row items-center'>
            {
                props.icon && <props.icon className={`w-4 h-4 mr-2 ${props.className}`} />
            }
            <input
                type="checkbox"
                className="mr-2 w-5 h-5"
                disabled={props.disabled}
                {...props.formData}
            />
        </div>
    );
};

export default CheckboxWithIcon;