import React from 'react';

const TextArea = (props) => {
    return (
        <div className={`flex flex-row items-start border border-slate-300 rounded focus-within:border-sky-500 focus-within:ring-sky-500 focus-within:outline-none focus-within:ring-1 shadow-sm ${props.className}`}>
            {
                props.icon &&
                <span className={`mr-3 ${props.iconClassName}`}>
                    <props.icon
                        size={props.iconSize}
                    />
                </span>
            }
            <textarea className="placeholder:text-slate-400 block bg-white w-full sm:text-sm focus:outline-none"
                placeholder={props.placeholder}
                type={props.type}
                name={props.name}
                value={props.value}
                onChange={props.onChange}
                rows={props.rows}
                disabled={props.disabled}
                {...props.formData}
            />
        </div>
    );
};

export default TextArea;