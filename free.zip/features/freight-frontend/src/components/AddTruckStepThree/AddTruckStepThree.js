import React, { useEffect, useState } from 'react';
import Button from '../Button/Button';
import InputField from '../InputField/InputField';
import AddTruckLabelWithInput from '../AddTruckLabelWithInput/AddTruckLabelWithInput';
import Dropdown from '../Dropdown/Dropdown';
import { useForm } from 'react-hook-form';
import InputError from '../InputError/InputError';
import isValidEmail from '../../utilities/isValidEmail';
import axiosInstance from '../../axiosInstance';
import { addNotification } from '../../slices/notificationSlice';
import { useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';

const AddTruckStepThree = (props) => {
    const [countryCodes, setCountryCodes] = useState([]);
    const { t } = useTranslation();
    const {
        register,
        handleSubmit,
        formState: { errors },
        reset,
        watch
    } = useForm({
        defaultValues: {
            ...props.data
        }
    });
    const dispatch = useDispatch();
    const watchPassword = watch("password");

    const updateData = (data) => {
        props.updateData(data);
        props.changeStep(2);
    }

    const handleSubmitForm = (data) => {
        delete data.confirmPassword;
        props.updateData(data);
        props.setSaveTruck(true);
    };

    const getAllCountryCodes = async () => {
        try {
            const { data } = await axiosInstance.get('/country-codes');
            setCountryCodes(data.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        if (props.reset.includes(3)) {
            reset({
                firstName: "",
                surname: "",
                countryCodeId: "null",
                phone: "",
                email: "",
                username: "",
                password: "",
                confirmPassword: "",
            });
            props.setReset((prev) => prev.filter(r => r !== 3));
        }
    }, [props.reset]);

    useEffect(() => {
        getAllCountryCodes();
    }, []);

    return (
        <form className='flex flex-col bg-white drop-shadow-lg rounded p-5 w-full lg:w-1/2 mx-auto'>
            <p className='my-5 text-center text-2xl'>
                {t('driversInformation')}
            </p>
            <AddTruckLabelWithInput label={t('firstName')}>
                <InputField
                    placeholder={t('firstName')}
                    className='px-3 py-2'
                    formData={register('firstName', { required: true })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.firstName && 'First Name is required'}
                />
            </AddTruckLabelWithInput>
            <AddTruckLabelWithInput label={t('surname')}>
                <InputField
                    placeholder={t('surname')}
                    className='px-3 py-2'
                    formData={register('surname', { required: true })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.surname && 'Surname is required'}
                />
            </AddTruckLabelWithInput>
            <AddTruckLabelWithInput label={t('countryCode')}>
                <Dropdown
                    className='px-3 py-2'
                    placeholder={`${t('select')} ${t('countryCode')}`}
                    options={countryCodes}
                    formData={register('countryCodeId', { required: true, validate: value => value !== "null" })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.countryCodeId && 'Country Code is required'}
                />
            </AddTruckLabelWithInput>
            <AddTruckLabelWithInput label={t('phone')}>
                <InputField
                    placeholder={t('phone')}
                    className='px-3 py-2'
                    formData={register('phone', { required: true })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.phone && 'Phone  Number is required'}
                />
            </AddTruckLabelWithInput>
            <AddTruckLabelWithInput label={t('email')}>
                <InputField
                    placeholder={t('email')}
                    type='email'
                    className='px-3 py-2'
                    formData={register('email', { required: true, validate: value => isValidEmail(value) })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={
                        errors.email &&
                        (errors.email.type === 'required' ? 'Email is required' : 'Email is not valid')
                    }
                />
            </AddTruckLabelWithInput>
            <AddTruckLabelWithInput label={t('username')}>
                <InputField
                    placeholder={t('username')}
                    className='px-3 py-2'
                    formData={register('username', { required: true })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.username && 'Username is required'}
                />
            </AddTruckLabelWithInput>
            <AddTruckLabelWithInput label={t('password')}>
                <InputField
                    placeholder={t('password')}
                    type='password'
                    className='px-3 py-2'
                    formData={register('password', { required: true })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.password && 'Password is required'}
                />
            </AddTruckLabelWithInput>
            <AddTruckLabelWithInput label={t('confirmPassword')}>
                <InputField
                    placeholder={t('confirmPassword')}
                    type='password'
                    className='px-3 py-2'
                    formData={register('confirmPassword', { required: true, validate: value => value === watchPassword })}
                />
                <InputError
                    className='mt-1 ml-1'
                    error={errors.confirmPassword && (errors.confirmPassword.type === 'required' ? 'Confirm Password is required' : 'Confirm Password does not match')}
                />
            </AddTruckLabelWithInput>

            <div className='my-5 flex justify-center'>
                <Button
                    className='px-5 py-2 mr-2'
                    title={t('previous')}
                    onClick={handleSubmit(updateData)}
                />
                <Button
                    className='px-5 py-2'
                    title={t('save')}
                    onClick={handleSubmit(handleSubmitForm)}
                />
            </div>
        </form>
    );
};

export default AddTruckStepThree;