import React, { useState } from 'react';
import Button from '../Button/Button';
import { AiFillStar } from 'react-icons/ai';
import prettyDate from '../../utilities/prettyDate';
import { ReactComponent as IconOne } from '../../assets/icons/empire.svg';
import { ReactComponent as IconTwo } from '../../assets/icons/triangle-exclamation-solid.svg';
import { ReactComponent as IconThree } from '../../assets/icons/square-caret-up-regular.svg';
import { useNavigate } from 'react-router-dom';
import axiosInstance from '../../axiosInstance';
import { addNotification } from '../../slices/notificationSlice';
import { useDispatch } from 'react-redux';
import { type } from '../../utilities/constantValues';
import { useTranslation } from 'react-i18next';

const LoadDetailsCard = (props) => {
    const [hideFollow, setHideFollow] = useState(false);
    const { t } = useTranslation();
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const isIncluded = (arr, number) => {
        const index = arr.findIndex((item) => item.id === number);
        return index !== -1;
    };

    const handleFollowFreight = async (id) => {
        try {
            const { data: response } = await axiosInstance.post(`/freights/${id}/follow`);
            dispatch(addNotification({ type: "success", message: response.message }));
            setHideFollow(true);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    return (
        <div className='flex flex-col lg:flex-row justify-between p-3 bg-white my-5 lg:my-2'>
            <div className='flex-1 p-3'>
                <div className='flex flex-col lg:flex-row justify-between'>
                    <div className='block lg:hidden bg-bgPrimary p-3 mb-5 text-lg font-semibold text-primary'>
                        {t("load")}
                    </div>
                    <div className='flex flex-row'>
                        <div className={`w-14 h-10 mr-2 bg-flag1 flex items-center justify-center text-white text-2xl font-bold`}>
                            {props?.item?.freights_from?.title[0]}
                        </div>
                        <div>
                            <p className='text-primary font-bold'>{props?.item?.freights_from?.title}</p>
                            <p className='text-secondary'>{props?.item?.loading_asap_loading ? 'ASAP' : `${t('at')} ${new Date(props?.item?.loading_from_date).toLocaleDateString()} ${t('to')} ${new Date(props?.item?.loading_to_date).toLocaleDateString()}`}</p>
                        </div>
                    </div>
                    <p className='text-secondary'>
                        {props?.item?.load?.postCode}
                    </p>
                </div>
                <div className='mt-4'>
                    <p className='text-secondary'>{props?.item?.CarType?.title}</p>
                    <p className='text-secondary'>No.Art.: {props?.item?.articles} / {t('weight')}:  {props?.item?.weight}</p>
                </div>
            </div>
            <div className='flex-1 p-3'>
                <div className='block lg:hidden bg-bgPrimary p-3 mb-5 text-lg font-semibold text-primary'>
                    {t("unload")}
                </div>
                <div className='flex flex-row'>
                    <div className='flex flex-row'>
                        <div className={`w-14 h-10 mr-2 bg-flag1 flex items-center justify-center text-white text-2xl font-bold`}>
                            {props?.item?.freights_to?.title[0]}
                        </div>
                        <div>
                            <p className='text-primary font-bold'>{props?.item?.freights_to?.title}</p>
                            <p className='text-secondary'>{props?.item?.unloading_direct_delivery ? 'Direct Delivery' : `${t('at')} ${new Date(props?.item?.unloading_from_date).toLocaleDateString()} ${t('to')} ${new Date(props?.item?.unloading_to_date).toLocaleDateString()}`}</p>
                        </div>
                    </div>
                </div>
                <div className='mt-4'>
                    <p className='text-secondary'>
                        {t('distance')}: {props?.item?.distance}km
                        {
                            props?.item?.volume && <span>
                                <span className='mx-2'>| {t('volume')}: {props?.item?.volume}m3</span>
                            </span>
                        }
                    </p>
                    <p className='text-secondary'>{t('publishedOn')}: {prettyDate(props?.item?.created_at)}</p>
                    {
                        props?.item?.special_requirements.length > 0 &&
                        <p className='flex flex-row py-2'>
                            {isIncluded(props?.item?.special_requirements, 1) && <IconOne className='w-4 h-4 fill-[#03a9f0] mr-4' />}
                            {isIncluded(props?.item?.special_requirements, 2) && <IconTwo className='w-4 h-4 fill-[red] mr-4' />}
                            {isIncluded(props?.item?.special_requirements, 3) && <IconThree className='w-4 h-4 fill-[orange] mr-4' />}
                        </p>
                    }
                    <p className='text-secondary'>{props?.item?.TransportType?.title}</p>
                    <Button
                        title={t('showInfo')}
                        className='p-1 text-xs block mt-2'
                        onClick={() => navigate(`/freights/${props?.item?.id}`)}
                    />
                </div>
            </div>
            <div className='min-w-[25%] p-3'>
                <div className='block lg:hidden bg-bgPrimary p-3 mb-5 text-lg font-semibold text-primary'>
                    {t("company")}
                </div>
                <div className='flex flex-row items-center'>
                    <div className='bg-blue-200 text-btnPrimaryText flex items-center justify-center w-14 h-10 mr-2'>
                        <p className='text-2xl font-semibold'>{props?.item?.Company?.title[0]}</p>
                    </div>
                    <div>
                        <p
                            className='text-btnPrimary font-semibold select-none cursor-pointer'
                            onClick={() => navigate(`/companies/${props?.item?.Company?.id}`)}
                        >
                            {props?.item?.Company?.title}
                        </p>
                        {
                            props?.item?.show_phone &&
                            <p>{props?.item?.CountryCode?.value}{props?.item?.phone}</p>
                        }
                    </div>
                </div>
                <p className='mt-2 text-secondary'>
                    {t('price')}: {props?.item?.suggested_price} {props?.item?.Currency?.title} {props?.item?.vat_included ? '' : '+ VAT'}
                </p>
                <p className='mt-1 text-secondary'>
                    {props?.item?.PaymentDeadline?.title}
                </p>
                {
                    props?.userData?.type === type.transporter &&
                    <>
                        <Button
                            title={t('sendOffer')}
                            className='p-1 text-xs block mt-2'
                            onClick={() => navigate(`/freights/${props?.item?.id}/send-offer`)}
                        />
                        {(!props?.hideFollow && !hideFollow) &&
                            <Button
                                title={t('follow')}
                                className='p-1 text-xs block mt-2'
                                icon={AiFillStar}
                                iconSize='12'
                                iconClassName='mr-1 fill-[#FFC107]'
                                onClick={() => handleFollowFreight(props?.item?.id)}
                            />
                        }
                    </>
                }
            </div>
        </div>
    );
};

export default LoadDetailsCard;