const getRowCountToPage = (rows) => rows % 20 > 0 ? Math.floor(rows / 20) + 1 : rows / 20;
export default getRowCountToPage;