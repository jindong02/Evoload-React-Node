const type = {
    expeditor: 'expeditor',
    transporter: 'transporter'
};

const defaults = ['/', '/my-account', '/company-profile', '/companies/:id', '/freights/:id', '/about', '/map', '/support', '/send-verification-code'];
const expeditor = [...defaults, '/new-freight', '/my-freights', '/my-freights/:id/offers', '/my-freights/:id/edit', '/active-freights', '/offers/:id', '/completed-freights', '/freight-live'];
const expeditorPrimaryUser = [...expeditor, '/add-user', '/list-user'];
const transporter = [...defaults, '/freights/:id/send-offer', '/followed-freights', '/my-offers', '/my-offers/:id/edit', '/active-transports', '/completed-transports', '/offers/:id'];
const transporterPrimaryUser = [...transporter, '/add-truck', '/list-trucks'];

Object.freeze(type);
Object.freeze(expeditorPrimaryUser);
Object.freeze(transporterPrimaryUser);
Object.freeze(expeditor);
Object.freeze(transporter);

export { type, expeditorPrimaryUser, transporterPrimaryUser, expeditor, transporter };