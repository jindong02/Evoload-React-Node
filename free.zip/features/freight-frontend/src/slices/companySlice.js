import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    company: null,
};


const companySlice = createSlice({
    name: "company",
    initialState,
    reducers: {
        saveCompanyData: (state, action) => {
            state.company = action.payload;
        },
        removeCompanyData: (state, action) => {
            state.company = null;
        }
    },
});

export const {
    saveCompanyData,
    removeCompanyData
} = companySlice.actions;

export default companySlice.reducer;