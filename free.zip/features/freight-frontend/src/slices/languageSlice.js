import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    language: {
        id: 1,
        name: 'ENGLISH',
        icon: 'fi-gb',
        language: 'en'
    },
};


const languageSlice = createSlice({
    name: "language",
    initialState,
    reducers: {
        saveLanguage: (state, action) => {
            state.language = action.payload;
            localStorage.setItem('language', JSON.stringify(action.payload));
        }
    },
});

export const {
    saveLanguage,
} = languageSlice.actions;

export default languageSlice.reducer;