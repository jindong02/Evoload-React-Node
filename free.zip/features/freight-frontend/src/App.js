import { Route, Routes } from "react-router-dom";
import "./App.css";
import Layout from "./components/Layout/Layout";
import About from "./pages/About/About";
import Home from "./pages/Home/Home";
import Map from "./pages/Map/Map";
import Support from "./pages/Support/Support";
import NotFound from "./pages/NotFound/NotFound";
import FollowedFreights from "./pages/FollowedFreights/FollowedFreights";
import MyOffers from "./pages/MyOffers/MyOffers";
import ActiveTransports from "./pages/ActiveTransports/ActiveTransports";
import CompletedTransports from "./pages/CompletedTransports/CompletedTransports";
import ListTrucks from "./pages/ListTrucks/ListTrucks";
import MyAccount from "./pages/MyAccount/MyAccount";
import CompanyProfile from "./pages/CompanyProfile/CompanyProfile";
import Login from "./pages/Login/Login";
import Register from "./pages/Register/Register";
import ForgotPassword from "./pages/ForgotPassword/ForgotPassword";
import { ToastContainer } from "react-toastify";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import "react-toastify/dist/ReactToastify.css";
import { removeNotification } from "./slices/notificationSlice";
import showNotification from "./utilities/showNotification";
import { saveAccessToken } from "./slices/authSlice";
import axiosInstance from "./axiosInstance";
import PublicRoute from "./components/PublicRoute/PublicRoute";
import AddUser from "./pages/AddUser/AddUser";
import ListUser from "./pages/ListUser/ListUser";
import FreightLive from "./pages/FreightLive/FreightLive";
import NewFreight from "./pages/NewFreight/NewFreight";
import MyFreights from "./pages/MyFreights/MyFreights";
import SendOffer from "./pages/SendOffer/SendOffer";
import Offers from "./pages/Offers/Offers";
import ActiveFreights from "./pages/ActiveFreights/ActiveFreights";
import CompletedFreights from "./pages/CompletedFreights/CompletedFreights";
import AcceptedOffer from "./pages/AcceptedOffer/AcceptedOffer";
import EditFreight from "./pages/EditFreight/EditFreight";
import EditOffer from "./pages/EditOffer/EditOffer";
import AddTruck from "./pages/AddTruck/AddTruck";
import CompanyDetails from "./pages/CompanyDetails/CompanyDetails";
import ViewFreight from "./pages/ViewFreight/ViewFreight";
import { useTranslation } from "react-i18next";
import { saveLanguage } from "./slices/languageSlice";
import VerifyEmail from "./pages/VerifyEmail/VerifyEmail";
import SendVerificationCode from "./pages/SendVerificationCode/SendVerificationCode";
import { useContext } from "react";
import SocketContext from "./SocketContext";
function App() {
  const [isLoading, setIsLoading] = useState(true);
  const { accessToken } = useSelector((state) => state.auth);
  const { notifications } = useSelector((state) => state.notification);
  const { language } = useSelector((state) => state.language);
  const [freight, setFreight] = useState({});
  const { i18n } = useTranslation();
  const dispatch = useDispatch();
  const socket = useContext(SocketContext);

  useEffect(() => {
  }, [freight]);

  
  

  const getAccessToken = async () => {
    try {
      const { data: response } = await axiosInstance.get(
        "/users/get-access-token"
      );
      if (response.data.accessToken) {
        dispatch(saveAccessToken(response.data.accessToken));
        setTimeout(() => {
          getAccessToken();
        }, 3000 * 1000);
      }
    } catch (err) {
      console.log(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    i18n.changeLanguage(language.code);
  }, [i18n, language]);

  useEffect(() => {
    if (notifications.length) {
      notifications.forEach((notification) => {
        showNotification(notification.type, notification.message);
        dispatch(removeNotification());
      });
    }
  }, [notifications]);

  useEffect(() => {
    if (!accessToken) {
      getAccessToken();
    } else {
      setIsLoading(false);
    }
    const language = localStorage.getItem("language");
    if (language) {
      dispatch(saveLanguage(JSON.parse(language)));
    }
  }, []);

  if (isLoading) {
    return (
      <div className="absolute right-1/2 bottom-1/2  transform translate-x-1/2 translate-y-1/2 ">
        <div className="border-t-transparent border-solid animate-spin  rounded-full border-blue-400 border-4 h-12 w-12"></div>
      </div>
    );
  }

  return (
    <>
      <ToastContainer autoClose={5000} closeOnClick />
      <Routes>
        <Route
          path="/"
          element={
            <Layout freightData={freight}>
              <Home freightData={freight} />
            </Layout>
          }
        />
        <Route
          path="/followed-freights"
          element={
            <Layout>
              <FollowedFreights />
            </Layout>
          }
        />
        <Route
          path="/my-offers"
          element={
            <Layout>
              <MyOffers />
            </Layout>
          }
        />
        <Route
          path="/my-offers/:id/edit"
          element={
            <Layout>
              <EditOffer />
            </Layout>
          }
        />
        <Route
          path="/active-transports"
          element={
            <Layout>
              <ActiveTransports />
            </Layout>
          }
        />
        <Route
          path="/completed-freights"
          element={
            <Layout>
              <CompletedFreights />
            </Layout>
          }
        />
        <Route
          path="/completed-transports"
          element={
            <Layout>
              <CompletedTransports />
            </Layout>
          }
        />
        <Route
          path="/active-freights"
          element={
            <Layout>
              <ActiveFreights />
            </Layout>
          }
        />
        <Route
          path="/add-truck"
          element={
            <Layout>
              <AddTruck />
            </Layout>
          }
        />
        <Route
          path="/list-trucks"
          element={
            <Layout>
              <ListTrucks />
            </Layout>
          }
        />
        <Route
          path="/about"
          element={
            <Layout>
              <About />
            </Layout>
          }
        />
        <Route
          path="/map"
          element={
            <Layout>
              <Map />
            </Layout>
          }
        />
        <Route
          path="/support"
          element={
            <Layout>
              <Support />
            </Layout>
          }
        />
        <Route
          path="/my-account"
          element={
            <Layout>
              <MyAccount />
            </Layout>
          }
        />
        <Route
          path="/company-profile"
          element={
            <Layout>
              <CompanyProfile />
            </Layout>
          }
        />
        <Route
          path="/companies/:id"
          element={
            <Layout>
              <CompanyDetails />
            </Layout>
          }
        />
        <Route
          path="/add-user"
          element={
            <Layout>
              <AddUser />
            </Layout>
          }
        />
        <Route
          path="/list-user"
          element={
            <Layout>
              <ListUser />
            </Layout>
          }
        />
        <Route
          path="/freight-live"
          element={
            <Layout>
              <FreightLive />
            </Layout>
          }
        />
        <Route
          path="/new-freight"
          element={
            <Layout>
              <NewFreight socket={socket} setFreight={setFreight} />
            </Layout>
          }
        />
        <Route
          path="/my-freights"
          element={
            <Layout>
              <MyFreights />
            </Layout>
          }
        />
        <Route
          path="/my-freights/:id/offers"
          element={
            <Layout>
              <Offers />
            </Layout>
          }
        />
        <Route
          path="/my-freights/:id/edit"
          element={
            <Layout>
              <EditFreight />
            </Layout>
          }
        />
        <Route
          path="/offers/:id"
          element={
            <Layout>
              <AcceptedOffer />
            </Layout>
          }
        />
        <Route
          path="/freights/:id/send-offer"
          element={
            <Layout>
              <SendOffer />
            </Layout>
          }
        />
        <Route
          path="/freights/:id"
          element={
            <Layout>
              <ViewFreight />
            </Layout>
          }
        />
        <Route
          path="/log-in"
          element={
            <PublicRoute>
              <Login />
            </PublicRoute>
          }
        />
        <Route
          path="/register"
          element={
            <PublicRoute>
              <Register />
            </PublicRoute>
          }
        />
        <Route
          path="/forgot-password"
          element={
            <PublicRoute>
              <ForgotPassword />
            </PublicRoute>
          }
        />
        <Route
          path="/verify-email"
          element={
            <PublicRoute>
              <VerifyEmail />
            </PublicRoute>
          }
        />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
}

export default App;
