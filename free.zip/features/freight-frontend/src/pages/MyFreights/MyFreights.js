import React, { useEffect, useMemo, useState } from 'react';
import { addNotification } from '../../slices/notificationSlice';
import { useDispatch } from 'react-redux';
import axiosInstance from '../../axiosInstance';
import Pagination from '../../components/Pagination/Pagination';
import getRowCountToPage from '../../utilities/getRowCountToPage';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

const MyFreights = () => {
    const [freightsCount, setFreightsCount] = useState(0);
    const [freightListTableData, setTruckListTableData] = useState([]);
    const [pageIndex, setPageIndex] = useState(0);
    const { t } = useTranslation();

    const dispatch = useDispatch();
    const navigate = useNavigate();

    const freightListTableHeader = useMemo(() => [
        {
            label: 'freightId',
            accessor: 'id'
        },
        {
            label: 'loadingFrom',
            accessor: 'freights_from',
            accessorTwo: 'title'
        },
        {
            label: 'unloadingTo',
            accessor: 'freights_to',
            accessorTwo: 'title'
        },
        {
            label: 'carType',
            accessor: 'CarType',
            accessorTwo: 'title'
        },
        {
            label: 'price',
            accessor: 'suggested_price',
        },
        {
            label: 'currency',
            accessor: 'Currency',
            accessorTwo: 'title'
        },
        {
            label: 'offers',
            accessor: 'offers',
            accessorTwo: 'length'
        },
        {
            label: 'status',
            accessor: 'status',
        },
        {
            label: 'updatedAt',
            accessor: 'updated_at',
        }
    ], []);

    const handleChangeStatus = async (id, status) => {
        try {
            const { data: response } = await axiosInstance.put(`/freights/${id}`, { status });
            getMyFreights();
            dispatch(addNotification({ type: "success", message: response.message }));
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const handleDelete = async (id) => {
        try {
            const { data: response } = await axiosInstance.delete(`/freights/${id}`);
            getMyFreights();
            dispatch(addNotification({ type: "success", message: response.message }));
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };


    const getMyFreights = async () => {
        try {
            const { data: response } = await axiosInstance.get(`/freights/my-freights?page=${pageIndex + 1}`);
            setFreightsCount(response.data.count);
            setTruckListTableData(response.data.rows);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        getMyFreights();
    }, [pageIndex]);

    return (
        <div>
            <div className='flex flex-row items-center justify-between'>
                <p className='text-primary text-2xl font-medium'>
                    My Freights
                </p>
            </div>
            <div className='overflow-x-auto'>
                <table className='my-5 bg-white drop-shadow-sm w-full'>
                    <thead>
                        <tr>
                            {
                                freightListTableHeader.map((item, index) => (
                                    <th
                                        key={index}
                                        className='px-4 py-2 text-sm font-medium text-left text-primary tracking-wider'
                                    >{t(item.label)}</th>
                                ))
                            }
                            <th
                                className='px-4 py-2 text-sm font-medium text-left text-primary tracking-wider'
                            >{t('actions')}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            freightListTableData.map((row, index) => (
                                <tr key={index}>
                                    {
                                        freightListTableHeader.map((item, subIndex) => (
                                            <td
                                                key={subIndex}
                                                className='px-4 py-2 text-sm text-left text-slate-600'
                                            >
                                                {
                                                    item.accessorTwo ? row[item.accessor][item.accessorTwo] : item.accessor.includes('_at') ? new Date(row[item.accessor]).toLocaleString() : row[item.accessor]
                                                }
                                            </td>
                                        ))
                                    }
                                    <td className='px-4 py-2 text-sm text-center text-slate-600 flex items-center justify-center'>
                                        <span
                                            className='bg-btnPrimary text-white px-2 py-1 m-1 cursor-pointer select-none'
                                            onClick={() => navigate(`/my-freights/${row.id}/edit`)}
                                        >
                                            {t('edit')}
                                        </span>
                                        <span
                                            className='bg-btnPrimary text-white px-2 py-1 m-1 cursor-pointer select-none'
                                            onClick={() => navigate(`/my-freights/${row.id}/offers`)}
                                        >
                                            {t('offers')}({row.offers.length})
                                        </span>
                                        {
                                            (row.status === 'opened' || row.status === 'closed') &&
                                            <span
                                                className='bg-btnPrimary text-white px-2 py-1 m-1 cursor-pointer select-none'
                                                onClick={() => handleChangeStatus(row.id, row.status === 'opened' ? 'closed' : 'opened')}
                                            >
                                                {row.status === 'opened' ? t('close') : t('open')}
                                            </span>
                                        }
                                        <span
                                            className='bg-red-600 text-white px-2 py-1 m-1 cursor-pointer select-none'
                                            onClick={() => handleDelete(row.id)}
                                        >
                                            {t('delete')}
                                        </span>
                                    </td>
                                </tr>
                            ))
                        }
                    </tbody>
                </table>
            </div>
            <Pagination
                pageCount={getRowCountToPage(freightsCount)}
                pageIndex={pageIndex}
                setPageIndex={setPageIndex}
            />
        </div>
    );
};

export default MyFreights;