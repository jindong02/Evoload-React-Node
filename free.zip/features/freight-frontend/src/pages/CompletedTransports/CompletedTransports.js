import React, { useEffect, useState } from 'react';
import Pagination from '../../components/Pagination/Pagination';
import axiosInstance from '../../axiosInstance';
import { addNotification } from '../../slices/notificationSlice';
import { useDispatch } from 'react-redux';
import getRowCountToPage from '../../utilities/getRowCountToPage';
import CompletedTransportCard from '../../components/CompletedTransportCard/CompletedTransportCard';
import { useTranslation } from 'react-i18next';

const CompletedTransports = () => {
    const [freightsCount, setFreightsCount] = useState(0);
    const [freights, setFreights] = useState([]);
    const [pageIndex, setPageIndex] = useState(0);
    const { t } = useTranslation();
    const dispatch = useDispatch();

    const deleteCompletedTransport = async (freightId) => {
        try {
            const { data: response } = await axiosInstance.delete(`/transports/${freightId}/completed-transport`);
            dispatch(addNotification({ type: "success", message: response.message }));
            getActiveTransports();
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const saveExpeditorReview = async (formData) => {
        try {
            const { data: response } = await axiosInstance.post(`/freights/${formData.freightId}/expeditor-review`, { expeditorReviewStars: formData.expeditorReviewStars, expeditorReview: formData.expeditorReview });
            dispatch(addNotification({ type: "success", message: response.message }));
            getActiveTransports();
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const getActiveTransports = async () => {
        try {
            const { data: response } = await axiosInstance.get(`/transports/completed-transports?page=${pageIndex + 1}`);
            setFreightsCount(response.data.count);
            setFreights(response.data.rows);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        getActiveTransports();
    }, [pageIndex]);

    return (
        <div className='overflow-x-auto'>
            <div className='my-2 w-full min-w-[800px]'>
                <div className='flex flex-row bg-white py-3'>
                    <p className='w-3/12 px-3 font-bold text-primary'>{t('load')}</p>
                    <p className='w-3/12 px-3 font-bold text-primary'>{t('unload')}</p>
                    <p className='w-4/12 px-3 font-bold text-primary'>{t('status')}</p>
                    <p className='w-2/12 px-3 font-bold text-primary text-center'>{t('actions')}</p>
                </div>
                {
                    freights?.map((item, index) => (
                        <CompletedTransportCard
                            key={index}
                            item={item}
                            saveExpeditorReview={saveExpeditorReview}
                            deleteCompletedTransport={deleteCompletedTransport}
                        />
                    ))
                }
            </div>
            <Pagination
                pageCount={getRowCountToPage(freightsCount)}
                pageIndex={pageIndex}
                setPageIndex={setPageIndex}
            />
        </div>
    );
};
export default CompletedTransports;