import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import axiosInstance from '../../axiosInstance';
import { useDispatch, useSelector } from 'react-redux';
import { addNotification } from '../../slices/notificationSlice';
import { set } from 'react-hook-form';
import { use } from 'i18next';
import { logoutUser } from '../../slices/authSlice';

const VerifyEmail = () => {
    const { accessToken } = useSelector(state => state.auth);
    const [searchParams, setSearchParams] = useSearchParams();
    const [message, setMessage] = useState('');
    const email = searchParams.get('email');
    const verification_code = searchParams.get('verification_code');
    const dispatch = useDispatch();
    const navigate = useNavigate();
    let timer;

    const verifyEmail = async (email, verification_code) => {
        try {
            const { data: response } = await axiosInstance.post(`/users/verify-email`, {
                email,
                verificationCode: verification_code
            });
            setMessage(response.message);
            dispatch(addNotification({ type: "success", message: response.message }));
            if (accessToken) {
                await axiosInstance.get('/users/logout');
                timer = setTimeout(() => {
                    window.location.href = '/';
                }, 3000);
            } else {
                timer = setTimeout(() => {
                    window.location.href = '/';
                }, 3000);
            }
        } catch (error) {
            setMessage(error.response.data?.message);
            dispatch(addNotification({ type: "error", message: error.response.data?.message }));
            timer = setTimeout(() => {
                navigate('/');
            }, 3000);
        }
    };

    useEffect(() => {
        if (email && verification_code) {
            verifyEmail(email, verification_code);
        } else {
            navigate('/');
        }
    }, [email, verification_code]);

    useEffect(() => {
        return () => {
            clearTimeout(timer);
        };
    }, []);

    return (
        <div className='flex justify-center items-center h-screen'>
            <div className='w-1/2'>
                <div className='text-center'>
                    {
                        !message ?
                            <h1 className='text-3xl font-bold text-primary'>
                                Verifying your email, please wait...
                            </h1>
                            :
                            <h1 className='text-3xl font-bold text-primary'>
                                {message}
                            </h1>
                    }
                    {
                        message &&
                        <p className='text-secondary mt-5'>
                            You will be redirected in 3 seconds.
                        </p>
                    }
                </div>
            </div>
        </div>
    );
};

export default VerifyEmail;