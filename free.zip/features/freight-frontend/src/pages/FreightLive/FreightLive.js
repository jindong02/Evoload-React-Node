import React, { useEffect, useState } from 'react';
import axiosInstance from '../../axiosInstance';
import { addNotification } from '../../slices/notificationSlice';
import { useDispatch } from 'react-redux';
import Pagination from '../../components/Pagination/Pagination';
import LoadDetailsCard from '../../components/LoadDetailsCard/LoadDetailsCard';
import getRowCountToPage from '../../utilities/getRowCountToPage';
import { useTranslation } from 'react-i18next';

const FreightLive = () => {
    const [freightsCount, setFreightsCount] = useState(0);
    const [freights, setFreights] = useState([]);
    const [pageIndex, setPageIndex] = useState(0);
    const { t } = useTranslation();
    const dispatch = useDispatch();

    const getAllFreights = async () => {
        try {
            const { data: response } = await axiosInstance.get(`/freights?page=${pageIndex + 1}`);
            setFreightsCount(response.data.count);
            setFreights(response.data.rows);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        getAllFreights();
    }, [pageIndex]);

    return (
        <div>
            <div className='my-2'>
                <div className='hidden lg:flex flex-row bg-white py-3'>
                    <p className='flex-1 px-3 font-bold text-primary'>{t('load')}</p>
                    <p className='flex-1 px-3 font-bold text-primary'>{t('unload')}</p>
                    <p className='min-w-[25%] px-3 font-bold text-primary'>{t('contact')}</p>
                </div>
                {
                    freights.map((item, index) => (
                        <LoadDetailsCard key={index} item={item} />
                    ))
                }
            </div>
            <Pagination
                pageCount={getRowCountToPage(freightsCount)}
                pageIndex={pageIndex}
                setPageIndex={setPageIndex}
            />
        </div>
    );
};

export default FreightLive;