import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { addNotification } from '../../slices/notificationSlice';
import axiosInstance from '../../axiosInstance';
import Pagination from '../../components/Pagination/Pagination';
import getRowCountToPage from '../../utilities/getRowCountToPage';
import CompletedFreightCard from '../../components/CompletedFreightCard/CompletedFreightCard';
import { useTranslation } from 'react-i18next';

const CompletedFreights = () => {
    const [completedFreightsCount, setCompletedFreightsCount] = useState(0);
    const [completedFreights, setCompletedFreights] = useState([]);
    const [pageIndex, setPageIndex] = useState(0);
    const { t } = useTranslation();
    const dispatch = useDispatch();

    const getAllCompletedFreights = async () => {
        try {
            const { data: response } = await axiosInstance.get(`/freights/completed-freights?page=${pageIndex + 1}`);
            setCompletedFreightsCount(response.data.count);
            setCompletedFreights(response.data.rows);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const saveTransporterReview = async (formData) => {
        try {
            const { data: response } = await axiosInstance.post(`/freights/${formData.freightId}/transporter-review`, { transporterReviewStars: formData.transporterReviewStars, transporterReview: formData.transporterReview });
            dispatch(addNotification({ type: "success", message: response.message }));
            getAllCompletedFreights();
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const deleteCompletedFreight = async (freightId) => {
        try {
            const { data: response } = await axiosInstance.delete(`/freights/${freightId}/completed-freight`);
            dispatch(addNotification({ type: "success", message: response.message }));
            getAllCompletedFreights();
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        getAllCompletedFreights();
    }, [pageIndex]);

    return (
        <div className='overflow-x-auto'>
            <div className='my-2 w-full min-w-[800px]'>
                <div className='flex flex-row bg-white py-3'>
                    <p className='w-3/12 px-3 font-bold text-primary'>{t('load')}</p>
                    <p className='w-3/12 px-3 font-bold text-primary'>{t('unload')}</p>
                    <p className='w-4/12 px-3 font-bold text-primary'>{t('contact')}</p>
                    <p className='w-2/12 px-3 font-bold text-primary text-center'>{t('actions')}</p>
                </div>
                {
                    completedFreights.map((item, index) => (
                        <CompletedFreightCard
                            key={index}
                            item={item}
                            saveTransporterReview={saveTransporterReview}
                            deleteCompletedFreight={deleteCompletedFreight}
                        />
                    ))
                }
            </div>
            <Pagination
                pageCount={getRowCountToPage(completedFreightsCount)}
                pageIndex={pageIndex}
                setPageIndex={setPageIndex}
            />
        </div>
    );
};

export default CompletedFreights;