import React, { useEffect, useMemo, useState } from 'react';
import { BsFillTrashFill } from 'react-icons/bs';
import Tooltip from '../../components/Tooltip/Tooltip';
import { addNotification } from '../../slices/notificationSlice';
import { useDispatch } from 'react-redux';
import axiosInstance from '../../axiosInstance';
import { useTranslation } from 'react-i18next';

const ListTrucks = () => {
    const [truckListTableData, setTruckListTableData] = useState([]);
    const { t } = useTranslation();
    const dispatch = useDispatch();

    const truckListTableHeader = useMemo(() => [
        {
            label: 'carType',
            accessor: 'CarType',
            accessorTwo: 'title'
        },
        {
            label: 'licenseNumber',
            accessor: 'license_number',
        },
        {
            label: 'driverName',
            accessor: 'driver',
            accessorTwo: 'first_name'
        },
        {
            label: 'phone',
            accessor: 'driver',
            accessorTwo: 'phone'
        },
        {
            label: 'length',
            accessor: 'length',
        },
        {
            label: 'width',
            accessor: 'width',
        },
        {
            label: 'height',
            accessor: 'height',
        },
    ], []);

    const getAllTrucksData = async () => {
        try {
            const { data: response } = await axiosInstance.get('/trucks');
            setTruckListTableData(response.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const handleDelete = async (id) => {
        try {
            await axiosInstance.delete(`/trucks/${id}`);
            getAllTrucksData();
            dispatch(addNotification({ type: "success", message: 'Truck deleted successfully' }));
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        getAllTrucksData();
    }, []);

    return (
        <div>
            <div className='flex flex-row items-center justify-between'>
                <p className='text-primary text-2xl font-medium'>
                    List Of Trucks
                </p>
            </div>
            <div className='overflow-x-auto'>
                <table className='my-5 bg-white drop-shadow-sm w-full'>
                    <thead>
                        <tr>
                            {
                                truckListTableHeader.map((item, index) => (
                                    <th
                                        key={index}
                                        className='px-4 py-2 text-sm font-medium text-left text-primary tracking-wider'
                                    >{t(item.label)}</th>
                                ))
                            }
                            <th
                                className='px-4 py-2 text-sm font-medium text-left text-primary tracking-wider'
                            >{t('actions')}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            truckListTableData.map((row, index) => (
                                <tr key={index}>
                                    {
                                        truckListTableHeader.map((item, subIndex) => (
                                            <td
                                                key={subIndex}
                                                className='px-4 py-2 text-sm text-left text-slate-600'
                                            >
                                                {
                                                    item.accessorTwo ? row[item.accessor][item.accessorTwo] :
                                                        (row[item.accessor] === false ? 'No' : row[item.accessor] === true ? 'Yes' : row[item.accessor])
                                                }
                                            </td>
                                        ))
                                    }
                                    <td className='px-4 py-2 text-sm text-left text-slate-600'>
                                        <span
                                            className='cursor-pointer relative group inline-block'
                                            onClick={() => handleDelete(row.id)}
                                        >
                                            <BsFillTrashFill />
                                            <Tooltip title='Delete' />
                                        </span>
                                    </td>
                                </tr>
                            ))
                        }
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default ListTrucks;