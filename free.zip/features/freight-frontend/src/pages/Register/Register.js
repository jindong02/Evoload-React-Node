import React, { useEffect, useMemo, useState } from 'react';
import Logo from '../../assets/images/vertical-logo.svg';
import { AiOutlineDown } from 'react-icons/ai';
import RegisterFirstStep from '../../components/RegisterFirstStep/RegisterFirstStep';
import RegisterSecondStep from '../../components/RegisterSecondStep/RegisterSecondStep';
import axiosInstance from '../../axiosInstance';
import { useDispatch, useSelector } from 'react-redux';
import { addNotification } from '../../slices/notificationSlice';
import { saveAccessToken, saveUser } from '../../slices/authSlice';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { saveLanguage } from '../../slices/languageSlice';

const Register = () => {
    const [step, setStep] = useState(1);
    const [register, setRegister] = useState(false);
    const [formData, setFormData] = useState({});
    const [openedLanguageDropdown, setOpenedLanguageDropdown] = useState(false);
    const { language } = useSelector(state => state.language);

    const { t } = useTranslation();

    const navigate = useNavigate();
    const dispatch = useDispatch();

    const languageItems = useMemo(() => [
        {
            id: 1,
            name: 'ENGLISH',
            icon: 'fi-gb',
            code: 'en'
        },
        {
            id: 2,
            name: 'DEUTSCH',
            icon: 'fi-de',
            code: 'de'
        },
        {
            id: 3,
            name: 'ROMANIAN',
            icon: 'fi-ro',
            code: 'ro'
        }
    ], []);

    const handleLanguageChange = (item) => {
        setOpenedLanguageDropdown(false);
        dispatch(saveLanguage(item));
    };

    const updateData = (newData) => {
        setFormData((prevData) => ({
            ...prevData,
            ...newData
        }));
    };

    const changeStep = (step) => {
        setStep(step);
    };

    const registerUser = async () => {
        try {
            delete formData.confirmPassword;
            const { data: response } = await axiosInstance.post('/users/register', formData);
            dispatch(addNotification({ type: "success", message: response.message }));
            dispatch(saveAccessToken(response.data.accessToken));
            delete response.data.accessToken;
            dispatch(saveUser(response.data));
            navigate('/');
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const components = {
        1: <RegisterFirstStep changeStep={changeStep} updateData={updateData} />,
        2: <RegisterSecondStep changeStep={changeStep} updateData={updateData} setRegister={setRegister} />
    };

    useEffect(() => {
        if (register) {
            registerUser();
            setRegister(false);
        }
    }, [formData]);

    return (
        <div className='w-full min-h-screen bg-bgPrimary py-5 lg:py-10 px-5 lg:px-0'>
            <div className='w-full lg:w-2/5 mx-auto bg-white px-5 lg:px-10 py-5 lg:py-10'>
                <img src={Logo} alt='logo' className='w-2/5 lg:w-3/12 mx-auto' />
                <div className='py-10'>
                    <div className='flex flex-col lg:flex-row justify-between items-center'>
                        <h1 className='text-2xl text-primary'>
                            {t('register')}
                        </h1>
                        <div>
                            <div
                                className='flex items-center mt-5 lg:mt-0 cursor-pointer select-none'
                                onClick={() => setOpenedLanguageDropdown((prev) => !prev)}
                            >
                                <span className={`fi ${language.icon}`}></span>
                                <span className='text-primary pl-2'>
                                    {language.name}
                                </span>
                                <AiOutlineDown
                                    size={12}
                                />
                            </div>
                            {
                                openedLanguageDropdown &&
                                <div className="relative">
                                    <div className='absolute z-10 w-full -top-2 -left-0 my-2 drop-shadow-md'>
                                        {
                                            languageItems.map((item) => (
                                                <div
                                                    key={item.id}
                                                    className='flex flex-row items-center bg-white cursor-pointer text-primary border-y-2 px-1 border-white hover:border-y-2 hover:border-slate-300'
                                                    onClick={() => handleLanguageChange(item)}
                                                >
                                                    <div className={`fi ${item.icon} mr-1 w-1/3`}></div>
                                                    <div className='text-sm py-1 w-2/3'>{item.name}</div>
                                                </div>
                                            ))
                                        }
                                    </div>
                                </div>
                            }
                        </div>
                    </div>
                    <hr className='my-5' />
                    <div className='font-bold text-primary'>
                        {t('step')} {step} of 2 {t(step === 1 ? 'companyDetails' : 'personalDetails')}
                    </div>
                    <hr className='my-5' />
                    {
                        components[step]
                    }
                </div>
            </div>
        </div>
    );
};

export default Register;