import React, { useEffect, useState } from 'react';
import Logo from '../../assets/images/EVOLOAD_mini.jpg';
import InputField from '../../components/InputField/InputField';
import { BsFillPersonFill } from 'react-icons/bs';
import { GrMail } from 'react-icons/gr';
import { BsFillTagFill } from 'react-icons/bs';
import { BsChatRightFill } from 'react-icons/bs';
import Dropdown from '../../components/Dropdown/Dropdown';
import TextArea from '../../components/TextArea/TextArea';
import Button from '../../components/Button/Button';
import SupportLabelWithInput from '../../components/SupportLabelWithInput/SupportLabelWithInput';
import { useForm } from 'react-hook-form';
import InputError from '../../components/InputError/InputError';
import axiosInstance from '../../axiosInstance';
import { addNotification } from '../../slices/notificationSlice';
import { useDispatch } from 'react-redux';
import isValidEmail from '../../utilities/isValidEmail';
import { useTranslation } from 'react-i18next';

const Support = () => {
    const [supportCategories, setSupportCategories] = useState([]);
    const { t } = useTranslation();
    const {
        register,
        handleSubmit,
        formState: { errors },
        reset
    } = useForm();

    const dispatch = useDispatch();

    const getAllCountries = async () => {
        try {
            const { data } = await axiosInstance.get('/support-categories?order=id&direction=asc');
            setSupportCategories(data.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const handleSubmitForm = async (formData) => {
        try {
            const { data: response } = await axiosInstance.post('/support-requests', formData);
            dispatch(addNotification({ type: "success", message: response.message }));
            reset({
                firstName: '',
                surname: '',
                email: '',
                message: '',
                subject: '',
                supportCategoryId: 'null'
            });
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        getAllCountries();
    }, []);

    return (
        <div className='w-full lg:w-3/6 my-5 mx-auto bg-white py-5 px-3 lg:p-10'>
            <div>
                <img src={Logo} alt='EVOLOAD' className='w-30 h-30 mx-auto' />
            </div>
            <div>
                <p className='text-primary text-2xl'>
                    {t('support')}
                </p>
            </div>
            <div className='my-5'>
                <SupportLabelWithInput label={t('firstName')}>
                    <div>
                        <InputField
                            placeholder={t('firstName')}
                            className='px-2 py-1 mr-2'
                            icon={BsFillPersonFill}
                            formData={register('firstName', { required: true })}
                        />
                        <InputError
                            className='mt-1 ml-1'
                            error={errors.firstName && 'First Name is required'}
                        />
                    </div>
                    <div>
                        <InputField
                            placeholder={t('surname')}
                            className='px-2 py-1'
                            icon={BsFillPersonFill}
                            formData={register('surname', { required: true })}
                        />
                        <InputError
                            className='mt-1 ml-1'
                            error={errors.surname && 'Surname is required'}
                        />
                    </div>
                </SupportLabelWithInput>
                <SupportLabelWithInput label={t('email')}>
                    <div className='w-full'>
                        <InputField
                            placeholder={t('email')}
                            className='px-2 py-1'
                            icon={GrMail}
                            formData={register('email', { required: true, validate: value => isValidEmail(value) })}
                        />
                        <InputError
                            className='mt-1 ml-1'
                            error={errors.email && (errors.email.type === 'required' ? 'Email is required' : 'Please enter a valid email address')}
                        />
                    </div>
                </SupportLabelWithInput>
                <SupportLabelWithInput label={t('category')}>
                    <div className='w-full'>
                        <Dropdown
                            className='px-2 py-1'
                            placeholder={`${t('select')} ${t('category')}`}
                            options={supportCategories}
                            formData={register('supportCategoryId', { required: true, validate: value => value !== 'null' })}
                        />
                        <InputError
                            className='mt-1 ml-1'
                            error={errors.supportCategoryId && 'Category is required'}
                        />
                    </div>
                </SupportLabelWithInput>
                <SupportLabelWithInput label={t('subject')}>
                    <div className='w-full'>
                        <InputField
                            placeholder={t('subject')}
                            className='px-2 py-1'
                            icon={BsFillTagFill}
                            formData={register('subject', { required: true })}
                        />
                        <InputError
                            className='mt-1 ml-1'
                            error={errors.subject && 'Subject is required'}
                        />
                    </div>
                </SupportLabelWithInput>
                <SupportLabelWithInput label={t('message')}>
                    <div className='w-full'>
                        <TextArea
                            placeholder={t('message')}
                            className='px-2 py-1'
                            icon={BsChatRightFill}
                            rows={5}
                            formData={register('message', { required: true })}
                        />
                        <InputError
                            className='mt-1 ml-1'
                            error={errors.message && 'Message is required'}
                        />
                    </div>
                </SupportLabelWithInput>
                <div className='flex items-center justify-center'>
                    <Button
                        className='mt-10 px-5 py-2'
                        title={t('submit')}
                        onClick={handleSubmit(handleSubmitForm)}
                    />
                </div>
            </div>
        </div>
    );
};

export default Support;