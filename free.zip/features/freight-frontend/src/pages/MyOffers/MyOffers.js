import React, { useEffect, useState } from 'react';
import MyOfferCard from '../../components/MyOfferCard/MyOfferCard';
import { useDispatch } from 'react-redux';
import { addNotification } from '../../slices/notificationSlice';
import axiosInstance from '../../axiosInstance';
import Pagination from '../../components/Pagination/Pagination';
import getRowCountToPage from '../../utilities/getRowCountToPage';
import { useTranslation } from 'react-i18next';

const activeTransportsTableHeader = [
    'load',
    'unload',
    'contact',
    'status',
    'actions'
];

const MyOffers = () => {
    const [offerCount, setOfferCount] = useState(0);
    const [offer, setOffer] = useState([]);
    const [pageIndex, setPageIndex] = useState(0);
    const { t } = useTranslation();
    const dispatch = useDispatch();

    const deleteOfferById = async (id) => {
        try {
            const { data: response } = await axiosInstance.delete(`/offers/${id}`);
            dispatch(addNotification({ type: "success", message: response.message }));
            getAllOffers();
        } catch (error) {
            console.log(error);
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const getAllOffers = async () => {
        try {
            const { data: response } = await axiosInstance.get(`/offers/my-offers?page=${pageIndex + 1}`);
            setOfferCount(response.data.count);
            setOffer(response.data.rows);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        getAllOffers();
    }, [pageIndex]);

    return (
        <div className='overflow-x-auto'>
            <div className='bg-white drop-shadow-sm my-2 w-full min-w-[800px]'>
                <div className='w-full flex flex-row py-3'>
                    {
                        activeTransportsTableHeader.map((item, index) => (
                            <div
                                key={index}
                                className={`px-3 font-bold text-left text-primary ${index <= 1 ? 'w-3/12' : 'w-2/12'}`}
                            >{t(item)}</div>
                        ))
                    }
                </div>
                {
                    offer.map((item, index) => (
                        <MyOfferCard key={index} item={item} onDelete={deleteOfferById} />
                    ))
                }
                <Pagination
                    pageCount={getRowCountToPage(offerCount)}
                    pageIndex={pageIndex}
                    setPageIndex={setPageIndex}
                />
            </div>
        </div>
    );
};

export default MyOffers;