import React from 'react';

const About = () => {
    return (
        <div>
            <p className='p-5 bg-[#F8FBFF] text-2xl'>
                About
            </p>
            <div className='text-primary bg-white p-5 text-sm'>
                <p className='py-2'>
                    The newest Transport will appear automatically in the home without the need of applying any Search Filter. If you want to narrow your search than you need to apply the Search Filters.
                </p>
                <p className='py-2'>
                    When you have read the details of an Transport you can click on The blue INFO button located in the Contact column,and read the extra details that were given.</p>
                <p className='py-2'>
                    Then you can use the Send Offer button to send a Price Offer,where you will have a box where you can give extra details about your Loading and Unloading Possibilities that the Shipper will receive together with your Price Offer.</p>
                <p className='py-2'>
                    When Your price offer will be accepted you will receive a notification in the platform, and an E-Mail on you registered address.
                </p>
                <p className='py-2'>
                    From this time you cand find the offer in the ,,Active Transports’’ where you will need to complete 3 Informations: Driver Name , Licence Number Auto, Phone Number, after that you should receive The Transport Order on E-mail or you will be Called on Phone from the Shipper.
                </p>
                <p className='py-2'>
                    When the Shipper will give the Accept and the Order was Confirmed you will have access at the Transport Status where you cand send to the Shipper Info about the Loading and Unloading Date and Hours.
                </p>
                <p className='py-2'>
                    If you have any kind of Problem,Suggestion,or Complaint please use the Support or Contact us by E-Mail or Phone.
                </p>
            </div>
        </div>
    );
};

export default About;