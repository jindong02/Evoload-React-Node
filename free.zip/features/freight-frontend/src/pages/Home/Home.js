import React, { useEffect, useState } from "react";
import Button from "../../components/Button/Button";
import LoadDetailsCard from "../../components/LoadDetailsCard/LoadDetailsCard";
import SearchFilterModal from "../../components/SearchFilterModal/SearchFilterModal";
import { BsSearch } from "react-icons/bs";
import Pagination from "../../components/Pagination/Pagination";
import axiosInstance from "../../axiosInstance";
import { addNotification } from "../../slices/notificationSlice";
import { useDispatch, useSelector } from "react-redux";
import getRowCountToPage from "../../utilities/getRowCountToPage";
import jwt_decode from "jwt-decode";
import { useTranslation } from "react-i18next";
import LoadDetailsSocketCard from "../../components/LoadDetailsSocketCard/LoadDetailsSocketCard";
import { useContext } from "react";
import SocketContext from "../../SocketContext";

const Home = ({ freightData }) => {
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [socketData, setSocketData] = useState([]);
  const [freightsCount, setFreightsCount] = useState(0);
  const [testData, setTestData] = useState([]);
  const [freights, setFreights] = useState([]);
  const [pageIndex, setPageIndex] = useState(0);
  const { accessToken } = useSelector((state) => state.auth);
  const { t } = useTranslation();
  const userData = jwt_decode(accessToken);
  const dispatch = useDispatch();
  const socket = useContext(SocketContext);


  const getAllFreights = async () => {
    try {
      const { data: response } = await axiosInstance.get(
        `/freights?page=${pageIndex + 1}`
      );
      setFreightsCount(response.data.count);
      setFreights(response.data.rows);
    } catch (error) {
      dispatch(
        addNotification({ type: "error", message: error.response.data.message })
      );
    }
  };

  useEffect(() => {
    const data = getAllFreights();
    socket.on("freight", (data) => {
      setSocketData([data]);
      if (data) {
        setTestData([data]);
      }
    });
  }, [freightData]);

  useEffect(() => {
    getAllFreights();
  }, [pageIndex]);

  return (
    <div>
      <div className="mt-2 mb-5">
        <Button
          title="Search"
          icon={BsSearch}
          iconSize="16"
          className="px-3 py-2 lg:px-10 lg:py-3"
          iconClassName="fill-[white]"
          textClassName="text-lg"
          onClick={() => setShowSearchModal(true)}
        />
        <SearchFilterModal
          showSearchModal={showSearchModal}
          setShowSearchModal={setShowSearchModal}
        />
      </div>
      <div>
        <div className="my-2">
          <div className="hidden lg:flex flex-row bg-white py-3">
            <p className="flex-1 px-3 font-bold text-primary">{t("load")}</p>
            <p className="flex-1 px-3 font-bold text-primary">{t("unload")}</p>
            <p className="min-w-[25%] px-3 font-bold text-primary">
              {t("contact")}
            </p>
          </div>

          {socketData.length > 0 &&
            socketData.map((item, index) => (
              <LoadDetailsSocketCard
                key={index}
                item={item}
                userData={userData}
              />
            ))}
          {freights.map((item, index) => (
            <LoadDetailsCard key={index} item={item} userData={userData} />
          ))}
        </div>
        <Pagination
          pageCount={getRowCountToPage(freightsCount)}
          pageIndex={pageIndex}
          setPageIndex={setPageIndex}
        />
      </div>
    </div>
  );
};
export default Home;
