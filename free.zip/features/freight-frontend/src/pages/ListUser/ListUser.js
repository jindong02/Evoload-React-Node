import React, { useEffect, useMemo, useState } from 'react';
import { BsFillTrashFill } from 'react-icons/bs';
import Tooltip from '../../components/Tooltip/Tooltip';
import { addNotification } from '../../slices/notificationSlice';
import { useDispatch } from 'react-redux';
import axiosInstance from '../../axiosInstance';
import { useTranslation } from 'react-i18next';

const ListUser = () => {
    const [userListTableData, setUserListTableData] = useState([]);
    const { t } = useTranslation();
    const dispatch = useDispatch();

    const userListTableHeader = useMemo(() => [
        {
            label: 'ID',
            accessor: 'id',
        },
        {
            label: 'firstName',
            accessor: 'first_name',
        },
        {
            label: 'surname',
            accessor: 'surname',
        },
        {
            label: 'email',
            accessor: 'email',
        },
        {
            label: 'phone',
            accessor: 'phone',
        },
        {
            label: 'username',
            accessor: 'username',
        }
    ], []);


    const getAllUserData = async () => {
        try {
            const { data: response } = await axiosInstance.get('/users');
            setUserListTableData(response.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        getAllUserData();
    }, []);

    return (
        <div>
            <div className='flex flex-row items-center justify-between'>
                <p className='text-primary text-2xl font-medium'>
                    List Of Users
                </p>
            </div>
            <div className='overflow-x-auto'>
                <table className='my-5 bg-white drop-shadow-sm w-full'>
                    <thead>
                        <tr>
                            {
                                userListTableHeader.map((item, index) => (
                                    <th
                                        key={index}
                                        className='px-4 py-2 text-sm font-medium text-left text-primary tracking-wider'
                                    >{t(item.label)}</th>
                                ))
                            }
                        </tr>
                    </thead>
                    <tbody>
                        {
                            userListTableData.map((row, index) => (
                                <tr key={index}>
                                    {
                                        userListTableHeader.map((item, subIndex) => (
                                            <td
                                                key={subIndex}
                                                className='px-4 py-2 text-sm text-left text-slate-600'
                                            >
                                                {
                                                    row[item.accessor]
                                                }
                                            </td>
                                        ))
                                    }
                                </tr>
                            ))
                        }
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default ListUser;