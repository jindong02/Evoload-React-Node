import React, { useEffect, useState } from 'react';
import Button from '../../components/Button/Button';
import LoadDetailsCard from '../../components/LoadDetailsCard/LoadDetailsCard';
import SearchFilterModal from '../../components/SearchFilterModal/SearchFilterModal';
import { BsSearch } from 'react-icons/bs';
import Pagination from '../../components/Pagination/Pagination';
import axiosInstance from '../../axiosInstance';
import { addNotification } from '../../slices/notificationSlice';
import { useDispatch, useSelector } from 'react-redux';
import getRowCountToPage from '../../utilities/getRowCountToPage';

const FollowedFreights = () => {
    const [showSearchModal, setShowSearchModal] = useState(false);
    const [freightsCount, setFreightsCount] = useState(0);
    const [freights, setFreights] = useState([]);
    const [pageIndex, setPageIndex] = useState(0);
    const { user } = useSelector(state => state.auth);
    const dispatch = useDispatch();

    const getAllFreights = async () => {
        try {
            const { data: response } = await axiosInstance.get(`/freights/followed-freights?page=${pageIndex + 1}`);
            setFreightsCount(response.data.count);
            setFreights(response.data.rows);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        getAllFreights();
    }, [pageIndex]);

    return (
        <div>
            <div className='mt-2 mb-5'>
                <Button
                    title='Search'
                    icon={BsSearch}
                    iconSize='16'
                    className='px-3 py-2 lg:px-10 lg:py-3'
                    iconClassName='fill-[white]'
                    textClassName='text-lg'
                    onClick={() => setShowSearchModal(true)}
                />
                <SearchFilterModal
                    showSearchModal={showSearchModal}
                    setShowSearchModal={setShowSearchModal}
                />
            </div>
            <div>
                <div className='my-2'>
                    <div className='hidden lg:flex flex-row bg-white py-3'>
                        <p className='flex-1 px-3 font-bold text-primary'>Load</p>
                        <p className='flex-1 px-3 font-bold text-primary'>Unload</p>
                        <p className='min-w-[25%] px-3 font-bold text-primary'>Contact</p>
                    </div>
                    {
                        freights.map((item, index) => (
                            <LoadDetailsCard
                                key={index}
                                item={item}
                                userData={user}
                                hideFollow={true}
                            />
                        ))
                    }
                </div>
                <Pagination
                    pageCount={getRowCountToPage(freightsCount)}
                    pageIndex={pageIndex}
                    setPageIndex={setPageIndex}
                />
            </div>
        </div>
    );
};
export default FollowedFreights;