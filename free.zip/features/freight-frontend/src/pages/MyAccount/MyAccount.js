import React, { useEffect, useState } from 'react';
import InputField from '../../components/InputField/InputField';
import MyAccountLabelWithInput from '../../components/MyAccountLabelWithInput/MyAccountLabelWithInput';
import Dropdown from '../../components/Dropdown/Dropdown';
import Button from '../../components/Button/Button';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from 'react-hook-form';
import InputError from '../../components/InputError/InputError';
import isValidEmail from '../../utilities/isValidEmail';
import axiosInstance from '../../axiosInstance';
import { addNotification } from '../../slices/notificationSlice';
import { saveUser } from '../../slices/authSlice';
import { useTranslation } from 'react-i18next';

const MyAccount = () => {
    const { user } = useSelector(state => state.auth);
    const [countryCodes, setCountryCodes] = useState([]);
    const [userType, setUserType] = useState({});
    const { t } = useTranslation();
    const dispatch = useDispatch();

    const {
        register,
        handleSubmit,
        formState: { errors },
        setValue,
        watch
    } = useForm();

    const watchPassword = watch("password");

    const handleSubmitForm = async (formData) => {
        try {
            const finalData = {};
            Object.keys(formData).forEach(key => {
                if (formData[key]) {
                    finalData[key] = formData[key];
                }
            });
            delete finalData.confirmPassword;
            const { data: response } = await axiosInstance.put('/users', finalData);
            dispatch(addNotification({ type: "success", message: response.message }));
            dispatch(saveUser(response.data));
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const getUserTypeByUserId = async (id) => {
        try {
            const { data: response } = await axiosInstance.get(`/user-types/users/${id}`);
            setUserType(response.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const getAllCountryCodes = async () => {
        try {
            const { data: response } = await axiosInstance.get('/country-codes');
            setCountryCodes(response.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        if (user && Object.keys(user).length) {
            setValue('firstName', user.first_name);
            setValue('surname', user.surname);
            setValue('function', user.function);
            setValue('phone', user.phone);
            setValue('username', user.username);
            setValue('email', user.email);
            setValue('password', '');
            setValue('confirmPassword', '');
        }
    }, [user]);

    useEffect(() => {
        if ((userType && Object.keys(userType).length) && countryCodes.length) {
            setValue('countryCodeId', user.country_code_id);
        }
    }, [userType, countryCodes]);

    useEffect(() => {
        if (user && Object.keys(user).length > 0) {
            getUserTypeByUserId(user.id);
        }
    }, [user]);

    useEffect(() => {
        getAllCountryCodes();
    }, []);

    return (
        <div>
            <div className='my-5 border border-slate-300'>
                <div className='bg-bgSecondary p-5 flex flex-col lg:flex-row justify-between items-center'>
                    <p className='text-primary text-xl'>
                        {t('myAccount')}
                    </p>
                    <p className='text-sm mt-2 lg:mt-0'>
                        Payed Until : 2024-03-29
                    </p>
                </div>
                <div className='bg-white p-5'>
                    <div>
                        <p className='text-2xl text-primary text-center my-3'>
                            {t('personalInfo')}
                        </p>
                        <hr />
                        <div>
                            <MyAccountLabelWithInput title={t('firstName')}>
                                <InputField
                                    placeholder={t('firstName')}
                                    className='px-3 py-2'
                                    formData={register('firstName', { required: true })}
                                />
                                <InputError
                                    className='mt-1 ml-1'
                                    error={errors.firstName && 'First Name is required'}
                                />
                            </MyAccountLabelWithInput>
                            <MyAccountLabelWithInput title={t('surname')}>
                                <InputField
                                    placeholder={t('surname')}
                                    className='px-3 py-2'
                                    formData={register('surname', { required: true })}
                                />
                                <InputError
                                    className='mt-1 ml-1'
                                    error={errors.surname && 'Surname is required'}
                                />
                            </MyAccountLabelWithInput>
                            <MyAccountLabelWithInput title={t('function')}>
                                <InputField
                                    placeholder={t('function')}
                                    className='px-3 py-2'
                                    formData={register('function')}
                                />
                                <InputError
                                    className='mt-1 ml-1'
                                    error={errors.function && 'Function is required'}
                                />
                            </MyAccountLabelWithInput>
                            <MyAccountLabelWithInput title={t('countryCode')}>
                                <Dropdown
                                    placeholder={`${t('select')} ${t('countryCode')}`}
                                    className='px-3 py-2'
                                    options={countryCodes}
                                    formData={register('countryCodeId', { required: true, validate: value => value !== 'null' })}
                                />
                            </MyAccountLabelWithInput>
                            <MyAccountLabelWithInput title={t('phone')}>
                                <InputField
                                    placeholder={t('phone')}
                                    className='px-3 py-2'
                                    formData={register('phone', { required: true })}
                                />
                                <InputError
                                    className='mt-1 ml-1'
                                    error={errors.phone && 'Phone is required'}
                                />
                            </MyAccountLabelWithInput>
                            <MyAccountLabelWithInput title={t('userType')}>
                                <Dropdown
                                    placeholder={userType?.title}
                                    className='px-3 py-2'
                                    disabled
                                />
                            </MyAccountLabelWithInput>
                        </div>
                    </div>
                    <div>
                        <p className='text-2xl text-primary text-center my-3'>
                            {t('userInfo')}
                        </p>
                        <hr />
                        <div>
                            <MyAccountLabelWithInput title={t('username')}>
                                <InputField
                                    placeholder={t('username')}
                                    className='px-3 py-2'
                                    formData={register('username', { required: true })}
                                />
                                <InputError
                                    className='mt-1 ml-1'
                                    error={errors.username && 'Username is required'}
                                />
                            </MyAccountLabelWithInput>
                            <MyAccountLabelWithInput title={t('email')}>
                                <InputField
                                    placeholder={t('email')}
                                    className='px-3 py-2'
                                    formData={register('email', { required: true, validate: value => isValidEmail(value) })}
                                />
                                <InputError
                                    className='mt-1 ml-1'
                                    error={errors.email && 'Email is required'}
                                />
                            </MyAccountLabelWithInput>
                            <MyAccountLabelWithInput title={t('password')}>
                                <InputField
                                    type='password'
                                    placeholder={t('password')}
                                    className='px-3 py-2'
                                    formData={register('password')}
                                />
                            </MyAccountLabelWithInput>
                            <MyAccountLabelWithInput title={t('confirmPassword')}>
                                <InputField
                                    type='password'
                                    placeholder={t('confirmPassword')}
                                    className='px-3 py-2'
                                    formData={register('confirmPassword', { validate: value => value === watchPassword })}
                                />
                                <InputError
                                    className='mt-1 ml-1'
                                    error={errors.confirmPassword && 'Confirm Password does not match'}
                                />
                            </MyAccountLabelWithInput>
                        </div>
                    </div>
                    <div className='flex items-center justify-center my-10'>
                        <Button
                            title={t('save')}
                            className='px-5 py-2'
                            onClick={handleSubmit(handleSubmitForm)}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default MyAccount;