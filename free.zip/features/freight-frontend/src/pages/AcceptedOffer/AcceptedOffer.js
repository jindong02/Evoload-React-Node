import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { addNotification } from '../../slices/notificationSlice';
import axiosInstance from '../../axiosInstance';
import { useNavigate, useParams } from 'react-router-dom';
import Modal from '../../components/Modal/Modal';
import AcceptedOfferCard from '../../components/AcceptedOfferCard/AcceptedOfferCard';
import { useTranslation } from 'react-i18next';


const AcceptedOffer = () => {
    const { id } = useParams();
    const [offer, setOffer] = useState({});
    const { t } = useTranslation();
    const dispatch = useDispatch();

    const getOfferById = async (id) => {
        try {
            const { data: response } = await axiosInstance.get(`/offers/${id}`);
            setOffer(response.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        getOfferById(id);
    }, [id]);

    return (
        <div className='my-2'>
            <div className='hidden lg:flex flex-row bg-white py-3'>
                <p className='w-3/12 px-3 font-bold text-primary'>{t('company')}</p>
                <p className='w-1/12 px-3 font-bold text-primary'>{t('offer')}</p>
                <p className='w-2/12 px-3 font-bold text-primary'>{t('loading')}</p>
                <p className='w-2/12 px-3 font-bold text-primary'>{t('unloading')}</p>
                <p className='w-2/12 px-3 font-bold text-primary'>{t('offeredOn')}</p>
                <p className='w-2/12 px-3 font-bold text-primary text-center'>{t('actions')}</p>
            </div>
            <AcceptedOfferCard
                item={offer}
            />
        </div>
    );
};

export default AcceptedOffer;