import React, { useMemo } from 'react';
import Logo from '../../assets/images/vertical-logo.svg';
import { AiOutlineDown, AiFillLock } from 'react-icons/ai';
import { GrMail } from 'react-icons/gr';
import InputField from '../../components/InputField/InputField';
import { Link } from 'react-router-dom';
import Button from '../../components/Button/Button';

const ForgotPassword = () => {

    const languageItems = useMemo(() => [
        {
            id: 1,
            name: 'ENGLISH',
            icon: 'fi-gb',
        },
        {
            id: 2,
            name: 'DEUTSCH',
            icon: 'fi-de',
        },
        {
            id: 3,
            name: 'ROMANIAN',
            icon: 'fi-ro',
        }
    ], []);

    return (
        <div className='w-full min-h-screen bg-bgPrimary py-10 lg:py-10 px-5 lg:px-0'>
            <div className='w-full lg:w-2/6 mx-auto bg-white px-5 lg:px-10 py-5 lg:py-10'>
                <img src={Logo} alt='logo' className='w-4/12 mx-auto' />
                <div className='py-10'>
                    <div className='flex flex-col lg:flex-row justify-between items-center'>
                        <h1 className='text-2xl text-primary'>Forgot Password?</h1>
                        <div className='flex items-center mt-5 lg:mt-0'>
                            <span className={`fi ${languageItems[0].icon}`}></span>
                            <span className='text-primary pl-2'>
                                {languageItems[0].name}
                            </span>
                            <AiOutlineDown
                                size={12}
                            />
                        </div>
                    </div>
                    <div className='pt-7 lg:pt-10'>
                        <div className='lg:pl-2 flex flex-col lg:flex-row  justify-center lg:justify-between items-center'>
                            <label className='text-primary w-full lg:w-2/6'>Email</label>
                            <InputField
                                placeholder='Email'
                                className='px-3 py-2 w-full lg:w-4/6'
                                icon={GrMail}
                            />
                        </ div>
                        <div className='flex justify-center lg:justify-end pt-7 lg:pt-10'>
                            <div className='lg:w-4/6 lg:ml-5 flex flex-col-reverse lg:flex-row'>
                                <Button
                                    title='Submit'
                                    className='px-3 py-2 lg:ml-3 flex justify-center'
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ForgotPassword;