import React, { useEffect, useState } from 'react';
import Pagination from '../../components/Pagination/Pagination';
import axiosInstance from '../../axiosInstance';
import { addNotification } from '../../slices/notificationSlice';
import { useDispatch } from 'react-redux';
import getRowCountToPage from '../../utilities/getRowCountToPage';
import ActiveTransportCard from '../../components/ActiveTransportCard/ActiveTransportCard';
import { useTranslation } from 'react-i18next';

const ActiveTransports = () => {
    const [freightsCount, setFreightsCount] = useState(0);
    const [freights, setFreights] = useState([]);
    const [freightStatuses, setFreightStatuses] = useState([]);
    const [truckList, setTruckList] = useState([]);
    const [pageIndex, setPageIndex] = useState(0);
    const { t } = useTranslation();
    const dispatch = useDispatch();

    const onSubmit = async (formData) => {
        try {
            const { data: response } = await axiosInstance.post(`/freights/${formData.itemId}/set-truck`, { truckId: formData.truckId });
            dispatch(addNotification({ type: "success", message: response.message }));
            getActiveTransports();
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const cancelFreight = async (id) => {
        try {
            const { data: response } = await axiosInstance.patch(`/freights/${id}/cancel`);
            dispatch(addNotification({ type: "success", message: response.message }));
            getActiveTransports();
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const updateFreightStatus = async (formData) => {
        try {
            const { data: response } = await axiosInstance.put(`/freights/${formData.freightId}/update-freight-status`, { offerId: formData.offerId, freightStatusId: formData.freightStatusId });
            dispatch(addNotification({ type: "success", message: response.message }));
            getActiveTransports();
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const getTruckList = async () => {
        try {
            const { data: response } = await axiosInstance.get(`/trucks/truck-list`);
            const modifiedResponse = response.data.map((item) => ({
                id: item.id,
                title: `${item.driver.full_name} - ${item.license_number} - ${item.driver.phone}`
            }));
            setTruckList([...modifiedResponse]);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const getAllFreightStatuses = async () => {
        try {
            const { data: response } = await axiosInstance.get(`/freight-statuses?order=id&direction=asc`);
            setFreightStatuses(response.data);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    const getActiveTransports = async () => {
        try {
            const { data: response } = await axiosInstance.get(`/transports/active-transports?page=${pageIndex + 1}`);
            setFreightsCount(response.data.count);
            setFreights(response.data.rows);
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        getActiveTransports();
    }, [pageIndex]);

    useEffect(() => {
        getTruckList();
        getAllFreightStatuses();
    }, []);

    return (
        <div className='overflow-x-auto'>
            <div className='my-2 w-full min-w-[800px]'>
                <div className='flex flex-row bg-white py-3 w-full'>
                    <p className='w-3/12 px-3 font-bold text-primary'>{t('load')}</p>
                    <p className='w-3/12 px-3 font-bold text-primary'>{t('unload')}</p>
                    <p className='w-4/12 px-3 font-bold text-primary'>{t('status')}</p>
                    <p className='w-2/12 px-3 font-bold text-primary text-center'>{t('actions')}</p>
                </div>
                {
                    freights?.map((item, index) => (
                        <ActiveTransportCard
                            key={index}
                            item={item}
                            truckList={truckList}
                            freightStatuses={freightStatuses}
                            onSubmit={onSubmit}
                            updateFreightStatus={updateFreightStatus}
                            cancelFreight={cancelFreight}
                        />
                    ))
                }
            </div>
            <Pagination
                pageCount={getRowCountToPage(freightsCount)}
                pageIndex={pageIndex}
                setPageIndex={setPageIndex}
            />
        </div>
    );
};
export default ActiveTransports;