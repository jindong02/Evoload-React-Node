import React, { useEffect } from 'react';
import { BsTruck } from 'react-icons/bs';
import { FiMapPin } from 'react-icons/fi';
import { BiBuilding } from 'react-icons/bi';
import { BsBuildingCheck } from 'react-icons/bs';
import { CgProfile } from 'react-icons/cg';
import { TfiBag } from 'react-icons/tfi';
import Button from '../../components/Button/Button';
import { addNotification } from '../../slices/notificationSlice';
import axiosInstance from '../../axiosInstance';
import { useDispatch, useSelector } from 'react-redux';
import { saveCompanyData } from '../../slices/companySlice';
import CompanyReview from '../../components/CompanyReview/CompanyReview';
import ReviewStats from '../../components/ReviewStats/ReviewStats';
import CompletedTransportCount from '../../components/CompletedTransportCount/CompletedTransportCount';
import CompanyFleet from '../../components/CompanyFleet/CompanyFleet';
import { useTranslation } from 'react-i18next';

const CompanyProfile = () => {
    const { company } = useSelector(state => state.company);
    const { t } = useTranslation();
    const dispatch = useDispatch();

    const companyProfile = [
        {
            title: 'street',
            accessor: 'street_and_number',
            icon: FiMapPin,
        },
        {
            title: 'vatNumber',
            accessor: 'vat_number',
            icon: BiBuilding,
        },
        {
            title: 'companySinceYear',
            accessor: 'established_in',
            icon: BsBuildingCheck,
        },
        {
            title: 'taxNumber',
            accessor: 'tax_number',
            icon: BiBuilding,
        },
        {
            title: 'ownerDirector',
            accessor: 'owner',
            icon: TfiBag,
        },
        {
            title: 'taxOffice',
            accessor: 'tax_office',
            icon: CgProfile
        },
    ];

    const getCompanyProfile = async () => {
        try {
            const { data: response } = await axiosInstance.get('/users/company-profile');
            dispatch(saveCompanyData(response.data));
        } catch (error) {
            dispatch(addNotification({ type: "error", message: error.response.data.message }));
        }
    };

    useEffect(() => {
        if (!company)
            getCompanyProfile();
    }, []);

    return (
        <div className='flex flex-col lg:flex-row'>
            <div className='w-full lg:w-9/12 lg:mr-5'>
                <div className='flex flex-col lg:flex-row bg-white p-5'>
                    <div className='flex justify-center items-center mr-5 p-5'>
                        <div className='flex justify-center items-center bg-bgSecondary rounded-full p-5' >
                            <BsTruck size={60} />
                        </div>
                    </div>
                    <div>
                        <div className='bg-bgSecondary p-5 mb-3 mt-5 lg:mt-0'>
                            <p className='font-semibold text-blue-500 flex flex-col lg:flex-row items-center'>
                                {company && company.name}
                                <Button
                                    className='mt-3 lg:mt-0 lg:ml-3 px-2 py-1'
                                    title={`company Id : ${company && company.id}`}
                                />
                            </p>
                        </div>
                        {
                            companyProfile.map((item, index) => (
                                <div key={index} className='flex row'>
                                    <div className='flex flex-row my-2'>
                                        <div className='flex flex-row'>
                                            {
                                                item.icon &&
                                                <span className='mr-3'>
                                                    <item.icon size={24} />
                                                </span>

                                            }
                                            <span className='text-primary font-semibold mr-2'>
                                                {t(item.title)} :
                                            </span>
                                        </div>
                                        <div className='text-primary'>
                                            {company && company[item.accessor]}
                                        </div>
                                    </div>
                                </div>
                            ))

                        }
                    </div>
                </div>
                <CompanyReview
                    id={company?.id}
                    title={company?.title}
                    rating={company?.total_review_count}
                />
            </div>
            <div className='w-full lg:w-3/12'>
                <CompletedTransportCount
                    id={company?.id}
                />
                <div className='my-5 border border-slate-300'>
                    <div className='bg-bgSecondary p-5 flex flex-col lg:flex-row'>
                        <p className='text-primary text-xl w-full'>
                            {t('turnoverLastYear')}
                        </p>
                    </div>
                    <div className='bg-white p-5'>
                        <p>
                            0 RON
                        </p>
                    </div>
                </div>
                <ReviewStats
                    id={company?.id}
                    totalStarCount={company?.total_star_count}
                    totalReviewCount={company?.total_review_count}
                />
                <CompanyFleet
                    id={company?.id}
                />
            </div>
        </div>
    );
};

export default CompanyProfile;