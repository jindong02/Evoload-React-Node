const jwt = require("jsonwebtoken");
const { ExpressError } = require("../utilities");
const { type } = require("../utilities/constantValues");

module.exports.isLoggedIn = async (req, res, next) => {
    try {
        const accessToken = req.headers?.authorization?.split(" ")[1];
        if (accessToken) {
            jwt.verify(accessToken, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
                if (err) {
                    res.clearCookie("refreshToken");
                    throw new ExpressError(401, "Unauthorized");
                } else {
                    req.user = user;
                    next();
                }
            });
        } else {
            res.clearCookie("refreshToken");
            throw new ExpressError(401, "Unauthorized");
        }
    } catch (error) {
        next(error);
    }
};

module.exports.isExpeditor = async (req, res, next) => {
    try {
        const { user } = req;
        if (user.type === type.expeditor) {
            next();
        } else {
            res.clearCookie("refreshToken");
            throw new ExpressError(403, "Forbidden");
        }
    } catch (error) {
        next(error);
    }
};

module.exports.isTransporter = async (req, res, next) => {
    try {
        const { user } = req;
        if (user.type === type.transporter) {
            next();
        } else {
            res.clearCookie("refreshToken");
            throw new ExpressError(403, "Forbidden");
        }
    } catch (error) {
        next(error);
    }
};

module.exports.isPrimaryUser = async (req, res, next) => {
    try {
        const { user } = req;
        if (user.is_primary_user) {
            next();
        } else {
            res.clearCookie("refreshToken");
            throw new ExpressError(403, "Forbidden");
        }
    } catch (error) {
        next(error);
    }
};

module.exports.isVerified = async (req, res, next) => {
    try {
        const { user } = req;
        if (user.is_verified) {
            next();
        } else {
            res.clearCookie("refreshToken");
            throw new ExpressError(403, "Forbidden");
        }
    } catch (error) {
        next(error);
    }
};