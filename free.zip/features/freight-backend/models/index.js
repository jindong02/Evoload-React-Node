const { sequelize } = require("../configs/dbConfig");
const CarType = require("./carType");
const Company = require("./company");
const Country = require("./country");
const CountryCode = require("./countryCode");
const Currency = require("./currency");
const Follower = require("./follower");
const Freight = require("./freight");
const FreightStatus = require("./freightStatus");
const Offer = require("./offer");
const PaymentDeadline = require("./paymentDeadline");
const SpecialRequirement = require("./specialRequirement");
const SupportCategory = require("./supportCategory");
const SupportRequest = require("./supportRequest");
const TransportType = require("./transportType");
const Truck = require("./truck");
const User = require("./user");
const UserType = require("./userType");
const Notifications = require("./notifications");

CarType.hasMany(Truck, {
  foreignKey: { name: "car_type_id", allowNull: false },
  as: "trucks",
});
Truck.belongsTo(CarType, {
  foreignKey: { name: "car_type_id", allowNull: false },
});
CarType.hasMany(Freight, {
  foreignKey: { name: "car_type_id", allowNull: false },
  as: "freights",
});
Freight.belongsTo(CarType, {
  foreignKey: { name: "car_type_id", allowNull: false },
});

Company.hasMany(Offer, {
  foreignKey: { name: "company_id", allowNull: false },
  as: "offers",
});
Offer.belongsTo(Company, {
  foreignKey: { name: "company_id", allowNull: false },
});
Company.hasMany(User, {
  foreignKey: { name: "company_id", allowNull: false },
  as: "users",
});
User.belongsTo(Company, {
  foreignKey: { name: "company_id", allowNull: false },
});
Company.hasMany(Truck, {
  foreignKey: { name: "company_id", allowNull: false },
  as: "trucks",
});
Truck.belongsTo(Company, {
  foreignKey: { name: "company_id", allowNull: false },
});
Company.hasMany(Freight, {
  foreignKey: { name: "company_id", allowNull: false },
  as: "freights",
});
Freight.belongsTo(Company, {
  foreignKey: { name: "company_id", allowNull: false },
});
Company.hasMany(SupportRequest, {
  foreignKey: { name: "company_id", allowNull: false },
  as: "support_requests",
});
SupportRequest.belongsTo(Company, {
  foreignKey: { name: "company_id", allowNull: false },
});

Country.hasMany(Company, {
  foreignKey: { name: "country_id", allowNull: false },
  as: "companies",
});
Company.belongsTo(Country, {
  foreignKey: { name: "country_id", allowNull: false },
});
Country.hasMany(Freight, {
  foreignKey: { name: "from_country_id", allowNull: false },
  as: "freights_from",
});
Freight.belongsTo(Country, {
  foreignKey: { name: "from_country_id", allowNull: false },
  as: "freights_from",
});
Country.hasMany(Freight, {
  foreignKey: { name: "to_country_id", allowNull: false },
  as: "freights_to",
});
Freight.belongsTo(Country, {
  foreignKey: { name: "to_country_id", allowNull: false },
  as: "freights_to",
});

CountryCode.hasMany(User, {
  foreignKey: { name: "country_code_id", allowNull: false },
  as: "users",
});
User.belongsTo(CountryCode, {
  foreignKey: { name: "country_code_id", allowNull: false },
});
CountryCode.hasMany(Freight, {
  foreignKey: { name: "country_code_id", allowNull: true },
  as: "freights",
});
Freight.belongsTo(CountryCode, {
  foreignKey: { name: "country_code_id", allowNull: true },
});

Currency.hasMany(Freight, {
  foreignKey: { name: "currency_id", allowNull: false },
  as: "freights",
});
Freight.belongsTo(Currency, {
  foreignKey: { name: "currency_id", allowNull: false },
});
Currency.hasMany(Offer, {
  foreignKey: { name: "currency_id", allowNull: false },
  as: "offers",
});
Offer.belongsTo(Currency, {
  foreignKey: { name: "currency_id", allowNull: false },
});

Freight.belongsToMany(SpecialRequirement, {
  through: "freight_special_requirement",
  foreignKey: { name: "freight_id", allowNull: false },
  timestamps: false,
  as: "special_requirements",
});
SpecialRequirement.belongsToMany(Freight, {
  through: "freight_special_requirement",
  foreignKey: { name: "special_requirement_id", allowNull: false },
  timestamps: false,
  as: "freights",
});
Freight.hasMany(Offer, {
  foreignKey: { name: "freight_id", allowNull: false },
  as: "offers",
});
Offer.belongsTo(Freight, {
  foreignKey: { name: "freight_id", allowNull: false },
});
Freight.belongsToMany(User, {
  through: Follower,
  foreignKey: { name: "freight_id", allowNull: false },
  timestamps: false,
  as: "follower_users",
  uniqueKey: "id",
});
User.belongsToMany(Freight, {
  through: Follower,
  foreignKey: { name: "user_id", allowNull: false },
  timestamps: false,
  as: "followed_freights",
  uniqueKey: "id",
});
Freight.belongsToMany(Company, {
  through: Follower,
  foreignKey: { name: "freight_id", allowNull: false },
  timestamps: false,
  as: "follower_companies",
  uniqueKey: "id",
});
Company.belongsToMany(Freight, {
  through: Follower,
  foreignKey: { name: "company_id", allowNull: false },
  timestamps: false,
  as: "followed_freights",
  uniqueKey: "id",
});
Freight.belongsToMany(FreightStatus, {
  through: "freight_freight_status",
  foreignKey: { name: "freight_id", allowNull: false },
  as: "freight_statuses",
});
FreightStatus.belongsToMany(Freight, {
  through: "freight_freight_status",
  foreignKey: { name: "freight_status_id", allowNull: false },
  as: "freights",
});

Offer.hasOne(Freight, {
  foreignKey: { name: "offer_id", allowNull: true },
  as: "accepted_freight",
});
Freight.belongsTo(Offer);

PaymentDeadline.hasMany(Freight, {
  foreignKey: { name: "payment_deadline_id", allowNull: false },
  as: "freights",
});
Freight.belongsTo(PaymentDeadline, {
  foreignKey: { name: "payment_deadline_id", allowNull: false },
});

SupportCategory.hasMany(SupportRequest, {
  foreignKey: { name: "support_category_id", allowNull: false },
  as: "support_requests",
});
SupportRequest.belongsTo(SupportCategory, {
  foreignKey: { name: "support_category_id", allowNull: false },
});

TransportType.hasMany(Freight, {
  foreignKey: { name: "transport_type_id", allowNull: false },
  as: "freights",
});
Freight.belongsTo(TransportType, {
  foreignKey: { name: "transport_type_id", allowNull: false },
});

Truck.hasMany(Freight, {
  foreignKey: { name: "truck_id", allowNull: true },
  as: "freights",
});
Freight.belongsTo(Truck);

User.hasMany(Offer, {
  foreignKey: { name: "user_id", allowNull: false },
  as: "offers",
});
Offer.belongsTo(User, { foreignKey: { name: "user_id", allowNull: false } });
User.hasMany(SupportRequest, {
  foreignKey: { name: "user_id", allowNull: false },
  as: "support_requests",
});
SupportRequest.belongsTo(User, {
  foreignKey: { name: "user_id", allowNull: false },
});
User.hasMany(Truck, {
  foreignKey: { name: "user_id", allowNull: false },
  as: "trucks",
});
Truck.belongsTo(User, { foreignKey: { name: "user_id", allowNull: false } });
User.hasOne(Truck, {
  foreignKey: { name: "driver_user_id", allowNull: false },
  as: "driver_truck",
});
Truck.belongsTo(User, {
  foreignKey: { name: "driver_user_id", allowNull: false },
  as: "driver",
});
User.hasMany(Freight, {
  foreignKey: { name: "user_id", allowNull: false },
  as: "freights",
});
Freight.belongsTo(User, { foreignKey: { name: "user_id", allowNull: false } });

UserType.hasMany(User, {
  foreignKey: { name: "user_type_id", allowNull: false },
  as: "users",
});
User.belongsTo(UserType);

sequelize.sync();

module.exports = {
  CarType,
  Company,
  Country,
  CountryCode,
  Currency,
  Follower,
  Freight,
  Offer,
  PaymentDeadline,
  SpecialRequirement,
  SupportCategory,
  SupportRequest,
  TransportType,
  Truck,
  User,
  UserType,
  Notifications,
};
