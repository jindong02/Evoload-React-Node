const { sequelize } = require("../configs/dbConfig");
const { DataTypes } = require("sequelize");
const User = require("./user");

const Follower = sequelize.define(
    "Follower",
    {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
        },
    },
    {
        tableName: "followers",
        freezeTableName: true,
        underscored: true,
    },

);

module.exports = Follower;