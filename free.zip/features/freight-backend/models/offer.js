const { sequelize } = require("../configs/dbConfig");
const { DataTypes } = require("sequelize");

const Offer = sequelize.define(
    "Offer",
    {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
        },
        direct_delivery: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
        },
        offer_price: {
            type: DataTypes.DOUBLE,
            allowNull: false,
        },
        vat_included: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
        },
        loading_date: {
            type: DataTypes.DATE,
            allowNull: false,
        },
        loading_hour: {
            type: DataTypes.TIME,
            allowNull: false,
        },
        unloading_date: {
            type: DataTypes.DATE,
        },
        unloading_hour: {
            type: DataTypes.TIME,
        },
        details: {
            type: DataTypes.STRING(1000),
        },
        status: {
            type: DataTypes.ENUM,
            allowNull: false,
            values: ['active', 'inactive', 'accepted', 'rejected'],
            defaultValue: 'active'
        },
        soft_delete: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: false
        }
    },
    {
        tableName: "offers",
        freezeTableName: true,
        underscored: true,
        createdAt: 'created_at',
        updatedAt: 'updated_at'
    },

);

module.exports = Offer;