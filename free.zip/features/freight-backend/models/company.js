const { sequelize } = require("../configs/dbConfig");
const { DataTypes } = require("sequelize");

const Company = sequelize.define(
    "Company",
    {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
        },
        title: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        street_and_number: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        city:{
            type: DataTypes.STRING,
            allowNull: false,
        },
        established_in: {
            type: DataTypes.INTEGER,
        },
        vat_number: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        tax_number: {
            type: DataTypes.STRING,
        },
        owner: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        tax_office: {
            type: DataTypes.STRING,
        },
        total_star_count: {
            type: DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 0
        },
        total_review_count: {
            type: DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 0
        },
        status: {
            type: DataTypes.ENUM,
            allowNull:false,
            values: ['active', 'inactive'],
            defaultValue: 'active'
        },
        soft_delete: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: false
        }
    },
    {
        tableName: "companies",
        freezeTableName: true,
        underscored: true,
        createdAt: 'created_at',
        updatedAt: 'updated_at',
    },

);
// sync force
// User.sync({ force: true });
module.exports = Company;