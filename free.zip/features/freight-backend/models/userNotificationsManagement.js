const { sequelize } = require("../configs/dbConfig");
const { DataTypes } = require("sequelize");

const UserNotificationsManagement = sequelize.define(
  "UserNotificationsManagement",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: DataTypes.INTEGER,
    },
    user_type:{
      type: DataTypes.STRING,
    },
    notification_id: {
      type: DataTypes.INTEGER,
    },
    cleared_date_time: {
      type: DataTypes.DATE,
    },
    is_clear: {
      type: DataTypes.TINYINT,
    },
    is_offer_notification:{
      type: DataTypes.BOOLEAN,
      allowNull:false,
      defaultValue: false
  }
  },
  {
    tableName: "user_notifications_management",
    underscored: true,
  }
);

module.exports = UserNotificationsManagement;
