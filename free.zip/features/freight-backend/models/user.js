const { sequelize } = require("../configs/dbConfig");
const { DataTypes } = require("sequelize");

const User = sequelize.define(
    "User",
    {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
        },
        username: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true
        },
        email: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true
        },
        password: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        first_name: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        surname: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        full_name: {
            type: DataTypes.VIRTUAL,
            get() {
                return `${this.first_name} ${this.surname}`;
            },
            set(value) {
                throw new Error('Do not try to set the `fullName` value!');
            }
        },
        function: {
            type: DataTypes.STRING,
        },
        phone: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        is_primary_user: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
        },
        type:{
            type: DataTypes.ENUM,
            allowNull:false,
            values: ['expeditor', 'transporter'],
        },
        is_verified: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: false
        },
        verification_code: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        verification_code_expires_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        verification_code_attempts: {
            type: DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 0
        },
        status: {
            type: DataTypes.ENUM,
            allowNull:false,
            values: ['active', 'inactive'],
            defaultValue: 'active'
        },
        soft_delete: {
            type: DataTypes.BOOLEAN,
            allowNull:false,
            defaultValue: false
        },
       
    },
    {
        tableName: "users",
        freezeTableName: true,
        underscored: true,
        createdAt: 'created_at',
        updatedAt: 'updated_at',
        scopes: {
            login: {
                attributes: ['id', 'username', 'status']
            }
        }
    },

);
// sync force
// User.sync({ force: true });
module.exports = User;