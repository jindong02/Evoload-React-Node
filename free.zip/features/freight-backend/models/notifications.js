const { sequelize } = require("../configs/dbConfig");
const { DataTypes } = require("sequelize");

const Notifications = sequelize.define(
  "Notifications",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: DataTypes.INTEGER,
    },
    text: {
      type: DataTypes.STRING,
    },
    user_type: {
      type: DataTypes.STRING,
    },

    status: {
      type: DataTypes.STRING,
    },
    created_at: {
      type: DataTypes.DATE,
    },
    cleared_date_time: {
      type: DataTypes.DATE,
    },
    read_date_time: {
      type: DataTypes.DATE,
    },
    cleared_by: {
      type: DataTypes.STRING,
    },
    read_by: {
      type: DataTypes.STRING,
    },
    is_clear: {
      type: DataTypes.TINYINT,
    },
    is_read: {
      type: DataTypes.TINYINT,
    },
  },
  {
    tableName: "notifications",
    underscored: true,
  }
);

module.exports = Notifications;
