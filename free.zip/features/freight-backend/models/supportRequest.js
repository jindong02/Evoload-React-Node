const { sequelize } = require("../configs/dbConfig");
const { DataTypes } = require("sequelize");

const SupportRequest = sequelize.define(
    "SupportRequest",
    {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
        },
        first_name: {
            type: DataTypes.STRING,
            allowNull: false
        },
        surname: {
            type: DataTypes.STRING,
            allowNull: false
        },
        email: {
            type: DataTypes.STRING,
            allowNull: false
        },
        subject: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        message: {
            type: DataTypes.STRING(5000),
            allowNull: false,
        },
        status: {
            type: DataTypes.ENUM,
            allowNull:false,
            values: ['pending', 'in progress', 'resolved'],
            defaultValue: 'pending'
        },
        soft_delete: {
            type: DataTypes.BOOLEAN,
            allowNull:false,
            defaultValue: false
        }
    },
    {
        tableName: "support_requests",
        freezeTableName: true,
        underscored: true,
        createdAt: 'created_at',
        updatedAt: 'updated_at'
    },

);

module.exports = SupportRequest;