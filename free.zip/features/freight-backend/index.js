const express = require("express");
const app = express();
const cors = require("cors");
const morgan = require("morgan");
const cookieParser = require("cookie-parser");
require("dotenv").config();
const socketIO = require("socket.io");

const { connectToDatabase } = require("./configs/dbConfig");
const {
  carTypeRoute,
  companyRoute,
  countryRoute,
  userTypeRoute,
  userRoute,
  supportCategoryRoute,
  supportRequestRoute,
  truckRoute,
  currencyRoute,
  transportTypeRoute,
  paymentDeadlineRoute,
  freightRoute,
  offerRoute,
  transportRoute,
  freightStatusRoute,
  countryCodeRoute,
  NotificationsRoute,
} = require("./routes");
const { modelService, ExpressError } = require("./utilities");

const PORT = process.env.PORT || 3000;
const STAGE = process.env.STAGE || "dev";

app.use(cookieParser());
app.use(morgan("dev", { skip: (req, res) => STAGE !== "dev" }));
app.use(
  cors({
    origin: true,
    credentials: true,
    exposedHeaders: "Authorization",
  })
);
app.use(express.json({ limit: "30mb", extended: true }));
app.use(express.urlencoded({ limit: "30mb", extended: true }));

app.use("/car-types", carTypeRoute);
app.use("/companies", companyRoute);
app.use("/countries", countryRoute);
app.use("/country-codes", countryCodeRoute);
app.use("/currencies", currencyRoute);
app.use("/freights", freightRoute);
app.use("/notifications", NotificationsRoute);
app.use("/freight-statuses", freightStatusRoute);
app.use("/offers", offerRoute);
app.use("/payment-deadlines", paymentDeadlineRoute);
app.use("/support-categories", supportCategoryRoute);
app.use("/support-requests", supportRequestRoute);
app.use("/transports", transportRoute);
app.use("/transport-types", transportTypeRoute);
app.use("/trucks", truckRoute);
app.use("/users", userRoute);
app.use("/user-types", userTypeRoute);

app.get("/", (req, res) => {
  res.send("Server is running");
});

app.use("*", (req, res, next) => {
  next(new ExpressError(404, "Page not found"));
});

app.use((err, req, res, next) => {
  if (err.name && err.name.includes("Sequelize"))
    err.message =
      (err.errors?.length && err.errors[0]?.message) || "Database Error";
  const { statusCode = 500, message = "Internal Server Error" } = err;
  modelService.errorResponse(res, statusCode, message);
});

const server = app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT} : http://localhost:${PORT}`);
});
const io = socketIO(server, { cors: { origin: "*" } });


// io.on("connection", (socket) => {
//   console.log("New client connected");

//   // When the client sends the "notifications" event
//   socket.on("notifications", (data) => {
//     console.log("Received notification data on the server:");
//     console.log(data);

//     // Broadcast the notification data to all connected clients except the sender
//     socket.broadcast.emit("notifications", data);
//   });

//   // When the client disconnects from the socket.io server
//   socket.on("disconnect", () => {
//     console.log("Client disconnected");
//   });
// });





io.on("connection", (socket) => {
  console.log("Web Socket connection established");

  socket.on("message", (data) => {
    io.emit("message", data);
  });

  socket.on("disconnect", () => {
    console.log("A client disconnected");
  });

  socket.on("freight", (data) => {
    io.emit("freight", data);
  });

  socket.on("offer", (data) => {
    io.emit("offer", data);
  });
  socket.on("accept-offer", (data) => {
    io.emit("accept-offer", data);
  });

  socket.on("add-truck", (data) => {
    io.emit("add-truck", data);
  });

  socket.on("finish-transport", (data) => {
    io.emit("finish-transport", data);
  });



  socket.on("notifications", (data) => {
    console.log("Received notification data on the server:");
    console.log(data);

    // Emit the received notification data to all connected clients
    io.emit("notifications", data);
  });
});

connectToDatabase();
