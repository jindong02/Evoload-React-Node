const express = require('express');
const router = express.Router();
const { supportCategoryController } = require('../controllers');
const catchAsync = require('../utilities/catchAsync');
const { isLoggedIn, isVerified } = require('../middlewares/auth');

router.get('/', isLoggedIn, isVerified, catchAsync(supportCategoryController.getAllSupportCategories));

module.exports = router;