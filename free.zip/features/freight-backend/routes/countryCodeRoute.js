const express = require('express');
const router = express.Router();
const { countryCodeController } = require('../controllers');
const catchAsync = require('../utilities/catchAsync');

router.get('/', catchAsync(countryCodeController.getAllCountryCodes));
router.get('/:id', catchAsync(countryCodeController.getCountryCodeById));

module.exports = router;