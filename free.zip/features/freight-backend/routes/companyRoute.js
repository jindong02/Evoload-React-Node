const express = require('express');
const router = express.Router();
const { companyController } = require('../controllers');
const catchAsync = require('../utilities/catchAsync');
const { isLoggedIn, isVerified } = require('../middlewares/auth');

router.get('/:id/reviews', isLoggedIn, isVerified, catchAsync(companyController.getCompanyReviews));
router.get('/:id/review-stats', isLoggedIn, isVerified, catchAsync(companyController.getCompanyReviewStatsByRating));
router.get('/:id/completed-transport-count', isLoggedIn, isVerified, catchAsync(companyController.getCompletedTransportCount));
router.get('/:id/fleet', isLoggedIn, isVerified, catchAsync(companyController.getCompanyFleet));
router.get('/:id', isLoggedIn, isVerified, catchAsync(companyController.getCompanyById));

module.exports = router;