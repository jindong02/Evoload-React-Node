const express = require('express');
const router = express.Router();
const { offerController } = require('../controllers');
const catchAsync = require('../utilities/catchAsync');
const { isLoggedIn, isTransporter, isVerified } = require('../middlewares/auth');

router.get('/my-offers', isLoggedIn, isVerified, isTransporter, catchAsync(offerController.getMyOffers));
router.get('/:id', isLoggedIn, isVerified, catchAsync(offerController.getOfferById));
router.delete('/:id', isLoggedIn, isVerified, isTransporter, catchAsync(offerController.deleteOfferById));


module.exports = router;