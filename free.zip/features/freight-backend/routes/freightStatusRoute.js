const express = require('express');
const router = express.Router();
const { freightStatusController } = require('../controllers');
const catchAsync = require('../utilities/catchAsync');
const { isLoggedIn, isTransporter, isVerified } = require('../middlewares/auth');

router.get('/', isLoggedIn, isVerified, isTransporter, catchAsync(freightStatusController.getAllFreightStatuses));

module.exports = router;