const express = require('express');
const router = express.Router();
const { transportTypeController } = require('../controllers');
const catchAsync = require('../utilities/catchAsync');
const { isLoggedIn, isVerified } = require('../middlewares/auth');

router.get('/', isLoggedIn, isVerified, catchAsync(transportTypeController.getAllTransportTypes));

module.exports = router;