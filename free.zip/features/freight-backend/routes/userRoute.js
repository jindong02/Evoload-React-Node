const express = require('express');
const router = express.Router();
const { userController } = require('../controllers');
const catchAsync = require('../utilities/catchAsync');
const { isLoggedIn, isExpeditor, isPrimaryUser, isVerified } = require('../middlewares/auth');

router.post('/log-in', catchAsync(userController.loginUser));
router.post('/register', catchAsync(userController.registerUser));
router.get('/get-access-token', catchAsync(userController.getAccessToken));
router.get('/logout', isLoggedIn, catchAsync(userController.logout));
router.get('/me', isLoggedIn, catchAsync(userController.getCurrentUser));
router.get('/company-profile', isLoggedIn, catchAsync(userController.getCompanyProfile));
router.get('/', isLoggedIn, isVerified, isExpeditor, isPrimaryUser, catchAsync(userController.getAllUsers));
router.post('/', isLoggedIn, isVerified, isExpeditor, isPrimaryUser, catchAsync(userController.createUser));
router.put('/', isLoggedIn, isVerified, catchAsync(userController.updateUser));
router.post('/verify-email', catchAsync(userController.verifyEmail));
router.post('/send-verification-code', isLoggedIn, catchAsync(userController.sendVerificationCode));

module.exports = router;