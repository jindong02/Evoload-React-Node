const express = require('express');
const router = express.Router();
const { truckController } = require('../controllers');
const catchAsync = require('../utilities/catchAsync');
const { isLoggedIn, isTransporter, isPrimaryUser, isVerified } = require('../middlewares/auth');

router.get('/truck-list', isLoggedIn, isVerified, isTransporter, catchAsync(truckController.getTruckList));
router.get('/', isLoggedIn, isVerified, catchAsync(truckController.getAllTrucks));
router.post('/', isLoggedIn, isVerified, isTransporter, isPrimaryUser, catchAsync(truckController.addTruck));
router.delete('/:id', isLoggedIn, isVerified, isTransporter, isPrimaryUser, catchAsync(truckController.deleteTruck));

module.exports = router;