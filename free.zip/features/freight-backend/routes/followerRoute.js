// const express = require('express');
// const router = express.Router();
// const {  followerController } = require('../controllers');
// const catchAsync = require('../utilities/catchAsync');
// const { isLoggedIn, isExpeditor, isTransporter } = require('../middlewares/auth');

// router.get('/my-freights', isLoggedIn, isExpeditor, catchAsync(freightController.getMyFreights));
// router.get('/:id', isLoggedIn, catchAsync(freightController.getFreightById));
// router.put('/:id', isLoggedIn, isExpeditor, catchAsync(freightController.updateFreightStatus));
// router.delete('/:id', isLoggedIn, isExpeditor, catchAsync(freightController.deleteFreight));
// router.post('/:id/follow', isLoggedIn, isTransporter, catchAsync(followerController.addFollower));
// router.post('/:id/offer', isLoggedIn, isTransporter, catchAsync(freightController.addOffer));
// router.get('/', isLoggedIn, catchAsync(freightController.getAllFreights));
// router.post('/', isLoggedIn, isExpeditor, catchAsync(freightController.addFreight));

// module.exports = router;