const express = require('express');
const router = express.Router();
const { supportRequestController } = require('../controllers');
const catchAsync = require('../utilities/catchAsync');
const { isLoggedIn, isVerified } = require('../middlewares/auth');

router.post('/', isLoggedIn, isVerified, catchAsync(supportRequestController.createOne));

module.exports = router;