const express = require('express');
const router = express.Router();
const { currencyController } = require('../controllers');
const catchAsync = require('../utilities/catchAsync');
const { isLoggedIn, isVerified } = require('../middlewares/auth');

router.get('/', isLoggedIn, isVerified, catchAsync(currencyController.getAllCurrencies));

module.exports = router;