const express = require("express");
const router = express.Router();
const { notificatiosController } = require("../controllers");
const catchAsync = require("../utilities/catchAsync");
const {
  isLoggedIn,
  isExpeditor,
  isTransporter,
  isPrimaryUser,
  isVerified,
} = require("../middlewares/auth");

router.post(
  "/",
  isLoggedIn,
  isVerified,
  catchAsync(notificatiosController.addNotifications)
);
router.post(
  "/clearall",
  isLoggedIn,
  isVerified,
  catchAsync(notificatiosController.clearNotifications)
)
router.post(
  "/setOfferNotification",
  isLoggedIn,
  isVerified,
  catchAsync(notificatiosController.setOfferNotifications)
)
router.post(
  "/getOfferNotification",
  isLoggedIn,
  isVerified,
  catchAsync(notificatiosController.getOfferNotification)
);
router.get(
  "/",
  isLoggedIn,
  isVerified,
  catchAsync(notificatiosController.getAllNotifications)
);

module.exports = router;
