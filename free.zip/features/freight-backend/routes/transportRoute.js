const express = require('express');
const router = express.Router();
const { transportController } = require('../controllers');
const catchAsync = require('../utilities/catchAsync');
const { isLoggedIn, isTransporter, isPrimaryUser, isVerified } = require('../middlewares/auth');

router.get('/active-transports', isLoggedIn, isVerified, isTransporter, catchAsync(transportController.getActiveTransports));
router.get('/completed-transports', isLoggedIn, isVerified, isTransporter, catchAsync(transportController.getCompletedTransports));
router.delete('/:id/completed-transport', isLoggedIn, isVerified, isTransporter, isPrimaryUser, catchAsync(transportController.deleteCompletedTransport));

module.exports = router;