const express = require('express');
const router = express.Router();
const { countryController } = require('../controllers');
const catchAsync = require('../utilities/catchAsync');

router.get('/', catchAsync(countryController.getAllCountries));

module.exports = router;