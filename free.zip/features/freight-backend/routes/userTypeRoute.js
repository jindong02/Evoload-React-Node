const express = require('express');
const router = express.Router();
const { userTypeController } = require('../controllers');
const catchAsync = require('../utilities/catchAsync');
const { isLoggedIn, isVerified } = require('../middlewares/auth');

router.get('/', catchAsync(userTypeController.getAllUserTypes));
router.get('/users/:id', isLoggedIn, isVerified, catchAsync(userTypeController.getUserTypeByUserId));

module.exports = router;