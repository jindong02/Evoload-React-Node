const type = {
    expeditor: 'expeditor',
    transporter: 'transporter'
};

Object.freeze(type);

module.exports = {
    type
}