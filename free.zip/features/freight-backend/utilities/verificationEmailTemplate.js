module.exports = (email, verificationCode) => {
  return `<div style="background-color: #f5f5f5; padding: 20px;">
        <div style="background-color: #fff; padding: 20px; border-radius: 10px;">
            <h1 style="text-align: center; color: #000;">Welcome to the Transporter App</h1>
            <p style="text-align: center; color: #000;">Please click the button below to verify your email address</p>
            <button type="button">Click Me!</button>
              <div style="text-align: center;">
                <a href="${process.env.WEB_URL}/verify-email?email=${email}&verification_code=${verificationCode}" style="background-color: #000; color: #fff; padding: 10px 20px; border-radius: 5px; text-decoration: none;">Verify Email</a>
            </div>
        </div>
    </div>`;
};
