const nodemailer = require("nodemailer");

module.exports = async (receiver, subject, body) => {
    let transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
            user: process.env.SENDER_EMAIL,
            pass: process.env.SENDER_PASSWORD,
        },
    });
    let info = await transporter.sendMail({
        from: process.env.SENDER_EMAIL, // sender address
        to: receiver, // list of receivers
        subject: subject, // Subject line
        html: body,
    });
}