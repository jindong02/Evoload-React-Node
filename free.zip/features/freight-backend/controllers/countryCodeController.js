const { CountryCode } = require("../models");
const { modelService, ExpressError } = require("../utilities");
const { dataValidator } = require("../utilities");


module.exports.getAllCountryCodes = async (req, res) => {
    const countryCodes = await CountryCode.findAll({
        where: {
            status: 'active',
            soft_delete: false
        },
        ...modelService.queryOptions(req)
    });
    modelService.successResponse(res, 200, countryCodes);
};

module.exports.getCountryCodeById = async (req, res) => {
    const countryCode = await CountryCode.findByPk(req.params.id);
    modelService.successResponse(res, 200, countryCode);
};