const { Op } = require("sequelize");
const { Offer, TransportType, Freight, Currency, Company, Country } = require("../models");
const { modelService, ExpressError } = require("../utilities");
const { dataValidator } = require("../utilities");
const { type } = require("../utilities/constantValues");


module.exports.getMyOffers = async (req, res) => {
    const where = {};
    if (req.user.is_primary_user) {
        where.company_id = req.user.company_id;
    } else {
        where.user_id = req.user.id;
    }
    const offers = await Offer.findAndCountAll({
        where: {
            [Op.and]: [
                {
                    soft_delete: false,
                    ...where,
                },
                {
                    [Op.or]: [
                        { status: 'active' },
                        { status: 'inactive' },
                    ]
                }
            ]
        },
        ...modelService.queryOptions(req),
        include: [
            {
                model: Currency,
            },
            {
                model: Freight,
                include: [
                    {
                        model: TransportType,
                    },
                    {
                        model: Company,
                    },
                    {
                        model: Country,
                        as: "freights_from",
                        attributes: ["title"]
                    },
                    {
                        model: Country,
                        as: "freights_to",
                        attributes: ["title"]
                    }
                ]
            }
        ]
    });
    modelService.successResponse(res, 200, offers);
};

module.exports.getOfferById = async (req, res) => {
    const { id } = req.params;
    const where = {};
    if (req.user.type === type.expeditor) {
        const freight = await Freight.findOne({
            where: {
                offer_id: id,
                [Op.or]: [
                    {
                        company_id: req.user.company_id,
                    },
                    {
                        user_id: req.user.id,
                    },
                ],
            },
        });
        if (!freight) throw new ExpressError(400, "Offer not found");
    } else {
        if (req.user.is_primary_user) {
            where.company_id = req.user.company_id;
        } else {
            where.user_id = req.user.id;
        }
    }
    const offer = await Offer.findOne({
        where: {
            id,
            soft_delete: false,
            ...where,
        },
        include: [
            {
                model: Currency,
            },
            {
                model: Freight,
                include: [
                    {
                        model: TransportType,
                    },
                    {
                        model: Company,
                    }
                ]
            }
        ]
    });
    modelService.successResponse(res, 200, offer);
};

module.exports.deleteOfferById = async (req, res) => {
    const { id } = req.params;
    const where = {};
    if (req.user.is_primary_user) {
        where.company_id = req.user.company_id;
    } else {
        where.user_id = req.user.id;
    }
    const offer = await Offer.findOne({
        where: {
            id,
            soft_delete: false,
            ...where,
        }
    });
    if (!offer) throw new ExpressError(400, "Offer not found");

    const acceptedFreight = await Freight.findOne({
        where: {
            offer_id: id,
        }
    });
    if (acceptedFreight) throw new ExpressError(400, "Accepted offer cannot be deleted");
    await offer.destroy();
    modelService.successResponse(res, 200, {}, "Offer deleted successfully");
};