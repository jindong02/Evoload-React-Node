const bcrypt = require("bcrypt");
const jwt = require('jsonwebtoken');
const { sequelize } = require("../configs/dbConfig");
const { User, Company } = require("../models");
const { modelService, ExpressError, sendMail, verificationEmailTemplate } = require("../utilities");
const { dataValidator } = require("../utilities");
const { Op } = require("sequelize");
const { v4: uuidv4 } = require('uuid');

module.exports.registerUser = async (req, res) => {
    const { error, value } = dataValidator.isValidRegisterUserObject(req.body);
    if (error) throw new ExpressError(400, error.details[0].message);
    const currentDateTime = new Date();
    currentDateTime.setSeconds(currentDateTime.getSeconds() + process.env.VERIFICATION_VALIDITY);
    const user = await sequelize.transaction(async (t) => {
        const registeredCompany = await Company.create({
            title: value.title,
            owner: value.owner,
            street_and_number: value.streetAndNumber,
            city: value.city,
            vat_number: value.vatNumber,
            country_id: value.countryId,
        }, { transaction: t });

        const salt = await bcrypt.genSalt(12);
        const hashedPassword = await bcrypt.hash(value.password, salt);

        const registeredUser = await User.create({
            first_name: value.firstName,
            surname: value.surname,
            phone: value.phone,
            email: value.email,
            username: value.username,
            password: hashedPassword,
            type: value.type,
            user_type_id: value.userTypeId,
            company_id: registeredCompany.id,
            country_code_id: value.countryCodeId,
            is_primary_user: true,
            verification_code: uuidv4(),
            verification_code_expires_at: currentDateTime
        }, { transaction: t });

        delete registeredUser.dataValues.password;
        return registeredUser;
    });

    const subject = "Please confirm your email";
    sendMail(user.email, subject, verificationEmailTemplate(user.email, user.verification_code));

    const accessToken = jwt.sign({
        id: user.id,
        type: user.type,
        is_primary_user: user.is_primary_user,
        company_id: user.company_id,
        is_verified: user.is_verified
    }, process.env.ACCESS_TOKEN_SECRET, { expiresIn: '3600s' });

    const refreshToken = jwt.sign({
        id: user.id,
        type: user.type,
        is_primary_user: user.is_primary_user,
        company_id: user.company_id,
        is_verified: user.is_verified
    }, process.env.REFRESH_TOKEN_SECRET, { expiresIn: '7d' });

    res.cookie('refreshToken', refreshToken, {
        httpOnly: true,
    });

    const response = {
        accessToken,
        id: user.id,
        first_name: user.first_name,
        surname: user.surname,
        phone: user.phone,
        email: user.email,
        username: user.username,
        user_type_id: user.user_type_id,
        company_id: user.company_id,
        is_primary_user: user.is_primary_user,
        type: user.type,
        is_verified: user.is_verified
    };
    modelService.successResponse(res, 200, response, "User registered successfully");
};

module.exports.loginUser = async (req, res) => {
    const { error, value } = dataValidator.isValidLoginUserObject(req.body);
    if (error) throw new ExpressError(400, error.details[0].message);

    const user = await User.findOne({
        where: {
            [Op.and]: [
                { [Op.or]: [{ username: value.username }, { email: value.username }] },
                { status: 'active' },
                { soft_delete: false }
            ]
        }
    });
    if (!user) throw new ExpressError(401, "Invalid credentials");
    const isValidUser = await bcrypt.compare(value.password, user.password);
    if (!isValidUser) throw new ExpressError(401, "Invalid credentials");

    const accessToken = jwt.sign({
        id: user.id,
        type: user.type,
        is_primary_user: user.is_primary_user,
        company_id: user.company_id,
        is_verified: user.is_verified
    }, process.env.ACCESS_TOKEN_SECRET, { expiresIn: '3600s' });

    const refreshToken = jwt.sign({
        id: user.id,
        type: user.type,
        is_primary_user: user.is_primary_user,
        company_id: user.company_id,
        is_verified: user.is_verified
    }, process.env.REFRESH_TOKEN_SECRET, { expiresIn: '7d' });

    res.cookie('refreshToken', refreshToken, {
        httpOnly: true,
    });

    const response = {
        accessToken,
        id: user.id,
        first_name: user.first_name,
        surname: user.surname,
        phone: user.phone,
        email: user.email,
        username: user.username,
        type: user.type,
        is_primary_user: user.is_primary_user,
        country_code_id: user.country_code_id,
        user_type_id: user.user_type_id,
        company_id: user.company_id,
        is_verified: user.is_verified
    };
    modelService.successResponse(res, 200, response, "User Logged In successfully");
};

module.exports.getAccessToken = async (req, res) => {
    const refreshToken = req.cookies.refreshToken;
    if (refreshToken) {
        jwt.verify(
            refreshToken,
            process.env.REFRESH_TOKEN_SECRET,
            (err, user) => {
                if (err) {
                    res.clearCookie("refreshToken");
                    throw new ExpressError(401, "Unauthorized");
                } else {
                    const accessToken = jwt.sign(
                        {
                            id: user.id,
                            type: user.type,
                            is_primary_user: user.is_primary_user,
                            company_id: user.company_id,
                            is_verified: user.is_verified
                        },
                        process.env.ACCESS_TOKEN_SECRET,
                        { expiresIn: "3600s" }
                    );
                    modelService.successResponse(res, 200, { accessToken });
                }
            }
        );
    } else {
        res.clearCookie("refreshToken");
        throw new ExpressError(401, "Unauthorized");
    }

};

module.exports.logout = async (req, res) => {
    res.clearCookie("refreshToken");
    modelService.successResponse(res, 200, null, "Logged out successfully");
};

module.exports.getCurrentUser = async (req, res) => {
    const user = await User.findByPk(req.user.id);
    if (!user) {
        res.clearCookie("refreshToken");
        throw new ExpressError(401, "Unauthorized");
    }

    delete user.dataValues.password;
    modelService.successResponse(res, 200, user);
};

module.exports.updateUser = async (req, res) => {
    const { error, value } = dataValidator.isValidUpdateUserObject(req.body);
    if (error) throw new ExpressError(400, error.details[0].message);
    const user = await User.findByPk(req.user.id);
    if (!user) throw new ExpressError(404, "User not found");

    let hashedPassword;
    if (value.password) {
        const salt = await bcrypt.genSalt(12);
        hashedPassword = await bcrypt.hash(value.password, salt);
    }

    const updatedUser = await user.update({
        first_name: value.firstName,
        surname: value.surname,
        function: value.function,
        phone: value.phone,
        username: value.username,
        email: value.email,
        password: hashedPassword,
        country_code_id: value.countryCodeId,
    });
    delete updatedUser.dataValues.password;
    modelService.successResponse(res, 200, updatedUser, "User updated successfully");
};

module.exports.getCompanyProfile = async (req, res) => {
    const user = await User.findByPk(req.user.id);
    if (!user) throw new ExpressError(404, "User not found");
    const company = await Company.findByPk(user.company_id);
    if (!company) throw new ExpressError(404, "Company not found");
    modelService.successResponse(res, 200, company);
};

module.exports.createUser = async (req, res) => {
    const user = await User.findByPk(req.user.id);
    if (!user) throw new ExpressError(404, "User not found");

    const { error, value } = dataValidator.isValidCreateUserObject({
        ...req.body,
        companyId: user.company_id,
        userTypeId: user.user_type_id
    });
    if (error) throw new ExpressError(400, error.details[0].message);

    const salt = await bcrypt.genSalt(12);
    const hashedPassword = await bcrypt.hash(value.password, salt);

    await User.create({
        first_name: value.firstName,
        surname: value.surname,
        phone: value.phone,
        email: value.email,
        username: value.username,
        password: hashedPassword,
        company_id: user.company_id,
        user_type_id: value.userTypeId,
        is_primary_user: false,
        type: value.type,
        country_code_id: value.countryCodeId,
    });
    modelService.successResponse(res, 200, {}, "User created successfully");
};

module.exports.getAllUsers = async (req, res) => {
    const user = await User.findByPk(req.user.id);
    if (!user) throw new ExpressError(404, "User not found");
    const users = await User.findAll({
        where: {
            id: { [Op.ne]: user.id },
            company_id: user.company_id,
            soft_delete: false,
        }
    });
    modelService.successResponse(res, 200, users);
};

module.exports.sendVerificationCode = async (req, res) => {
    const { id } = req.body;
    const user = await User.findOne({
        where: {
            id,
            status: "active",
            verification_code_expires_at: {
                [Op.or]: [
                    { [Op.gte]: new Date() },
                    { [Op.eq]: null }
                ]
            },
            is_verified: false,
        },
    });
    if (!user) throw new ExpressError(404, "User not found");

    const currentDateTime = new Date();
    currentDateTime.setSeconds(currentDateTime.getSeconds() + process.env.VERIFICATION_VALIDITY);
    user.update({
        verification_code: uuidv4(),
        verification_code_expires_at: currentDateTime,
    });

    const subject = "Please confirm your email";
    sendMail(user.email, subject, verificationEmailTemplate(user.email, user.verification_code));
    modelService.successResponse(res, 200, {}, "Verification code sent successfully");
};

module.exports.verifyEmail = async (req, res) => {
    const { email, verificationCode } = req.body;

    const user = await User.findOne({
        where: {
            email,
            verification_code: verificationCode,
            verification_code_expires_at: { [Op.gte]: new Date() },
            status: "active",
        },
    });
    if (!user) {
        const isUser = await User.findOne({
            where: {
                email,
            },
        });
        if (!isUser) throw new ExpressError(404, "User not found");
        if (isUser.verification_code_attempts >= process.env.MAX_WRONG_VERIFICATION_ATTEMPTS) {
            await isUser.update({
                verification_code_attempts: isUser.verification_code_attempts + 1,
                status: "inactive",
            });
            throw new ExpressError(400, "User account has been deactivated due to multiple failed verification attempts");
        } else {
            await isUser.update({
                verification_code_attempts: isUser.verification_code_attempts + 1,
            });
            throw new ExpressError(400, "Invalid verification code");
        }
    }

    await user.update({
        is_verified: true,
        verification_code: null,
        verification_code_expires_at: null,
        verification_code_attempts: 0,
    });
    modelService.successResponse(res, 200, {}, "Email verified successfully");
};