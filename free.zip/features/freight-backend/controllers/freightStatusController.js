const { Follower, User, Freight, Company, SpecialRequirement, TransportType, PaymentDeadline, CarType, Currency, Offer } = require("../models");
const FreightStatus = require("../models/freightStatus");
const { modelService, ExpressError } = require("../utilities");
const { dataValidator } = require("../utilities");


module.exports.addFollower = async (req, res) => {
    const { id } = req.params;
    const user = await User.findOne({
        where: {
            id: req.user.id,
            status: 'active',
            soft_delete: false
        }
    });
    if (!user) throw new ExpressError(401, "Unauthorized");

    const { error, value } = dataValidator.isValidCreateFollowerObject({
        freightId: id,
        companyId: user.company_id,
        userId: user.id,
    });
    if (error) throw new ExpressError(400, error.details[0].message);

    const isAlreadyFollowed = await Follower.findOne({
        where: {
            freight_id: value.freightId,
            company_id: value.companyId,
            user_id: value.userId,
        }
    });
    if (isAlreadyFollowed) throw new ExpressError(400, "Freight already followed");

    await Follower.create({
        freight_id: value.freightId,
        company_id: value.companyId,
        user_id: value.userId,
    });
    modelService.successResponse(res, 201, {}, "Freight followed successfully");
};

module.exports.getAllFreightStatuses = async (req, res) => {
    const freightStatuses = await FreightStatus.findAll({
        where: {
            status: 'active',
            soft_delete: false
        },
        ...modelService.queryOptions(req)
    });
    modelService.successResponse(res, 200, freightStatuses);
};

module.exports.updateFreightStatus = async (req, res) => {
    const { id } = req.params;
    const { error, value } = dataValidator.isValidUpdateFreightStatusObject(req.body);
    if (error) throw new ExpressError(400, error.details[0].message);

    const where = {};
    if(req.user.is_primary_user) {
        where.company_id = req.user.company_id;
    } else {
        where.user_id = req.user.id;
    }
    const givenOffer = await Offer.findOne({
        where: {
            id: value.offerId,
            status: 'active',
            soft_delete: false,
            ...where
        }
    });
    if (!givenOffer) throw new ExpressError(404, "Invalid offer");

    const freight = await Freight.findOne({
        where: {
            id: id,
            status: 'started',
            soft_delete: false,
            offer_id: value.offerId
        }
    });
    if (!freight) throw new ExpressError(404, "Freight not found");

    const ans = await freight.addFreight_statuses([value.freightStatusId]);
    modelService.successResponse(res, 200, {}, "Freight status updated successfully");
};