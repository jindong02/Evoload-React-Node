const { Country } = require("../models");
const { modelService, ExpressError } = require("../utilities");
const { dataValidator } = require("../utilities");


module.exports.getAllCountries = async (req, res) => {
    const countries = await Country.findAll({
        where: {
            status: 'active',
            soft_delete: false
        },
        ...modelService.queryOptions(req)
    });
    modelService.successResponse(res, 200, countries);
};