const carTypeController = require("./carTypeController");
const companyController = require("./companyController");
const countryController = require("./countryController");
const countryCodeController = require("./countryCodeController");
const currencyController = require("./currencyController");
const followerController = require("./followerController");
const freightController = require("./freightController");
const notificatiosController = require("./notificationsController");
const freightStatusController = require("./freightStatusController");
const offerController = require("./offerController");
const paymentDeadlineController = require("./paymentDeadlineController");
const supportCategoryController = require("./supportCategoryController");
const supportRequestController = require("./supportRequestController");
const transportController = require("./transportController");
const transportTypeController = require("./transportTypeController");
const truckController = require("./truckController");
const userController = require("./userController");
const userTypeController = require("./userTypeController");

module.exports = {
  carTypeController,
  companyController,
  countryController,
  countryCodeController,
  currencyController,
  followerController,
  freightController,
  freightStatusController,
  offerController,
  paymentDeadlineController,
  supportCategoryController,
  supportRequestController,
  transportController,
  transportTypeController,
  truckController,
  userController,
  userTypeController,
  notificatiosController,
};
