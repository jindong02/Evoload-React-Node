const { sequelize } = require("../configs/dbConfig");
const {
  Freight,
  User,
  SpecialRequirement,
  Company,
  TransportType,
  PaymentDeadline,
  CarType,
  Currency,
  Country,
  Truck,
  CountryCode,
  Follower,
} = require("../models");
const FreightStatus = require("../models/freightStatus");
const Offer = require("../models/offer");
const { modelService, ExpressError } = require("../utilities");
const { dataValidator } = require("../utilities");
const { Sequelize, Op } = require("sequelize");
const { type } = require("../utilities/constantValues");
const moment = require("moment");

module.exports.addFreight = async (req, res) => {
  const user = await User.findOne({
    where: {
      id: req.user.id,
      status: "active",
      soft_delete: false,
    },
  });

  if (!user) throw new ExpressError("User not found", 404);
  const { error, value } = dataValidator.isValidCreateFreightObject({
    ...req.body,
    companyId: user.company_id,
    userId: user.id,
  });

  if (error) throw new ExpressError(400, error.details[0].message);

  await sequelize.transaction(async (t) => {
    const freight = await Freight.create(
      {
        loading_asap_loading: value.loadingAsapLoading,
        loading_from_date: value.loadingFromDate,
        loading_to_date: value.loadingToDate,
        loading_between: value.loadingBetween,
        loading_and: value.loadingAnd,
        unloading_direct_delivery: value.directDelivery,
        unloading_from_date: value.unloadingFromDate,
        unloading_to_date: value.unloadingToDate,
        unloading_between: value.unloadingBetween,
        unloading_and: value.unloadingAnd,
        distance: value.distance,
        suggested_price: value.suggestedPrice,
        vat_included: value.vatIncluded,
        phone: value.phone,
        show_phone: value.showPhone,
        weight: value.weight,
        articles: value.articles,
        volume: value.volume,
        reference: value.referenceNo,
        observations: value.observations,
        from_country_id: value.loadingFromCountryId,
        to_country_id: value.unloadingToCountryId,
        car_type_id: value.carTypeId,
        currency_id: value.currencyId,
        payment_deadline_id: value.paymentDeadlineId,
        transport_type_id: value.transportTypeId,
        country_code_id: value.countryCodeId,
        company_id: value.companyId,
        user_id: value.userId,
      },
      { transaction: t }
    );

    const specialRequirementIds = [];
    if (value.specialRequirementOne) specialRequirementIds.push(1);
    if (value.specialRequirementTwo) specialRequirementIds.push(2);
    if (value.specialRequirementThree) specialRequirementIds.push(3);
    await freight.setSpecial_requirements([...specialRequirementIds], {
      transaction: t,
    });
  });

  const currentDate = moment().format("DD-MM-YYYY HH:mm:ss");
  const jsonData = {
    value: {
      ...value,
      publishedOn: currentDate,
    },
  };
  modelService.successResponse(
    res,
    200,
    jsonData,
    "Freight created successfully"
  );
};

module.exports.getAllFreights = async (req, res) => {
  let uniqueHiddenFreightIds = [];
  if (req.user.type === type.transporter) {
    const hiddenFreightIds = [];
    const followedFreights = await Follower.findAll({
      where: {
        user_id: req.user.id,
      },
      attributes: ["freight_id"],
    });
    followedFreights.forEach((freight) =>
      hiddenFreightIds.push(freight.freight_id)
    );
    const sentOffers = await Offer.findAll({
      where: {
        user_id: req.user.id,
        status: "active",
        soft_delete: false,
      },
      attributes: ["freight_id"],
    });
    sentOffers.forEach((offer) => hiddenFreightIds.push(offer.freight_id));
    uniqueHiddenFreightIds = [...new Set(hiddenFreightIds)];
  }
  const freights = await Freight.findAndCountAll({
    where: {
      id: {
        [Op.notIn]: uniqueHiddenFreightIds,
      },
      status: "opened",
      soft_delete: false,
    },
    ...modelService.queryOptions(req),
    include: [
      {
        model: Company,
      },
      {
        model: SpecialRequirement,
        as: "special_requirements",
      },
      {
        model: TransportType,
      },
      {
        model: PaymentDeadline,
      },
      {
        model: CarType,
      },
      {
        model: Currency,
      },
      {
        model: Country,
        as: "freights_from",
        attributes: ["title"],
      },
      {
        model: Country,
        as: "freights_to",
        attributes: ["title"],
      },
      {
        model: CountryCode,
      },
    ],
  });
  modelService.successResponse(res, 200, freights);
};

module.exports.getFreightById = async (req, res) => {
  const { id } = req.params;
  const freight = await Freight.findOne({
    where: {
      id,
      soft_delete: false,
    },
    include: [
      {
        model: Company,
      },
      {
        model: SpecialRequirement,
        as: "special_requirements",
      },
      {
        model: TransportType,
      },
      {
        model: PaymentDeadline,
      },
      {
        model: CarType,
      },
      {
        model: Currency,
      },
      {
        model: Country,
        as: "freights_from",
        attributes: ["title"],
      },
      {
        model: Country,
        as: "freights_to",
        attributes: ["title"],
      },
    ],
  });
  if (!freight) throw new ExpressError("Freight not found", 404);
  modelService.successResponse(res, 200, freight);
};

module.exports.getMyFreights = async (req, res) => {
  const where = {};
  if (req.user.is_primary_user) {
    where.company_id = req.user.company_id;
  } else {
    where.user_id = req.user.id;
  }
  const freights = await Freight.findAndCountAll({
    where: {
      [Op.and]: [
        {
          soft_delete: false,
          ...where,
        },
        {
          [Op.or]: [
            { status: "opened" },
            { status: "closed" },
            { status: "cancelled" },
          ],
        },
      ],
    },
    ...modelService.queryOptions(req),
    include: [
      {
        model: Currency,
      },
      {
        model: CarType,
      },
      {
        model: Offer,
        as: "offers",
        attributes: ["id"],
        required: false,
        where: {
          status: "active",
          soft_delete: false,
        },
      },
      {
        model: Country,
        as: "freights_from",
        attributes: ["title"],
      },
      {
        model: Country,
        as: "freights_to",
        attributes: ["title"],
      },
    ],
  });
  modelService.successResponse(res, 200, freights);
};

module.exports.updateFreightStatus = async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  if (status !== "opened" && status !== "closed")
    throw new ExpressError(400, "Invalid status value.");
  const where = {};
  if (req.user.is_primary_user) {
    where.company_id = req.user.company_id;
  } else {
    where.user_id = req.user.id;
  }
  const freight = await Freight.findOne({
    where: {
      [Op.or]: [
        {
          id,
          status: "opened",
          soft_delete: false,
          ...where,
        },
        {
          id,
          status: "closed",
          soft_delete: false,
          ...where,
        },
      ],
    },
  });
  if (!freight) throw new ExpressError(400, "Freight not found");
  await freight.update({
    status,
  });
  modelService.successResponse(
    res,
    200,
    {},
    "Freight status updated successfully"
  );
};

module.exports.deleteFreight = async (req, res) => {
  const { id } = req.params;
  const where = {};
  if (req.user.is_primary_user) {
    where.company_id = req.user.company_id;
  } else {
    where.user_id = req.user.id;
  }
  await Freight.update(
    {
      soft_delete: true,
    },
    {
      where: {
        [Op.or]: [
          {
            id,
            status: "opened",
            soft_delete: false,
            ...where,
          },
          {
            id,
            status: "closed",
            soft_delete: false,
            ...where,
          },
          {
            id,
            status: "cancelled",
            soft_delete: false,
            ...where,
          },
        ],
      },
    }
  );
  modelService.successResponse(res, 200, {}, "Freight deleted successfully");
};

module.exports.addOffer = async (req, res) => {
  const { id } = req.params;
  const user = await User.findOne({
    where: {
      id: req.user.id,
      status: "active",
      soft_delete: false,
    },
  });
  const freight = await Freight.findOne({
    where: {
      id,
      status: "opened",
      soft_delete: false,
    },
  });
  if (!freight) throw new ExpressError(400, "Freight not found");
  const { error, value } = dataValidator.isValidCreateOfferObject({
    ...req.body,
    freightId: freight.id,
    userId: user.id,
    companyId: user.company_id,
  });
  if (error) throw new ExpressError(400, error.details[0].message);

  const isOfferExist = await Offer.findOne({
    where: {
      freight_id: freight.id,
      user_id: user.id,
      company_id: user.company_id,
      soft_delete: false,
    },
  });
  if (isOfferExist) throw new ExpressError(400, "Offer already sent");

  await Offer.create({
    direct_delivery: value.directDelivery,
    offer_price: value.offerPrice,
    vat_included: value.vatIncluded,
    loading_date: value.loadingDate,
    loading_hour: value.loadingHour,
    unloading_date: value.unloadingDate,
    unloading_hour: value.unloadingHour,
    details: value.details,
    currency_id: value.currencyId,
    freight_id: value.freightId,
    user_id: value.userId,
    company_id: value.companyId,
  });
  modelService.successResponse(res, 200, {}, "Offer sent successfully");
};

module.exports.updateOffer = async (req, res) => {
  const { id, offerId } = req.params;
  const freight = await Freight.findOne({
    where: {
      id,
      status: "opened",
      soft_delete: false,
    },
  });
  if (!freight)
    throw new ExpressError(
      400,
      "Freight not found or Freight is already accepted"
    );
  const { error, value } = dataValidator.isValidEditOfferObject({
    ...req.body,
  });
  if (error) throw new ExpressError(400, error.details[0].message);

  const where = {};
  if (req.user.is_primary_user) {
    where.company_id = req.user.company_id;
  } else {
    where.user_id = req.user.id;
  }
  const offer = await Offer.findOne({
    where: {
      id: offerId,
      soft_delete: false,
      ...where,
    },
  });
  if (!offer) throw new ExpressError(404, "Offer not found");

  await offer.update({
    direct_delivery: value.directDelivery,
    offer_price: value.offerPrice,
    vat_included: value.vatIncluded,
    loading_date: value.loadingDate,
    loading_hour: value.loadingHour,
    unloading_date: value.unloadingDate,
    unloading_hour: value.unloadingHour,
    details: value.details,
    currency_id: value.currencyId,
  });
  modelService.successResponse(res, 200, {}, "Offer updated successfully");
};

module.exports.getOffersByFreightId = async (req, res) => {
  const { id } = req.params;
  const where = {};
  if (req.user.is_primary_user) {
    where.company_id = req.user.company_id;
  } else {
    where.user_id = req.user.id;
  }
  const freight = await Freight.findOne({
    where: {
      id,
      status: "opened",
      soft_delete: false,
      ...where,
    },
  });
  if (!freight) throw new ExpressError(400, "Freight not found");

  const offers = await Offer.findAndCountAll({
    where: {
      freight_id: freight.id,
      status: "active",
      soft_delete: false,
    },
    ...modelService.queryOptions(req),
    include: [
      {
        model: Company,
        include: [
          {
            model: Country,
          },
        ],
      },
      {
        model: Currency,
      },
    ],
  });
  modelService.successResponse(res, 200, offers);
};

module.exports.acceptOffer = async (req, res) => {
  const { id } = req.params;
  const where = {};
  if (req.user.is_primary_user) {
    where.company_id = req.user.company_id;
  } else {
    where.user_id = req.user.id;
  }
  const isAvailable = await Freight.findOne({
    where: {
      id,
      status: "opened",
      soft_delete: false,
      offer_id: null,
      ...where,
    },
  });
  if (!isAvailable)
    throw new ExpressError(400, "Freight not found or Offer already accepted");

  const { error, value } = dataValidator.isValidAcceptOfferObject(req.body);
  if (error) throw new ExpressError(400, error.details[0].message);

  const result = await sequelize.transaction(async (t) => {
    await isAvailable.update(
      {
        offer_id: value.offerId,
        status: "offered",
      },
      { transaction: t }
    );

    const acceptedOffer = await Offer.findOne({
      where: {
        id: value.offerId,
        freight_id: id,
        soft_delete: false,
      },
    });
    if (!acceptedOffer) throw new ExpressError(400, "Offer not found");

    await acceptedOffer.update(
      {
        status: "accepted",
      },
      { transaction: t }
    );

    await Offer.update(
      {
        status: "rejected",
      },
      {
        where: {
          id: {
            [Op.ne]: value.offerId,
          },
          freight_id: id,
          soft_delete: false,
        },
      },
      { transaction: t }
    );
  });
  modelService.successResponse(res, 200, {}, "Offer accepted successfully");
};

module.exports.getActiveFreights = async (req, res) => {
  const where = {};
  if (req.user.is_primary_user) {
    where.company_id = req.user.company_id;
  } else {
    where.user_id = req.user.id;
  }
  const freights = await Freight.findAndCountAll({
    where: {
      [Op.and]: [
        {
          soft_delete: false,
          ...where,
        },
        {
          [Op.or]: [
            { status: "offered" },
            { status: "pending" },
            { status: "started" },
          ],
        },
      ],
    },
    ...modelService.queryOptions(req),
    include: [
      {
        model: Currency,
      },
      {
        model: CarType,
      },
      {
        model: Truck,
        attributes: ["license_number"],
        include: [
          {
            model: User,
            as: "driver",
            attributes: ["first_name", "surname", "full_name", "phone"],
          },
        ],
      },
      {
        model: FreightStatus,
        as: "freight_statuses",
      },
      {
        model: Country,
        as: "freights_from",
        attributes: ["title"],
      },
      {
        model: Country,
        as: "freights_to",
        attributes: ["title"],
      },
    ],
  });
  modelService.successResponse(res, 200, freights);
};

module.exports.getCompletedFreights = async (req, res) => {
  const where = {};
  if (req.user.is_primary_user) {
    where.company_id = req.user.company_id;
  } else {
    where.user_id = req.user.id;
  }
  const freights = await Freight.findAndCountAll({
    where: {
      status: "completed",
      soft_delete: false,
      ...where,
    },
    ...modelService.queryOptions(req),
    include: [
      {
        model: Currency,
      },
      {
        model: CarType,
      },
      {
        model: Offer,
        as: "offers",
        attributes: ["id"],
        required: false,
        where: {
          status: "active",
          soft_delete: false,
        },
      },
      {
        model: Country,
        as: "freights_from",
        attributes: ["title"],
      },
      {
        model: Country,
        as: "freights_to",
        attributes: ["title"],
      },
    ],
  });
  modelService.successResponse(res, 200, freights);
};

module.exports.setTruckForFreight = async (req, res) => {
  const { id } = req.params;
  const { error, value } = dataValidator.isValidSetTruckForFreightObject(
    req.body
  );
  if (error) throw new ExpressError(400, error.details[0].message);

  const freight = await Freight.findOne({
    where: {
      id,
      status: "offered",
      soft_delete: false,
    },
    include: [
      {
        model: Offer,
        as: "offers",
      },
    ],
  });
  if (!freight) throw new ExpressError(400, "Freight not found");

  if (req.user.is_primary_user) {
    if (freight.offers[0].company_id !== req.user.company_id)
      throw new ExpressError(400, "Freight not found");
  } else {
    if (freight.offers[0].user_id !== req.user.id)
      throw new ExpressError(400, "Freight not found");
  }

  const where = {};
  if (req.user.is_primary_user) {
    where.company_id = req.user.company_id;
  } else {
    where.user_id = req.user.id;
  }

  const truck = await Truck.findOne({
    where: {
      id: value.truckId,
      status: "active",
      soft_delete: false,
      ...where,
    },
  });
  if (!truck) throw new ExpressError(400, "Truck not found");

  await freight.update({
    truck_id: value.truckId,
    status: "pending",
  });
  modelService.successResponse(res, 200, {}, "Truck set successfully");
};

module.exports.startFreight = async (req, res) => {
  const { id } = req.params;
  const where = {};
  if (req.user.is_primary_user) {
    where.company_id = req.user.company_id;
  } else {
    where.user_id = req.user.id;
  }
  const freight = await Freight.findOne({
    where: {
      id,
      status: "pending",
      soft_delete: false,
      ...where,
    },
  });
  if (!freight) throw new ExpressError(400, "Freight not found");

  await freight.update({
    status: "started",
  });
  modelService.successResponse(res, 200, {}, "Freight started successfully");
};

module.exports.finishFreight = async (req, res) => {
  const { id } = req.params;
  const where = {};
  if (req.user.is_primary_user) {
    where.company_id = req.user.company_id;
  } else {
    where.user_id = req.user.id;
  }
  const freight = await Freight.findOne({
    where: {
      id,
      status: "started",
      soft_delete: false,
      ...where,
    },
  });
  if (!freight) throw new ExpressError(400, "Freight not found");

  await freight.update({
    status: "completed",
  });
  modelService.successResponse(res, 200, {}, "Freight completed successfully");
};

module.exports.addExpeditorReview = async (req, res) => {
  const { id } = req.params;
  const { error, value } = dataValidator.isValidAddExpeditorReviewObject(
    req.body
  );
  if (error) throw new ExpressError(400, error.details[0].message);
  const where = {};
  if (req.user.is_primary_user) {
    where.company_id = req.user.company_id;
  } else {
    where.user_id = req.user.id;
  }
  const freight = await Freight.findOne({
    where: {
      id,
      status: "completed",
      soft_delete: false,
    },
    include: [
      {
        model: Offer,
        as: "offers",
        where: {
          ...where,
        },
      },
    ],
  });
  if (!freight) throw new ExpressError(400, "Freight not found");

  const company = await Company.findOne({
    where: {
      id: freight.company_id,
    },
  });

  const result = await sequelize.transaction(async (t) => {
    await freight.update(
      {
        expeditor_review: value.expeditorReview,
        expeditor_review_stars: value.expeditorReviewStars,
        expeditor_review_date: new Date(),
      },
      { transaction: t }
    );

    await company.update(
      {
        total_star_count: company.total_star_count + value.expeditorReviewStars,
        total_review_count: company.total_review_count + 1,
      },
      { transaction: t }
    );
  });
  modelService.successResponse(res, 200, {}, "Review added successfully");
};

module.exports.addTransporterReview = async (req, res) => {
  const { id } = req.params;
  const { error, value } = dataValidator.isValidAddTransporterReviewObject(
    req.body
  );
  if (error) throw new ExpressError(400, error.details[0].message);

  const where = {};
  if (req.user.is_primary_user) {
    where.company_id = req.user.company_id;
  } else {
    where.user_id = req.user.id;
  }
  const freight = await Freight.findOne({
    where: {
      id,
      status: "completed",
      soft_delete: false,
      ...where,
    },
  });
  if (!freight) throw new ExpressError(400, "Freight not found");

  const offer = await Offer.findOne({
    where: {
      id: freight.offer_id,
    },
  });

  const company = await Company.findOne({
    where: {
      id: offer.company_id,
    },
  });

  const result = await sequelize.transaction(async (t) => {
    await freight.update(
      {
        transporter_review: value.transporterReview,
        transporter_review_stars: value.transporterReviewStars,
        transporter_review_date: new Date(),
      },
      { transaction: t }
    );

    await company.update(
      {
        total_star_count:
          company.total_star_count + value.transporterReviewStars,
        total_review_count: company.total_review_count + 1,
      },
      { transaction: t }
    );
  });
  modelService.successResponse(res, 200, {}, "Review added successfully");
};

module.exports.getEditableFreightById = async (req, res) => {
  const { id } = req.params;
  const freight = await Freight.findOne({
    where: {
      [Op.and]: [
        {
          id,
          soft_delete: false,
        },
        {
          [Op.or]: [{ status: "opened" }, { status: "closed" }],
        },
      ],
    },
    include: [
      {
        model: Company,
      },
      {
        model: SpecialRequirement,
        as: "special_requirements",
      },
      {
        model: TransportType,
      },
      {
        model: PaymentDeadline,
      },
      {
        model: CarType,
      },
      {
        model: Currency,
      },
      {
        model: Country,
        as: "freights_from",
        attributes: ["title"],
      },
      {
        model: Country,
        as: "freights_to",
        attributes: ["title"],
      },
      {
        model: CountryCode,
      },
    ],
  });
  if (!freight) throw new ExpressError(404, "Freight not found");
  modelService.successResponse(res, 200, freight);
};

module.exports.getViewableFreightById = async (req, res) => {
  const { id } = req.params;
  const freight = await Freight.findOne({
    where: {
      [Op.and]: [
        {
          id,
          soft_delete: false,
        },
        {
          [Op.or]: [{ status: { [Op.ne]: "closed" } }],
        },
      ],
    },
    include: [
      {
        model: Company,
      },
      {
        model: SpecialRequirement,
        as: "special_requirements",
      },
      {
        model: TransportType,
      },
      {
        model: PaymentDeadline,
      },
      {
        model: CarType,
      },
      {
        model: Currency,
      },
      {
        model: Country,
        as: "freights_from",
        attributes: ["title"],
      },
      {
        model: Country,
        as: "freights_to",
        attributes: ["title"],
      },
      {
        model: CountryCode,
      },
    ],
  });
  if (!freight) throw new ExpressError(404, "Freight not found");
  modelService.successResponse(res, 200, freight);
};

module.exports.editFreight = async (req, res) => {
  const { id } = req.params;
  const { error, value } = dataValidator.isValidEditFreightObject(req.body);
  if (error) throw new ExpressError(400, error.details[0].message);
  const where = {};
  if (req.user.is_primary_user) {
    where.company_id = req.user.company_id;
  } else {
    where.user_id = req.user.id;
  }
  const freight = await Freight.findOne({
    where: {
      [Op.and]: [
        {
          id,
          soft_delete: false,
          ...where,
        },
        {
          [Op.or]: [{ status: "opened" }, { status: "closed" }],
        },
      ],
    },
  });
  if (!freight) throw new ExpressError(404, "Freight not found");

  await sequelize.transaction(async (t) => {
    await freight.update(
      {
        loading_asap_loading: value.loadingAsapLoading,
        loading_from_date: value.loadingFromDate,
        loading_to_date: value.loadingToDate,
        loading_between: value.loadingBetween,
        loading_and: value.loadingAnd,
        unloading_direct_delivery: value.directDelivery,
        unloading_from_date: value.unloadingFromDate,
        unloading_to_date: value.unloadingToDate,
        unloading_between: value.unloadingBetween,
        unloading_and: value.unloadingAnd,
        distance: value.distance,
        suggested_price: value.suggestedPrice,
        vat_included: value.vatIncluded,
        phone: value.phone,
        show_phone: value.showPhone,
        weight: value.weight,
        articles: value.articles,
        volume: value.volume,
        reference: value.referenceNo,
        observations: value.observations,
        from_country_id: value.loadingFromCountryId,
        to_country_id: value.unloadingToCountryId,
        car_type_id: value.carTypeId,
        currency_id: value.currencyId,
        payment_deadline_id: value.paymentDeadlineId,
        transport_type_id: value.transportTypeId,
        country_code_id: value.countryCodeId,
      },
      { transaction: t }
    );

    const specialRequirementIds = [];
    if (value.specialRequirementOne) specialRequirementIds.push(1);
    if (value.specialRequirementTwo) specialRequirementIds.push(2);
    if (value.specialRequirementThree) specialRequirementIds.push(3);
    await freight.setSpecial_requirements([...specialRequirementIds], {
      transaction: t,
    });
  });
  modelService.successResponse(res, 200, {}, "Freight updated successfully");
};

module.exports.deleteCompletedFreight = async (req, res) => {
  const { id } = req.params;
  const freight = await Freight.findOne({
    where: {
      id,
      status: "completed",
      soft_delete: false,
      company_id: req.user.company_id,
    },
  });
  if (!freight) throw new ExpressError(404, "Freight not found");
  await freight.update({
    soft_delete: true,
  });
  modelService.successResponse(res, 200, {}, "Freight deleted successfully");
};

module.exports.cancelFreight = async (req, res) => {
  const { id } = req.params;
  if (req.user.type === type.expeditor) {
    const where = {};
    if (req.user.is_primary_user) {
      where.company_id = req.user.company_id;
    } else {
      where.user_id = req.user.id;
    }
    const freight = await Freight.findOne({
      where: {
        id,
        status: "offered",
        soft_delete: false,
        ...where,
      },
    });
    if (!freight) throw new ExpressError(404, "Freight not found");
    await freight.update({
      status: "cancelled",
    });
    modelService.successResponse(
      res,
      200,
      {},
      "Freight cancelled successfully"
    );
  } else {
    const where = {};
    if (req.user.is_primary_user) {
      where.company_id = req.user.company_id;
    } else {
      where.user_id = req.user.id;
    }
    const freight = await Freight.findOne({
      where: {
        id,
        status: "offered",
        soft_delete: false,
      },
      include: [
        {
          model: Offer,
          where: {
            ...where,
          },
        },
      ],
    });
    if (!freight) throw new ExpressError(404, "Freight not found");
    await freight.update({
      status: "cancelled",
    });
    modelService.successResponse(
      res,
      200,
      {},
      "Freight cancelled successfully"
    );
  }
};
