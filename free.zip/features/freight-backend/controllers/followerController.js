const { Op } = require("sequelize");
const { Follower, User, Freight, Company, SpecialRequirement, TransportType, PaymentDeadline, CarType, Currency, Country, CountryCode, Offer } = require("../models");
const { modelService, ExpressError } = require("../utilities");
const { dataValidator } = require("../utilities");


module.exports.addFollower = async (req, res) => {
    const { id } = req.params;
    const user = await User.findOne({
        where: {
            id: req.user.id,
            status: 'active',
            soft_delete: false
        }
    });
    if (!user) throw new ExpressError(401, "Unauthorized");

    const { error, value } = dataValidator.isValidCreateFollowerObject({
        freightId: id,
        companyId: user.company_id,
        userId: user.id,
    });
    if (error) throw new ExpressError(400, error.details[0].message);

    const isAlreadyFollowed = await Follower.findOne({
        where: {
            freight_id: value.freightId,
            company_id: value.companyId,
            user_id: value.userId,
        }
    });
    if (isAlreadyFollowed) throw new ExpressError(400, "Freight already followed");

    await Follower.create({
        freight_id: value.freightId,
        company_id: value.companyId,
        user_id: value.userId,
    });
    modelService.successResponse(res, 201, {}, "Freight followed successfully");
};

module.exports.getFollowedFreights = async (req, res) => {
    const hiddenFreightIds = [];
    const where = {};
    if (req.user.is_primary_user) {
        where.company_id = req.user.company_id;
    } else {
        where.user_id = req.user.id;
    }
    const sentOffers = await Offer.findAll({
        where: {
            status: 'active',
            soft_delete: false,
            ...where,
        },
        attributes: ['freight_id'],
    });
    sentOffers.forEach(offer => hiddenFreightIds.push(offer.freight_id));

    const FollowedFreights = await Follower.findAll({
        where: {
            freight_id: {
                [Op.notIn]: hiddenFreightIds
            },
            ...where,
        }
    });

    const freightIds = FollowedFreights.map(freight => freight.freight_id);
    const freights = await Freight.findAndCountAll({
        where: {
            id: freightIds,
            status: 'opened',
            soft_delete: false
        },
        ...modelService.queryOptions(req),
        include: [
            {
                model: Company,
            }, {
                model: SpecialRequirement,
                as: "special_requirements",
            }, {
                model: TransportType,
            }, {
                model: PaymentDeadline,
            }, {
                model: CarType,
            }, {
                model: Currency,
            }, {
                model: Country,
                as: "freights_from",
                attributes: ["title"]
            }, {
                model: Country,
                as: "freights_to",
                attributes: ["title"]
            }, {
                model: CountryCode
            }
        ]
    });
    modelService.successResponse(res, 200, freights);
};