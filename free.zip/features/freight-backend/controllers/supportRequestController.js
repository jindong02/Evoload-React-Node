const { SupportRequest, User } = require("../models");
const { modelService, ExpressError } = require("../utilities");
const { dataValidator } = require("../utilities");


module.exports.createOne = async (req, res) => {
    const user = await User.findOne({
        where: {
            id: req.user.id,
            status: "active",
            soft_delete: false
        },
        attributes: ["id", "company_id"]
    });
    if (!user) throw new ExpressError(404, "User not found");

    const { error, value } = dataValidator.isValidCreateSupportRequestObject({
        ...req.body,
        companyId: user.company_id,
        userId: user.id
    });
    if (error) throw new ExpressError(400, error.details[0].message);
    await SupportRequest.create({
        first_name: value.firstName,
        surname: value.surname,
        email: value.email,
        subject: value.subject,
        message: value.message,
        support_category_id: value.supportCategoryId,
        company_id: value.companyId,
        user_id: value.userId
    })
    modelService.successResponse(res, 201, {}, "Support request submitted successfully");
};