const { Op, Sequelize } = require("sequelize");
const { Company, User, Freight, Offer, TransportType, Truck, CarType, Country } = require("../models");
const { modelService, ExpressError } = require("../utilities");
const { dataValidator } = require("../utilities");
const { type } = require("../utilities/constantValues");

module.exports.getCompanyReviews = async (req, res) => {
    const { id } = req.params;
    const company = await Company.findOne({
        where: {
            id,
            soft_delete: false,
        },
        include: [
            {
                model: User,
                as: "users",
                required: true,
                attributes: ["type"],
                where: {
                    is_primary_user: true,
                },
            }
        ],
        attributes: ["id"]
    });
    if (!company) throw new ExpressError(404, "Company not found");
    let reviews;
    if (company.users[0].type === type.expeditor) {
        reviews = await Freight.findAndCountAll({
            where: {
                expeditor_review_stars: {
                    [Op.ne]: null
                },
                company_id: company.id,
                status: 'completed',
                soft_delete: false,
            },
            ...modelService.queryOptions(req),
            include: [
                {
                    model: Offer,
                    required: true,
                    include: [
                        {
                            model: Company,
                            required: true,
                            attributes: ["id", "title"]
                        },
                    ],
                    attributes: ["id", "company_id"]
                },
                {
                    model: TransportType,
                    attributes: ["id", "title"]
                },
                {
                    model: Country,
                    as: "freights_from",
                    attributes: ["title"]
                },
                {
                    model: Country,
                    as: "freights_to",
                    attributes: ["title"]
                },
            ],
            attributes: ["id", "expeditor_review", "expeditor_review_stars", "expeditor_review_date"]
        });
    } else {
        const myOffers = await Offer.findAll({
            where: {
                status: 'active',
                soft_delete: false,
                company_id: company.id
            },
            attributes: ["id"]
        });
        const myOfferIds = myOffers.map((item) => item.id);
        reviews = await Freight.findAndCountAll({
            where: {
                transporter_review_stars: {
                    [Op.ne]: null
                },
                offer_id: myOfferIds,
                status: 'completed',
                soft_delete: false,
            },
            ...modelService.queryOptions(req),
            include: [
                {
                    model: Company,
                    required: true,
                    attributes: ["id", "title"]
                },
                {
                    model: TransportType,
                    attributes: ["id", "title"]
                },
                {
                    model: Country,
                    as: "freights_from",
                    attributes: ["title"]
                },
                {
                    model: Country,
                    as: "freights_to",
                    attributes: ["title"]
                },
            ],
            attributes: ["id", "transporter_review", "transporter_review_stars", "transporter_review_date"]
        });
    }
    modelService.successResponse(res, 200, reviews);
};

module.exports.getCompanyById = async (req, res) => {
    const { id } = req.params;
    const company = await Company.findByPk(id);
    if (!company) throw new ExpressError(404, "Company not found");
    modelService.successResponse(res, 200, company);
};

module.exports.getCompanyReviewStatsByRating = async (req, res) => {
    const { id } = req.params;
    const company = await Company.findOne({
        where: {
            id,
            soft_delete: false,
        },
        include: [
            {
                model: User,
                as: "users",
                required: true,
                attributes: ["type"],
                where: {
                    is_primary_user: true,
                },
            }
        ],
        attributes: ["id"]
    });
    if (!company) throw new ExpressError(404, "Company not found");
    let reviewStats;
    if (company.users[0].type === type.expeditor) {
        reviewStats = await Freight.findAndCountAll({
            where: {
                expeditor_review_stars: {
                    [Op.ne]: null
                },
                company_id: company.id,
                status: 'completed',
                soft_delete: false,
            },
            attributes: [Sequelize.fn('COUNT', 'id')],
            group: ['expeditor_review_stars'],
        });
    } else {
        const myOffers = await Offer.findAll({
            where: {
                status: 'active',
                soft_delete: false,
                company_id: company.id
            },
            attributes: ["id"]
        });
        const myOfferIds = myOffers.map((item) => item.id);
        reviewStats = await Freight.findAndCountAll({
            where: {
                transporter_review_stars: {
                    [Op.ne]: null
                },
                offer_id: myOfferIds,
                status: 'completed',
                soft_delete: false,
            },
            attributes: [Sequelize.fn('COUNT', 'id')],
            group: ['transporter_review_stars'],
        });
    }
    modelService.successResponse(res, 200, reviewStats);
};

module.exports.getCompletedTransportCount = async (req, res) => {
    const { id } = req.params;
    const company = await Company.findOne({
        where: {
            id,
            soft_delete: false,
        },
        include: [
            {
                model: User,
                as: "users",
                required: true,
                attributes: ["type"],
                where: {
                    is_primary_user: true,
                },
            }
        ],
        attributes: ["id"]
    });
    if (!company) throw new ExpressError(404, "Company not found");
    const response = {
        type: company.users[0].type,
        count: 0
    }
    if (company.users[0].type === type.expeditor) {
        response.count = await Freight.count({
            where: {
                company_id: id,
                status: 'completed',
            },
        });
    } else {
        const myOffers = await Offer.findAll({
            where: {
                status: 'active',
                company_id: company.id
            },
            attributes: ["id"]
        });
        const myOfferIds = myOffers.map((item) => item.id);
        response.count = await Freight.count({
            where: {
                offer_id: myOfferIds,
                status: 'completed',
            },
        });
    }
    modelService.successResponse(res, 200, response);
};

module.exports.getCompanyFleet = async (req, res) => {
    const { id } = req.params;
    const company = await Company.findOne({
        where: {
            id,
            soft_delete: false,
        },
        include: [
            {
                model: User,
                as: "users",
                required: true,
                attributes: ["type"],
                where: {
                    is_primary_user: true,
                },
            }
        ],
        attributes: ["id"]
    });
    if (!company) throw new ExpressError(404, "Company not found");
    let fleet;
    if (company.users[0].type === type.expeditor) {
        fleet = null;
    } else {
        fleet = await Truck.findAndCountAll({
            where: {
                status: 'active',
                soft_delete: false,
                company_id: company.id,
            },
            attributes: [Sequelize.fn('COUNT', 'id')],
            include: [
                {
                    model: CarType,
                    attributes: ["id", "title"]
                },
            ],
            group: ['car_type_id'],
        });
    }
    modelService.successResponse(res, 200, fleet);
};