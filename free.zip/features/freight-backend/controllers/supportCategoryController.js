const { SupportCategory } = require("../models");
const { modelService, ExpressError } = require("../utilities");
const { dataValidator } = require("../utilities");


module.exports.getAllSupportCategories = async (req, res) => {
    const supportCategories = await SupportCategory.findAll({
        where: {
            status: 'active',
            soft_delete: false
        }, ...modelService.queryOptions(req)
    });
    modelService.successResponse(res, 200, supportCategories);
};