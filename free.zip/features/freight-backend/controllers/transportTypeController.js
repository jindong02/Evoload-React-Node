const { TransportType } = require("../models");
const { modelService, ExpressError } = require("../utilities");

module.exports.getAllTransportTypes = async (req, res) => {
    const transportTypes = await TransportType.findAll({
        where: {
            status: 'active',
            soft_delete: false
        },
        ...modelService.queryOptions(req),
    });
    modelService.successResponse(res, 200, transportTypes);
};