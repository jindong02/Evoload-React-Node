const { CarType } = require("../models");
const { modelService, ExpressError } = require("../utilities");
const { dataValidator } = require("../utilities");


module.exports.getAllCarTypes = async (req, res) => {
    const carTypes = await CarType.findAll({
        where: {
            status: 'active',
            soft_delete: false
        },
        ...modelService.queryOptions(req)
    });
    modelService.successResponse(res, 200, carTypes);
};

module.exports.getCarTypeById = async (req, res) => {
    const carType = await CarType.findByPk(req.params.id);
    modelService.successResponse(res, 200, carType);
};

module.exports.createCarType = async (req, res) => {
    const { error, value } = dataValidator.isValidCreateCarTypeObject(req.body);
    if (error) throw new ExpressError(400, error.details[0].message);
    const carType = await CarType.create(req.body);
    modelService.successResponse(res, 201, carType);
};
