const { UserType ,User} = require("../models");
const { modelService, ExpressError } = require("../utilities");
const { dataValidator } = require("../utilities");


module.exports.getAllUserTypes = async (req, res) => {
    const userTypes = await UserType.findAll(modelService.queryOptions(req));
    modelService.successResponse(res, 200, userTypes);
};

module.exports.getUserTypeByUserId = async (req, res) => {
    const user = await User.findByPk(req.params.id);
    if (!user) throw new ExpressError(404, "User not found");
    const userType = await UserType.findByPk(user.user_type_id);
    if (!userType) throw new ExpressError(404, "User type not found");
    modelService.successResponse(res, 200, userType);
};