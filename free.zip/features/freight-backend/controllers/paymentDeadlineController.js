const { PaymentDeadline } = require("../models");
const { modelService, ExpressError } = require("../utilities");


module.exports.getAllPaymentDeadlines = async (req, res) => {
    const paymentDeadlines = await PaymentDeadline.findAll({
        where: {
            status: 'active',
            soft_delete: false
        }, ...modelService.queryOptions(req)
    });
    modelService.successResponse(res, 200, paymentDeadlines);
};