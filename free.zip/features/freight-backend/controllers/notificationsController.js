const { sequelize } = require("../configs/dbConfig");
const {
  User,
  Notifications,
} = require("../models");
const FreightStatus = require("../models/freightStatus");
const Offer = require("../models/offer");
const { modelService, ExpressError } = require("../utilities");
const { dataValidator } = require("../utilities");
const { Sequelize, Op } = require("sequelize");
const { type } = require("../utilities/constantValues");
const moment = require("moment");
const UserNotificationsManagement = require("../models/userNotificationsManagement");

module.exports.addNotifications = async (req, res) => {
  const { text, status, created_at, user_id, user_type } = req.body;
  const user = await User.findOne({
    where: {
      id: user_id,
      status: "active",
      soft_delete: false,
    },
  });

  if (!user) throw new ExpressError("User not found", 404);
  await sequelize.transaction(async (t) => {
    const notifications = await Notifications.create(
      {
        user_id: user_id,
        user_type: user_type,
        text: text,
        status: status,
        created_at: created_at,
      },
      { transaction: t }
    );
  });

  const currentDate = moment().format("DD-MM-YYYY HH:mm:ss");

  const jsonData = {
    value: {
      user_id: 1,
      text: text,
      status: status,
      created_date: created_at,
    },
  };

  modelService.successResponse(
    res,
    200,
    "Notification created successfully",
    jsonData
  );
};

module.exports.clearNotifications = async (req, res) => {
  const { user_id , notification_id , is_clear } = req.body;
  const user = await User.findOne({
    where: {
      id: user_id,
      status: "active",
      soft_delete: false,
    },
  });

  if (!user) throw new ExpressError("User not found", 404);
  const currentDate = moment().format("DD-MM-YYYY HH:mm:ss");
  await sequelize.transaction(async (t) => {
    const notifications = await UserNotificationsManagement.create(
      {
        user_id: user_id,
        notification_id: notification_id,
        is_clear: is_clear,
      },
      { transaction: t }
    );
  });

  modelService.successResponse(
    res,
    200,
    "Notification Cleared successfully",
  );
};

// module.exports.setOfferNotifications = async (req, res) => {
//   const { user_id , user_type , status } = req.body;

//   const user = await User.findOne({
//     where: {
//       id: user_id,
//       status: "active",
//       soft_delete: false,
//     },
//   });

//   if (!user) throw new ExpressError("User not found", 404);

//   const currentDate = moment().format("DD-MM-YYYY HH:mm:ss");
//   await sequelize.transaction(async (t) => {
//     const notifications = await UserNotificationsManagement.create(
//       {
//         user_id: user_id,
//         user_type: user_type,
//         is_offer_notification: status,
//       },
//       { transaction: t }
//     );
//   });

//   modelService.successResponse(
//     res,
//     200,
//     "Offers Status Updated",
//   );
// };

module.exports.setOfferNotifications = async (req, res) => {
  const { user_id, user_type, status } = req.body;

  const user = await User.findOne({
    where: {
      id: user_id,
      status: "active",
      soft_delete: false,
    },
  });

  if (!user) throw new ExpressError("User not found", 404);

  const currentDate = moment().format("DD-MM-YYYY HH:mm:ss");

  const existingNotification = await UserNotificationsManagement.findOne({
    where: {
      user_id: user_id,
    },
  });

  if (existingNotification) {
    // If a notification record already exists, update it
    await existingNotification.update(
      {
        user_type: user_type,
        is_offer_notification: status,
      },
      { fields: ["user_type", "is_offer_notification"] } // Only update specified fields
    );
  } else {
    // If no notification record exists, create a new one
    await sequelize.transaction(async (t) => {
      await UserNotificationsManagement.create(
        {
          user_id: user_id,
          user_type: user_type,
          is_offer_notification: status,
        },
        { transaction: t }
      );
    });
  }

  modelService.successResponse(res, 200, "Offers Status Updated");
};



module.exports.getOfferNotification = async (req, res) => {
  const { user_id } = req.body;
  const notifications = await UserNotificationsManagement 
  .findOne({
    where: {
      user_id: user_id,
    },
    ...modelService.queryOptions(req),
  });
  modelService.successResponse(res, 200, notifications);
};

module.exports.getAllNotifications = async (req, res) => {
  const notifications = await Notifications.findAll({
    where: {
      status: "active",
    },
    ...modelService.queryOptions(req),
  });
  modelService.successResponse(res, 200, notifications);
};
