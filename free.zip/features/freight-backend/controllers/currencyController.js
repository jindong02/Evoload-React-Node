const { Currency } = require("../models");
const { modelService, ExpressError } = require("../utilities");
const { dataValidator } = require("../utilities");


module.exports.getAllCurrencies = async (req, res) => {
    const currencies = await Currency.findAll({
        where: {
            status: 'active',
            soft_delete: false
        },
        ...modelService.queryOptions(req)
    });
    modelService.successResponse(res, 200, currencies);
};