const { sequelize } = require("../configs/dbConfig");
const { Freight, CarType, Currency, Truck, User, Country } = require("../models");
const FreightStatus = require("../models/freightStatus");
const Offer = require("../models/offer");
const { modelService, ExpressError } = require("../utilities");
const { dataValidator } = require("../utilities");
const { Sequelize, Op } = require('sequelize');

module.exports.getActiveTransports = async (req, res, next) => {
    const where = {};
    if (req.user.is_primary_user) {
        where.company_id = req.user.company_id;
    } else {
        where.user_id = req.user.id;
    }
    const offers = await Offer.findAll({
        where: {
            status: 'accepted',
            soft_delete: false,
            ...where,
        },
        attributes: [
            'id',
        ],
    });
    const offerIds = offers.map(offer => offer.id);
    if (offerIds.length === 0) {
        modelService.successResponse(res, 200, []);
    }
    const activeTransports = await Freight.findAndCountAll({
        where: {
            [Op.and]: [
                {
                    offer_id: {
                        [Op.in]: offerIds
                    }
                },
                {
                    [Op.or]: [
                        { status: 'offered' },
                        { status: 'pending' },
                        { status: 'started' },
                    ]
                }
            ],
        },
        ...modelService.queryOptions(req),
        include: [
            {
                model: Currency,
            },
            {
                model: CarType,
            },
            {
                model: Truck,
                attributes: ["license_number"],
                include: [
                    {
                        model: User,
                        as: "driver",
                        attributes: ["first_name", "surname", "full_name", "phone"],
                    }
                ]
            },
            {
                model: FreightStatus,
                as: "freight_statuses",
            },
            {
                model: Country,
                as: "freights_from",
                attributes: ["title"]
            },
            {
                model: Country,
                as: "freights_to",
                attributes: ["title"]
            }
        ],
    });
    modelService.successResponse(res, 200, activeTransports);
};

module.exports.getCompletedTransports = async (req, res, next) => {
    const where = {};
    if (req.user.is_primary_user) {
        where.company_id = req.user.company_id;
    } else {
        where.user_id = req.user.id;
    }
    const offers = await Offer.findAll({
        where: {
            status: 'accepted',
            soft_delete: false,
            ...where,
        },
        attributes: [
            'id',
        ],
    });
    const offerIds = offers.map(offer => offer.id);
    if (offerIds.length === 0) {
        modelService.successResponse(res, 200, []);
    }
    const completedTransports = await Freight.findAndCountAll({
        where: {
            status: 'completed',
            offer_id: {
                [Op.in]: offerIds
            }
        },
        ...modelService.queryOptions(req),
        include: [
            {
                model: Currency,
            },
            {
                model: CarType,
            },
            {
                model: Country,
                as: "freights_from",
                attributes: ["title"]
            },
            {
                model: Country,
                as: "freights_to",
                attributes: ["title"]
            }
        ],
    });
    modelService.successResponse(res, 200, completedTransports);
};

module.exports.deleteCompletedTransport = async (req, res) => {
    const { id } = req.params;
    const freight = await Freight.findOne({
        where: {
            id,
            status: 'completed',
        }
    });
    if (!freight) throw new ExpressError(404, "Transport not found");

    const offer = await Offer.findOne({
        where: {
            id: freight.offer_id,
            soft_delete: false,
            company_id: req.user.company_id,
        }
    });
    if (!offer) throw new ExpressError(404, "Offer not found");

    await offer.update({
        soft_delete: true,
    });

    modelService.successResponse(res, 200, {}, "Transport deleted successfully");
};