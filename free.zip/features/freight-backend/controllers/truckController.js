const bcrypt = require("bcrypt");
const { Op } = require("sequelize");
const { sequelize } = require("../configs/dbConfig");
const { Truck, User, CarType } = require("../models");
const { modelService, ExpressError } = require("../utilities");
const { dataValidator } = require("../utilities");
const { type } = require("../utilities/constantValues");

module.exports.getTruckList = async (req, res) => {
    const where = {};
    if (req.user.is_primary_user) {
        where.company_id = req.user.company_id;
    } else {
        where.user_id = req.user.id;
    }
    const trucks = await Truck.findAll({
        where: {
            status: 'active',
            soft_delete: false,
            ...where,
        },
        ...modelService.queryOptions(req),
        include: [
            {
                model: User,
                attributes: ["first_name", "surname", "full_name", "phone"],
                as: "driver"
            }
        ]
    });
    modelService.successResponse(res, 200, trucks);
};

module.exports.getAllTrucks = async (req, res) => {
    const trucks = await Truck.findAll({
        where: {
            status: 'active',
            soft_delete: false,
            company_id: req.user.company_id
        },
        ...modelService.queryOptions(req),
        include: [{
            model: CarType,
            attributes: ["id", "title"]
        }, {
            model: User,
            attributes: ["first_name", "phone"],
            as: "driver"
        }]
    });
    modelService.successResponse(res, 200, trucks);
};

module.exports.addTruck = async (req, res) => {
    const { error, value } = dataValidator.isValidCreateTruckObject({
        ...req.body,
        userTypeId: req.user.type === type.expeditor ? 1 : 2,
        companyId: req.user.company_id,
        userId: req.user.id
    });
    if (error) throw new ExpressError(400, error.details[0].message);

    await sequelize.transaction(async (t) => {
        const salt = await bcrypt.genSalt(12);
        const hashedPassword = await bcrypt.hash(value.password, salt);

        const registeredUser = await User.create({
            first_name: value.firstName,
            surname: value.surname,
            phone: value.phone,
            email: value.email,
            username: value.username,
            password: hashedPassword,
            type: value.type,
            country_code_id: value.countryCodeId,
            user_type_id: value.userTypeId,
            company_id: value.companyId,
            is_primary_user: false
        }, { transaction: t });

        await Truck.create({
            license_number: value.licenseNumber,
            length: value.length,
            width: value.width,
            height: value.height,
            car_type_id: value.carTypeId,
            company_id: value.companyId,
            user_id: value.userId,
            driver_user_id: registeredUser.id
        }, { transaction: t });
    });
    modelService.successResponse(res, 201, {}, 'Truck added successfully');
};

module.exports.deleteTruck = async (req, res) => {
    const { id } = req.params;
    await Truck.update({ soft_delete: true }, { where: { id, company_id: req.user.company_id } });
    modelService.successResponse(res, 200, {}, 'Truck deleted successfully');
};